# ManuAI v4 — Switching from Mock to Live Data

All source systems start in **mock mode** by default — the platform runs
fully functional without any real infrastructure.  When you're ready to
connect a real system, follow the steps below.  **Each system is
independent** — connect them one at a time in any order.

---

## How Mock Mode Works

Every connector and Python service checks for its config variable at startup.
If the variable is absent, it switches to a built-in mock implementation that
returns realistic data.  No code changes needed — just add the variable.

| System | Mock trigger | What mock provides |
|---|---|---|
| PI Historian | `PI_WEB_API_URL` absent | Hardcoded tag values + ±1% jitter |
| SAP OData | `SAP_ODATA_BASE_URL` absent | Mock production orders, work orders, PRs |
| LIMS | `LIMS_BASE_URL` absent | Mock batch test results |
| OPC-UA / MES | `OPC_UA_ENDPOINT` absent | In-memory set-point store (writes logged) |
| IoT Hub | `IOT_HUB_CONNECTION_STRING` absent | Simulated vibration sensor readings |
| PdM Inference | `AML_PDM_ENDPOINT` absent | Rule-based failure scoring |
| Yield Optimiser | `AML_YIELD_ENDPOINT` absent | Physics-rule DCS recommendations |
| Energy Optimiser | `AML_ENERGY_ENDPOINT` absent | Rule-based load dispatch |
| Quality Vision | `VISION_MODEL_PATH` absent | Synthetic defect generation |
| Supply Intelligence | `SAP_ODATA_BASE_URL` absent | Hardcoded supplier risk catalogue |
| Digital Twin | `ADT_INSTANCE_URL` absent | Synthetic KPI divergence data |
| Safety Monitor | `AML_SAFETY_ENDPOINT` absent | Rule-based gas/LOTO/proximity alerts |

---

## Connecting Each System

### 1. OSIsoft PI Historian
```bash
# Single-plant deployment
PI_WEB_API_URL=https://pi-server.plant.local/piwebapi
PI_USERNAME=svc_manuai_pi
PI_PASSWORD=your_password
PI_SERVER_NAME=PIServer01

# Multi-plant deployment (recommended for enterprise)
PI_WEB_API_URL_P1=https://pi-server-mumbai.plant.local/piwebapi
PI_USERNAME_P1=svc_manuai_pi
PI_PASSWORD_P1=your_password_p1
PI_SERVER_NAME_P1=PIServer-MUM

PI_WEB_API_URL_P2=https://pi-server-pune.plant.local/piwebapi
PI_USERNAME_P2=svc_manuai_pi
PI_PASSWORD_P2=your_password_p2
PI_SERVER_NAME_P2=PIServer-PUN
```
Then update the PI tag paths in:
- `apps/api/src/routes/oee.ts` → `MACHINE_TAGS`
- `apps/api/src/routes/yield.ts` → `PARAMS[].piTag`

### 2. SAP (PP / MM / PM / QM)
```bash
SAP_ODATA_BASE_URL=https://sap-gateway.plant.local:8080/sap/opu/odata/sap
SAP_OAUTH_TOKEN_URL=https://sap-gateway.plant.local/oauth/token
SAP_OAUTH_CLIENT_ID=MANUAI_CLIENT
SAP_OAUTH_CLIENT_SECRET=your_secret
# Multi-plant SAP plant codes
SAP_PLANT_CODE_P1=1000
SAP_PLANT_CODE_P2=2000
# Legacy single-plant fallback
SAP_PLANT_CODE=1000
```
SAP write-back (work orders, PRs, NCRs) becomes live automatically.

### 3. Azure IoT Hub
```bash
IOT_HUB_CONNECTION_STRING=Endpoint=sb://...
IOT_HUB_CONSUMER_GROUP=manuai-backend
```
Sensor simulation stops; real device telemetry streams in.

### 4. LIMS
```bash
LIMS_BASE_URL=https://lims.plant.local/api/v2
LIMS_API_KEY=your_key
```

### 5. OPC-UA / MES Set-points
```bash
OPC_UA_ENDPOINT=opc.tcp://mes-server.plant.local:4840
```
Update `nodeId` values in `apps/api/src/routes/yield.ts` → `PARAMS[].nodeId`.

### 6. Azure Digital Twins
```bash
ADT_INSTANCE_URL=https://manuai-adt-prod.digitaltwins.azure.net
AZURE_CLIENT_ID=your_app_id
AZURE_CLIENT_SECRET=your_secret
AZURE_TENANT_ID=your_tenant
```

### 7. Azure ML Scoring Endpoints (replace rule engines)
```bash
AML_PDM_ENDPOINT=https://manuai-pdm.azureml.net/score
AML_YIELD_ENDPOINT=https://manuai-yield.azureml.net/score
AML_ENERGY_ENDPOINT=https://manuai-energy.azureml.net/score
AML_SAFETY_ENDPOINT=https://manuai-safety.azureml.net/score
AML_API_KEY=your_key
```

### 8. Vision Model (Quality)
```bash
VISION_MODEL_PATH=/models/quality_v3.1.onnx
```
Place the ONNX model file at the path above inside the `quality-vision` container.

### 9. Anthropic (AI Chat)
```bash
ANTHROPIC_API_KEY=sk-ant-...
```
Without this, AI chat endpoints return 503.  All other features work normally.

---

## Verifying Connection

After adding variables, restart the relevant service and check:

```bash
curl http://localhost:4000/api/health | jq .
```

The response shows `mock_mode` flags for each connector.  A `false` flag means
the live connector is active.

---

## Disabling Mock Auth (production)

Set `MOCK_AUTH=false` and configure Azure AD:
```bash
VITE_AZURE_CLIENT_ID=your_spa_client_id
VITE_AZURE_TENANT_ID=your_tenant_id
MOCK_AUTH=false
```
