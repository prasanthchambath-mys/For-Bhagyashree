import { twinRouter } from './all-routes';
import {
  loadTwinComponents, loadTwinScenarios, loadTwinKPIs,
} from '../data/csv-loader';
import { normalizePlant, assetsFor } from '../data/plant';

twinRouter.get('/components', (req, res) => {
  const all = loadTwinComponents() as Record<string, any[]>;
  const code = normalizePlant(req.query.plant);
  if (!code) { res.json({ components: all }); return; }
  const ids = new Set(assetsFor(code));
  const components: Record<string, any[]> = {};
  for (const [assetId, comps] of Object.entries(all)) {
    if (ids.has(assetId)) components[assetId] = comps;
  }
  res.json({ components });
});

// /scenarios and /divergence already on twinRouter in all-routes.ts
// Add /divergence override with correct field mapping
twinRouter.get('/divergence-detail', (_req, res) => {
  const kpis = loadTwinKPIs() as any[];
  const divergence = kpis.map(k => {
    const delta  = Number(k.actual ?? 0) - Number(k.twin_predicted ?? 0);
    const pct    = Number(k.twin_predicted ?? 0) !== 0
      ? Math.abs(delta / Number(k.twin_predicted) * 100) : 0;
    const status = pct > Number(k.threshold_pct ?? 5) * 2 ? 'critical'
                 : pct > Number(k.threshold_pct ?? 5) ? 'diverging' : 'aligned';
    return {
      kpi:    k.kpi_name,
      actual: k.actual,
      twin:   k.twin_predicted,
      unit:   k.unit ?? '',
      delta:  (delta >= 0 ? '+' : '') + delta.toFixed(2),
      status, time: 'live',
      action: status === 'critical' ? `Investigate ${k.kpi_name} — actual deviates ${Math.abs(delta).toFixed(1)}${k.unit ?? ''} from twin model`
            : status === 'diverging' ? `Monitor ${k.kpi_name} — trending away from model` : 'Aligned with twin model',
      source_mode: 'CSV',
      source_system: 'Azure_Digital_Twins',
    };
  });
  res.json({ data: divergence });
});

export default twinRouter;
