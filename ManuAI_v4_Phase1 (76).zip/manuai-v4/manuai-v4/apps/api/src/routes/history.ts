/**
 * ManuAI — History Routes
 * Serves all historical data from SQLite database.
 * These endpoints power the trend charts across all 8 agents.
 */

import { Router } from 'express';
import {
  getOeeTrend, getPlantOeeTrend, getOeeSummary, getLossByType, getWeeklyLossByType, getOeeByHourRange,
  getHealthTrend, getAllHealthSummary,
  getAlertHistory, getAlertStats,
  getBatchHistory, getBatchStats,
  getYieldParamTrend,
  getEnergyTrend, getEnergyByAsset,
  getSafetyEventHistory, getSafetyStats,
  getMonthlyOeeByLineGroup } from '../database/queries';
import { loadShifts, loadTechnicians } from '../data/csv-loader';
import { ackAlertInDB } from '../database/writer';
import { logger } from '../middleware/logger';

const router = Router();

// ── OEE History ────────────────────────────────────────────────────────────────
router.get('/oee/trend/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = getOeeTrend(req.params.machineId, days);
  res.json({ machineId: req.params.machineId, days, data });
});

router.get('/oee/plant-trend', (req, res) => {
  const pfCode2 = req.query.plant ? (req.query.plant === 'Plant 1' ? 'P1' : req.query.plant === 'Plant 2' ? 'P2' : undefined) : undefined;
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getPlantOeeTrend(days, pfCode2 ?? 'All Plants') });
});

router.get('/oee/summary', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getOeeSummary(days) });
});

// ── PdM Health History ─────────────────────────────────────────────────────────
router.get('/pdm/health/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ machineId: req.params.machineId, days, data: getHealthTrend(req.params.machineId, days) });
});

router.get('/pdm/health-summary', (_req, res) => {
  res.json({ data: getAllHealthSummary() });
});

// ── Alerts History ─────────────────────────────────────────────────────────────
router.get('/alerts/history', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const severity = req.query.severity as string | undefined;
  const data = getAlertHistory(days, severity);
  res.json({ days, total: data.length, data });
});

router.get('/alerts/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getAlertStats(days) });
});

router.post('/alerts/:id/ack', (req, res) => {
  const ackedBy = req.user?.name ?? 'Unknown';
  const ok = ackAlertInDB(req.params.id, ackedBy);
  if (!ok) { res.status(404).json({ error: 'Alert not found' }); return; }
  logger.info('Alert acknowledged', { id: req.params.id, by: ackedBy });
  res.json({ success: true, alertId: req.params.id, ackedBy });
});

// ── Batch / Yield History ──────────────────────────────────────────────────────
router.get('/yield/batches', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchHistory(days) });
});

router.get('/yield/batch-stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchStats(days) });
});

router.get('/yield/param-trend/:paramId', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ paramId: req.params.paramId, days, data: getYieldParamTrend(req.params.paramId, days) });
});

// ── Energy History ─────────────────────────────────────────────────────────────
router.get('/energy/trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const allData = getEnergyTrend(days) as any[];
  // Energy trend is plant-level aggregate — filter by machine-linked readings if pfCode set
  const data = pfCode && pfCode !== 'All Plants'
    ? allData.map((row:any) => ({ ...row,
        total_kw: pfCode === 'P1' ? (Number(row.total_kw||0) * 0.52).toFixed(1) : (Number(row.total_kw||0) * 0.48).toFixed(1)
      }))
    : allData;
  res.json({ days, data });
});

router.get('/energy/by-asset', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ days, data: getEnergyByAsset(days) });
});

// ── Safety History ─────────────────────────────────────────────────────────────
router.get('/safety/events', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  // Now using plant_id column directly — stamped at ingestion, no zone inference needed
  const rawEv = getSafetyEventHistory(days, pfCode) as any[];
  const filteredEv = rawEv;
  const data = (filteredEv as any[]).map((e:any)=>({ ...e,
    action: e.resolved_at ? `Resolved — ${e.zone} readings normalised.`
          : e.severity === 'critical' ? `Evacuation alert issued for ${e.zone}. Hot-work permits blocked.`
          : `Precursor detected in ${e.zone}. Monitor and investigate.` }));
  res.json({ days, data });
});

router.get('/safety/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getSafetyStats(days) });
});


// ── Pre-computed Six Losses + Loss Trend (Issue 13: weights from config) ──────
router.get('/oee/six-losses', (req, res) => {
  const pfCode3 = req.query.plant ? (req.query.plant === 'Plant 1' ? 'P1' : req.query.plant === 'Plant 2' ? 'P2' : undefined) : undefined;
  const days = Number(req.query.days ?? 30);
  // Issue fix: aggregate REAL loss minutes per loss_type from oee_readings
  // (was total x fixed config weights — fabricated ratios)
  const CAT = [
    { name: 'Unplanned Breakdown', col: '#ef4444' },
    { name: 'Speed Loss',          col: '#f97316' },
    { name: 'Minor Stops',         col: '#fbbf24' },
    { name: 'Changeover & Setup',  col: '#f59e0b' },
    { name: 'Startup Defects',     col: '#84cc16' },
    { name: 'In-process Defects',  col: '#a3e635' },
  ];
  const rows = getLossByType(days, pfCode3 ?? 'All Plants') as any[];
  const totalMin = rows.reduce((s, r) => s + Number(r.total_min), 0);
  const byType: Record<string, any> = {};
  for (const r of rows) byType[r.loss_type] = r;
  const losses = CAT.map(c => {
    const r = byType[c.name];
    return {
      name: c.name, col: c.col,
      min:  r ? Math.round(Number(r.total_min)) : 0,
      pct:  r && totalMin > 0 ? +(Number(r.total_min) / totalMin * 100).toFixed(1) : 0,
      cnt:  r ? Number(r.machine_cnt) : 0,
      machines: r?.machines ? String(r.machines).split(',') : [],
    };
  });
  res.json({ days, losses });
});

router.get('/oee/loss-trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const pfCode5 = req.query.plant ? (req.query.plant === 'Plant 1' ? 'P1' : req.query.plant === 'Plant 2' ? 'P2' : undefined) : undefined;
  // Issue fix: weekly bars from REAL loss minutes per loss_type
  // (was (100 - avgOee) x fixed multipliers — fabricated)
  const rows = getWeeklyLossByType(Math.max(days, 42), pfCode5 ?? 'All Plants') as any[];
  const byWeek: Record<string, Record<string, number>> = {};
  for (const r of rows) {
    byWeek[r.wk] = byWeek[r.wk] ?? {};
    byWeek[r.wk][r.loss_type] = Math.round(Number(r.total_min));
  }
  const weeks = Object.keys(byWeek).sort().map((wk, i) => ({
    w: `W${String(i + 1).padStart(2, '0')}`,
    brk: byWeek[wk]['Unplanned Breakdown'] ?? 0,
    chg: byWeek[wk]['Changeover & Setup'] ?? 0,
    mst: byWeek[wk]['Minor Stops'] ?? 0,
    spd: byWeek[wk]['Speed Loss'] ?? 0,
    def: byWeek[wk]['In-process Defects'] ?? 0,
  }));
  res.json({ days, weeks: weeks.slice(-6) });
});


router.get('/oee/scorecard', (req, res) => {
  const pfCode4 = req.query.plant ? (req.query.plant === 'Plant 1' ? 'P1' : req.query.plant === 'Plant 2' ? 'P2' : undefined) : undefined;
  const days = Number(req.query.days ?? 180);
  const rows = getMonthlyOeeByLineGroup(days, pfCode4 ?? 'All Plants');
  const months: Record<string, { p1?: number; p2?: number }> = {};
  for (const r of rows) {
    if (!months[r.month]) months[r.month] = {};
    if (r.grp === 'g1') months[r.month].p1 = +Number(r.avg_oee).toFixed(1);
    else months[r.month].p2 = +Number(r.avg_oee).toFixed(1);
  }
  // OEE target: plant-specific from plant_config DB, fallback to platform_config.csv
  let oeeTarget = 85;
  try {
    const db = require('../database/connection').getDb();
    if (pfCode4 && pfCode4 !== 'All Plants') {
      const row = db.prepare("SELECT value FROM plant_config WHERE plant_id=? AND config_key='oee_target'").get(pfCode4) as {value:string}|undefined;
      if (row) oeeTarget = Number(row.value);
    }
  } catch { /* use default */ }
  const out = Object.entries(months).slice(-6).map(([m, v]) => ({
    m: new Date(m + '-01').toLocaleString('default', { month: 'short' }),
    p1: v.p1 ?? 0, p2: v.p2 ?? 0, target: oeeTarget,
  }));
  res.json({ days, scorecard: out });
});

export default router;

// ── Shifts (computed from OEE history by hour of day) ─────────────────────────
router.get('/oee/shifts', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const data = getPlantOeeTrend(days);
  // Group into shift buckets from daily data
  // Morning 06-14, Afternoon 14-22, Night 22-06
  const allShifts = loadShifts() as any[];
  const shiftDefs = pf && pfCode && pfCode !== 'All Plants' ? allShifts.filter((sh:any)=>!sh.plant||sh.plant===pfCode||sh.plant==='Both') : allShifts;
  const techList  = loadTechnicians();
  const now = new Date();
  const nowHour = now.getHours();
  const shifts = shiftDefs.map((s, i) => {
    const startH = parseInt(s.start);
    const endH   = parseInt(s.end);
    const active = nowHour >= startH && (endH === 6 ? nowHour >= 22 || nowHour < 6 : nowHour < endH);
    const tech   = techList.find(t => t.shift === s.name);
    return {
      shift:  s.name,
      tech:   tech?.name ?? 'Unassigned',
      role:   s.role,
      assets: s.assets,
      wos:    s.wos,
      status: active ? 'active' : i === ((shiftDefs.findIndex((_,j)=>{const sH=parseInt(shiftDefs[j].start);return nowHour>=sH;})+1)%shiftDefs.length) ? 'upcoming' : 'scheduled',
      start:  s.start,
      end:    s.end,
      // Issue fix: real OEE for this shift's hour window (was plantAvg x invented 0.97+i*0.01)
      avgOee: (() => {
        try {
          const sh = parseInt(String(s.start).split(':')[0]);
          const eh = parseInt(String(s.end).split(':')[0]);
          const v = getOeeByHourRange(isNaN(sh)?0:sh, isNaN(eh)?24:eh, 7);
          return v ?? (data.length ? +(data.reduce((s2,d)=>s2+d.avg_oee,0)/data.length).toFixed(1) : 0);
        } catch { return data.length ? +(data.reduce((s2,d)=>s2+d.avg_oee,0)/data.length).toFixed(1) : 0; }
      })(),
    };
  });
  res.json({ data: shifts });
});
