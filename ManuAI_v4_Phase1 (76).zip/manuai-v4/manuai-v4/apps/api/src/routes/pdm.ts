import { pdmRouter } from './all-routes';
import { loadParts, loadPdmRules } from '../data/csv-loader';

// Add extra PdM endpoints not in all-routes.ts
pdmRouter.get('/parts', (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const P1M=['MCH-01','MCH-02','MCH-03','MCH-04','CMP-001','CHP-002','HYD-003','PMP-005'];
  const P2M=['MCH-05','MCH-06','MCH-07','MCH-08','CMP-002','CHP-003'];
  const { orders, inventory } = loadParts();
  const matchPlant = (row:any) => {
    if (!pfCode || pfCode === 'All Plants') return true;
    const a = String(row.asset_id || row.asset || '');
    return (pfCode==='P1'?P1M:P2M).some(id => a.includes(id));
  };
  res.json({
    orders: (orders as any[]).filter(matchPlant),
    inventory: (inventory as any[]).filter(matchPlant),
  });
});

pdmRouter.get('/rules', (_req, res) => {
  res.json({ rules: loadPdmRules() });
});

export default pdmRouter;
