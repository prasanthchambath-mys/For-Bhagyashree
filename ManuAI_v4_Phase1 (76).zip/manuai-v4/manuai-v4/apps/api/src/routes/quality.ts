// Quality routes are defined in all-routes.ts (qualityRouter) with full plant filtering.
// This module re-exports that router so index.ts can mount it at /api/quality.
// The plant-filtered /defects and /lines handlers live in all-routes.ts.
import { qualityRouter } from './all-routes';

export default qualityRouter;
