import { Router } from 'express';
import { loadYieldParams, loadProductionOrders } from '../data/csv-loader';
import { getTagsBatch } from '../connectors/pi-historian';
import { getTodayResults } from '../connectors/lims';
import { getProductionOrders } from '../connectors/sap-odata';
import { writeSetPoint } from '../connectors/opc-ua';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { broadcast } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { getPlantState } from '../simulation/engine';
import { z } from 'zod';

const router = Router();

// DCS parameter metadata loaded from yield_params.csv — no hardcoded tags
// REPLACE WITH: OPC-UA tag registry or real PI tag config in Phase 3
function getParamsMeta() {
  return (loadYieldParams() as any[]).map(p => ({
    id:     p.id,
    name:   p.name,
    piTag:  `Plant.Reactor.${p.id.replace('-','')}.PV`,
    nodeId: `ns=2;s=${p.id.replace('-','')}_SP`,
    unit:   p.unit,
    min:    Number(p.min ?? 0),
    max:    Number(p.max ?? 100),
    target: Number(p.tgt ?? 0),
    plant:  p.plant || 'P1',
  }));
}

router.get('/params', async (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const piValues = await getTagsBatch(getParamsMeta().map(p => p.piTag)).catch(() => ({}));
  const simParams = getPlantState().yieldParams;

  const params = getParamsMeta().map(p => {
    const simVal = simParams.find(sp => sp.id === p.id);
    const val = piValues[p.piTag] ?? simVal?.val ?? p.target;
    const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId: p.id });
    return {
      ...p, val: +val.toFixed(1),
      warn: Math.abs(val - p.target) / p.target > 0.05,
      blocked: conflict.blocked, blockedReason: conflict.reason,
    };
  });
  const filteredParams = pfCode && pfCode !== 'All Plants'
    ? params.filter((p:any) => !p.plant || p.plant === pfCode || p.plant === 'Both')
    : params;
  res.json({ params: filteredParams, timestamp: new Date().toISOString() });
});

const WriteSchema = z.object({ tagId: z.string(), value: z.number(), reason: z.string().min(5) });

router.post('/dcs-write', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const parsed = WriteSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  const { tagId, value, reason } = parsed.data;

  const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId });
  if (conflict.blocked) { res.status(409).json({ error: 'Semantic Layer block', reason: conflict.reason }); return; }

  const param = getParamsMeta().find(p => p.id === tagId);
  if (!param) { res.status(404).json({ error: `Unknown tag: ${tagId}` }); return; }
  if (value < param.min || value > param.max) { res.status(400).json({ error: `${value} out of safe range [${param.min}, ${param.max}]` }); return; }

  const ok = await writeSetPoint(param.nodeId, value);
  if (!ok) { res.status(502).json({ error: 'OPC-UA write failed' }); return; }

  logger.info('DCS write', { tagId, value, user: req.user?.name, reason });
  await semanticLayer.publishEvent({ id:`DCS-${Date.now()}`, from:'yield', to:'oee', type:'dcs_write', sev:'info',
    msg:`${param.name} → ${value} ${param.unit}: ${reason}`, impact:'Yield impact expected within 15 min', asset:tagId, ts:new Date().toISOString() });
  broadcast('yield', { type:'dcs_confirmed', tagId, value });
  res.json({ success: true, tagId, value, unit: param.unit });
});

router.get('/lims', async (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const all = await getTodayResults();
  const results = pfCode && pfCode !== 'All Plants'
    ? (all as any[]).filter((r:any) => !r.plant || r.plant === pfCode)
    : all;
  res.json({ results });
});

router.get('/orders', async (req, res) => {
  const opf = req.query.plant as string | undefined;
  const opfCode = opf === 'Plant 1' ? 'P1' : opf === 'Plant 2' ? 'P2' : opf;
  const state = getPlantState();
  // Issue fix: production_orders.csv is the authoritative source (CSV-driven
  // architecture). The SAP OData mock array previously bypassed it entirely.
  // In live SAP mode (SAP_ODATA_BASE_URL set) the connector takes precedence.
  let orders: any[] = [];
  if (process.env.SAP_ODATA_BASE_URL) {
    orders = (await getProductionOrders().catch(() => [])) as any[];
  }
  if (!orders.length) {
    try { orders = loadProductionOrders(); } catch { orders = []; }
  }
  const liveOrder = {
    id: state.batch.id, product: state.batch.product,
    qty: `${state.batch.qty} kg`, plan: state.batch.plan,
    actual: state.batch.actual, status: state.batch.status,
    start: new Date(state.batch.startedAt).toLocaleString('en-IN'),
    end: new Date(state.batch.startedAt + state.batch.durationMs).toLocaleString('en-IN'),
    // The simulation engine models one global batch. Tag it as P1 so the plant
    // filter treats it like any other row instead of duplicating under both plants.
    plant: 'P1',
  };
  const filteredOrders = opfCode && opfCode !== 'All Plants' ? orders.filter((o:any)=>!o.plant||o.plant===opfCode) : orders;
  // Only include the live batch when the selected plant matches it (or no filter).
  const includeLive = !opfCode || opfCode === 'All Plants' || opfCode === liveOrder.plant;
  // De-duplicate: if a CSV row shares the live batch's id, drop the CSV one so the
  // live (in-progress) version wins. Prevents the "two rows with PP-88414" effect.
  const deduped = includeLive
    ? [liveOrder, ...filteredOrders.filter((o:any) => o.id !== liveOrder.id)]
    : filteredOrders;
  res.json({ orders: deduped });
});

export default router;
