/**
 * ManuAI — Platform Configuration Route
 *
 * Serves all customer-configurable values from platform_config.csv.
 * Edit platform_config.csv in Excel → restart → values update in UI.
 * No code change, no rebuild needed.
 */

import { Router } from 'express';
import { loadPlatformConfig, loadTechStack, loadSemanticKpiDefs, loadPersonas, loadBaselines } from '../data/csv-loader';

const router = Router();

router.get('/', (_req, res) => {
  try {
    res.json(loadPlatformConfig());
  } catch (err) {
    res.status(500).json({ error: 'Failed to load platform config' });
  }
});

router.get('/tech-stack', (_req, res) => {
  try { res.json({ stacks: loadTechStack() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load tech stack' }); }
});

router.get('/semantic-kpis', (_req, res) => {
  try { res.json({ definitions: loadSemanticKpiDefs() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load semantic KPI definitions' }); }
});

router.get('/personas', (_req, res) => {
  try { res.json({ personas: loadPersonas() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load personas' }); }
});

router.get('/baselines', (req, res) => {
  try {
    const plant = req.query.plant as string | undefined;
    res.json({ baselines: loadBaselines(plant) });
  }
  catch (err) { res.status(500).json({ error: 'Failed to load baselines' }); }
});

// ── Per-plant configuration from plant_config DB table ──────────────────────
router.get('/plant/:plantId', (_req, res) => {
  try {
    const { plantId } = _req.params;
    const db = require('../database/connection').getDb();
    const rows = db.prepare('SELECT config_key, value, label, unit FROM plant_config WHERE plant_id = ?').all(plantId) as {config_key:string,value:string,label:string,unit:string}[];
    const config: Record<string, {value:string,label:string,unit:string}> = {};
    for (const r of rows) config[r.config_key] = { value: r.value, label: r.label, unit: r.unit };
    res.json({ plantId, config });
  } catch { res.json({ plantId: _req.params.plantId, config: {} }); }
});

// All registered plants (from dim_plant dimension table)
router.get('/plants', (_req, res) => {
  try {
    const db = require('../database/connection').getDb();
    const plants = db.prepare(`
      SELECT p.plant_id, p.plant_name, p.location, p.timezone, p.currency,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='oee_target') as oee_target,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='sap_plant_code') as sap_plant_code,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='energy_tariff_rs') as energy_tariff_rs,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='yield_target') as yield_target,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='pi_server_name') as pi_server_name
      FROM dim_plant p ORDER BY p.plant_id
    `).all();
    res.json({ plants });
  } catch { res.json({ plants: [] }); }
});

export default router;
