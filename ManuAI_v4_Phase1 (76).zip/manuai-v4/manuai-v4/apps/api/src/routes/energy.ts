import { energyRouter } from './all-routes';
import {
  loadEnergyWaste, loadCarbonTrend,
  loadDemandForecast, loadEnergyDispatch,
} from '../data/csv-loader';


energyRouter.get('/waste', (req, res) => {
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const all = loadEnergyWaste() as any[];
  res.json({ waste: pf && pfCode && pfCode !== 'All Plants' ? all.filter((r:any)=>!r.plant||r.plant===pfCode||r.plant==='Both') : all });
});
energyRouter.get('/carbon', (req, res) => {
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const all = loadCarbonTrend() as any[];
  res.json({ data: pf && pfCode && pfCode !== 'All Plants' ? all.filter((r:any)=>!r.plant||r.plant===pfCode) : all });
});
energyRouter.get('/demand-forecast', (_req, res) => res.json({ data:    loadDemandForecast() }));
energyRouter.get('/dispatch', (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const all = loadEnergyDispatch() as any[];
  const actions = pfCode && pfCode !== 'All Plants' ? all.filter((a:any)=>!a.plant||a.plant===pfCode) : all;
  res.json({ actions });
});

energyRouter.get('/live', (req, res) => {
  // REPLACE WITH: Azure IoT Hub / SCADA real-time energy feed in Phase 3
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const byPlant = (a: any) => !pfCode || pfCode === 'All Plants' || a.plant === pfCode;
  try {
    const { getPlantState } = require('../simulation/engine');
    const simAssets = getPlantState().energyAssets;
    if (Array.isArray(simAssets) && simAssets.length) {
      return res.json({ assets: simAssets.filter(byPlant).map((a: any) => ({
        id: a.id, name: a.name, kw: a.kw, anomaly: !!a.anomaly, plant: a.plant,
      })) });
    }
  } catch { /* fall through to CSV */ }
  try {
    const { loadEnergyAssets } = require('../data/csv-loader');
    res.json({ assets: (loadEnergyAssets() as any[]).filter(byPlant) });
  } catch {
    res.json({ assets: [] });
  }
});

export default energyRouter;
