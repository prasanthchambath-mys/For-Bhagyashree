import { safetyRouter } from './all-routes';
import { loadSafetyPermits, loadSafetyZones } from '../data/csv-loader';

safetyRouter.get('/permits', (req, res) => {
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const all = loadSafetyPermits() as any[];
  const filtered = pf && pfCode && pfCode !== 'All Plants' ? all.filter((r:any)=>!r.plant||r.plant===pfCode||r.plant==='Both') : all;
  res.json({ permits: filtered });
});

safetyRouter.get('/zones', (req, res) => {
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const all = loadSafetyZones() as any[];
  const filtered = pf && pfCode && pfCode !== 'All Plants' ? all.filter((r:any)=>!r.plant||r.plant===pfCode||r.plant==='Both') : all;
  res.json({ zones: filtered });
});

export default safetyRouter;
