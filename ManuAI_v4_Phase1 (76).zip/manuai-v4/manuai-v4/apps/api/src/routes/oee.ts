import { Router } from 'express';

// Loss split factors from platform_config.csv (section: loss_split) — Issue 9 fix
import { loadCsvRaw } from '../data/csv-loader';
const LOSS_SPLIT = (() => {
  const defaults = { changeover_setup: 0.15, startup_defects: 0.05, inprocess_defects: 0.04 };
  try {
    const rows = loadCsvRaw('platform_config.csv').filter((r: any) => r.section === 'loss_split');
    for (const r of rows) {
      if (r.key in defaults) (defaults as any)[r.key] = Number(r.value);
    }
  } catch { /* use defaults */ }
  return defaults;
})();
import { getPlantState } from '../simulation/engine';
import { getTagsBatch } from '../connectors/pi-historian';
import { semanticLayer } from '../semantic/service';
import { logger } from '../middleware/logger';
import { loadMachines } from '../data/csv-loader';

const router = Router();

// getMachineTags() built from machines.csv — pi_tag column
// REPLACE WITH: PI Web API tag registry in Phase 3
function getMachineTags(): Record<string, { avail: string; perf: string; qual: string }> {
  const machines = loadMachines();
  const result: Record<string, { avail: string; perf: string; qual: string }> = {};
  for (const m of machines) {
    const line = (m.line ?? 'LineA').replace(/\s/g, '');
    const id   = m.id.replace('-', '');
    result[m.id] = {
      avail: `Plant.${line}.${id}.Availability`,
      perf:  `Plant.${line}.${id}.Performance`,
      qual:  `Plant.${line}.${id}.Quality`,
    };
  }
  return result;
}

router.get('/live', async (_req, res) => {
  try {
    const allTags = Object.values(getMachineTags()).flatMap(t => [t.avail, t.perf, t.qual]);
    const piValues = await getTagsBatch(allTags).catch(() => ({}));
    const state = getPlantState();

    const roundM = (m: any) => ({
      ...m,
      health:  +Number(m.health).toFixed(1),
      rul:     Math.round(Number(m.rul)),
      lossMin: Math.round(Number(m.lossMin ?? 0)),
      vib:     +Number(m.vib  ?? 0).toFixed(1),
      temp:    Math.round(Number(m.temp ?? 0)),
    });
    const machines = state.machines.map(m => {
      const tags = getMachineTags()[m.id];
      if (tags && Object.keys(piValues).length > 0) {
        const avail = piValues[tags.avail] ?? m.avail;
        const perf  = piValues[tags.perf]  ?? m.perf;
        const qual  = piValues[tags.qual]  ?? m.qual;
        return roundM({ ...m, avail:+avail.toFixed(1), perf:+perf.toFixed(1), qual:+qual.toFixed(1),
                 oee:+(avail * perf * qual / 10000).toFixed(1) });
      }
      return roundM(m);
    });

    res.json({ machines, plantOEE: state.plantOEE, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error('OEE live error', { error: String(err) });
    const state = getPlantState();
    const roundM2 = (m: any) => ({
      ...m,
      health:  +Number(m.health).toFixed(1),
      rul:     Math.round(Number(m.rul)),
      lossMin: Math.round(Number(m.lossMin ?? 0)),
      vib:     +Number(m.vib  ?? 0).toFixed(1),
      temp:    Math.round(Number(m.temp ?? 0)),
    });
    res.json({ machines: state.machines.map(roundM2), plantOEE: state.plantOEE, timestamp: new Date().toISOString() });
  }
});

router.get('/losses', (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const P1M = ['MCH-01','MCH-02','MCH-03','MCH-04'], P2M = ['MCH-05','MCH-06','MCH-07','MCH-08'];
  const state = getPlantState();
  const machines = (pfCode && pfCode !== 'All Plants')
    ? state.machines.filter(m => (pfCode === 'P1' ? P1M : P2M).includes(m.id))
    : state.machines;
  const breakdowns = machines.filter(m => m.loss === 'Unplanned Breakdown');
  const speedLoss  = machines.filter(m => m.loss === 'Speed Loss');
  const minorStops = machines.filter(m => m.loss === 'Minor Stops');
  const totalMin   = machines.reduce((a,m)=>a+m.lossMin,0);

  const losses = [
    { name:'Unplanned Breakdown', min:breakdowns.reduce((a,m)=>a+m.lossMin,0), pct:0, cnt:breakdowns.length, machines:breakdowns.map(m=>m.id) },
    { name:'Speed Loss',          min:speedLoss.reduce((a,m)=>a+m.lossMin,0),  pct:0, cnt:speedLoss.length,  machines:speedLoss.map(m=>m.id)  },
    { name:'Minor Stops',         min:minorStops.reduce((a,m)=>a+m.lossMin,0), pct:0, cnt:minorStops.length, machines:minorStops.map(m=>m.id) },
    { name:'Changeover & Setup',  min:Math.floor(totalMin*LOSS_SPLIT.changeover_setup), pct:0, cnt:machines.filter(m=>m.status==='caution').length||8,  machines:machines.filter(m=>m.status==='caution').map(m=>m.id) },
    { name:'Startup Defects',     min:Math.floor(totalMin*LOSS_SPLIT.startup_defects), pct:0, cnt:machines.filter(m=>m.status==='good').length||3,  machines:machines.filter(m=>m.status==='good').slice(0,1).map(m=>m.id) },
    { name:'In-process Defects',  min:Math.floor(totalMin*LOSS_SPLIT.inprocess_defects), pct:0, cnt:machines.filter(m=>m.status==='critical').length||4,  machines:machines.filter(m=>m.status==='critical').slice(0,1).map(m=>m.id) },
  ].map(l => ({ ...l, pct:totalMin>0 ? +(l.min/totalMin*100).toFixed(1) : 0 }));

  res.json({ losses, totalMinutes: totalMin, date: new Date().toISOString().split('T')[0] });
});

router.get('/alerts', (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;
  const P1M=['MCH-01','MCH-02','MCH-03','MCH-04'],P2M=['MCH-05','MCH-06','MCH-07','MCH-08'];
  const state = getPlantState();
  const alerts = state.machines
    .filter(m => (m.status === 'critical' || m.status === 'warning') && (!pfCode||pfCode==='All Plants'||(pfCode==='P1'?P1M:P2M).includes(m.id)))
    .map(m => ({
      id: `ALT-${m.id}`, sev: m.status === 'critical' ? 'critical' : 'warning',
      type: m.loss, machine: m.id, line: m.line,
      ts: new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' }),
      ack: false,
      msg: `${m.name}: ${m.loss}. OEE ${m.oee}%, Health ${m.health.toFixed(0)}%, Vib ${m.vib} mm/s, Temp ${m.temp}°C. RUL: ${m.rul.toFixed(0)}d.`,
      routed: m.status === 'critical' ? 'Maintenance team notified' : 'Supervisor notified',
    }));
  res.json({ alerts });
});

router.post('/alerts/:id/ack', (req, res) => {
  logger.info('Alert acked', { id: req.params.id, user: req.user?.name });
  res.json({ success: true, alertId: req.params.id, ackedBy: req.user?.name, at: new Date().toISOString() });
});

export default router;
