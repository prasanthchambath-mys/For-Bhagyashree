import { EventEmitter } from 'events';
import { loadConflictRules } from '../data/csv-loader';
import { persistSemanticEvent, persistEventImpact, getRecentEvents as getStoredEvents } from '../database/event-store';
import { logger } from '../middleware/logger';
import { broadcastEvent } from '../websocket/broadcaster';

export type AgentId = 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety';

export interface CrossAgentEvent {
  id: string; from: AgentId | string; to: AgentId | string;
  type: string; sev: 'critical' | 'warning' | 'info';
  msg: string; impact: string; asset: string; ts: string;
}

export interface AgentAction {
  agent: AgentId; type: string; assetId?: string; tagId?: string;
}

// KPI definitions loaded from semantic_kpi_definitions.csv (seeded to DB at startup)
// Source: data/csv/semantic_kpi_definitions.csv — edit there to change definitions
// REPLACE WITH: Azure App Configuration or admin UI in Phase 2
import { loadSemanticKpiDefs } from '../data/csv-loader';
import { getDb } from '../database/connection';

function loadKpiDefinitionsFromDb(): Record<string, any> {
  try {
    const rows = getDb().prepare('SELECT * FROM semantic_kpi_definition').all() as any[];
    if (rows.length === 0) throw new Error('empty');
    const result: Record<string, any> = {};
    for (const r of rows) {
      result[r.kpi_id] = {
        name:    r.kpi_name,
        formula: r.formula,
        unit:    r.unit,
        agents:  r.agents.split(','),
        src:     r.source_system,
        governance: r.governance,
      };
    }
    return result;
  } catch {
    // Fallback to CSV if DB not ready yet
    const defs = loadSemanticKpiDefs();
    const result: Record<string, any> = {};
    for (const d of defs as any[]) {
      result[d.id] = { name: d.name, formula: d.formula, unit: d.unit,
        agents: Array.isArray(d.agents) ? d.agents : d.agents.split(';'),
        src: d.src, governance: d.governance };
    }
    return result;
  }
}

let _kpiDefsCache: Record<string, any> | null = null;
export function getKpiDefinitions(): Record<string, any> {
  if (!_kpiDefsCache) _kpiDefsCache = loadKpiDefinitionsFromDb();
  return _kpiDefsCache;
}
export function reloadKpiDefinitions(): void { _kpiDefsCache = null; }

// Legacy export for backward compat — lazy loaded from CSV/DB
export const KPI_DEFINITIONS = new Proxy({} as Record<string, any>, {
  get: (_t, key: string) => getKpiDefinitions()[key],
  ownKeys: () => Object.keys(getKpiDefinitions()),
  getOwnPropertyDescriptor: () => ({ configurable: true, enumerable: true }),
});

// Conflict rules loaded from conflict_rules.csv — no hardcoded rules
// REPLACE WITH: CMMS conflict rule API in Phase 3
let _conflictRulesCache: ReturnType<typeof loadConflictRules> | null = null;
function getConflictRules() {
  if (!_conflictRulesCache) _conflictRulesCache = loadConflictRules();
  return _conflictRulesCache;
}

// Active faults: Map<"ruleId::assetId", { since, assetId, zoneId? }>
// Key is scoped: "CR-001::MCH-06" — asset-specific blocking
const activeFaults = new Map<string, { since: Date; assetId: string; zoneId?: string }>();

class SemanticLayerService {
  private emitter = new EventEmitter();
  private recentEvents: CrossAgentEvent[] = [];
  private _cache = new Map<string, { val: unknown; exp: number }>();

  constructor() {
    this.emitter.setMaxListeners(50);
    logger.info('[Semantic] Using in-memory event bus (Redis inactive)');
  }

  getKPIDefinitions() { return getKpiDefinitions(); }

  registerFault(ruleId: string, assetId: string, zoneId?: string): void {
    activeFaults.set(`${ruleId}::${assetId}`, { since: new Date(), assetId, zoneId });
    logger.info('Semantic Layer: fault registered', { ruleId, assetId, zoneId });
  }

  resolveFault(ruleId: string, assetId: string): void {
    activeFaults.delete(`${ruleId}::${assetId}`);
    logger.info('Semantic Layer: fault resolved', { ruleId, assetId });
  }

  getActiveFaults(): Array<{ key: string; ruleId: string; assetId: string; zoneId?: string; since: Date }> {
    return Array.from(activeFaults.entries()).map(([key, v]) => ({
      key, ruleId: key.split('::')[0], assetId: v.assetId, zoneId: v.zoneId, since: v.since,
    }));
  }

  /**
   * Unified view of every conflict the Semantic Layer is currently enforcing,
   * across ALL rule types (yield DCS, PTW, work orders, energy dispatch, …).
   * Used by /api/semantic/active-blocks for the right-panel aggregate counter.
   *
   * Computed from two sources, to match checkConflict() exactly:
   *   1. activeFaults map — explicitly registered faults (CR-002 gas, CR-001 maintenance)
   *   2. Live plant state — machines in sustained critical state (the fallback path)
   * Without (2), the yield params get blocked=true but the counter showed 0 — a visible
   * contradiction in the UI.
   */
  getActiveBlocks(): Array<{
    ruleId: string; blockAgent: string; blockAction: string; triggerAgent: string;
    scope: 'asset' | 'zone'; assetId: string; zoneId?: string;
    plant_id: 'P1' | 'P2' | null; reason: string; since: Date;
  }> {
    const rules = getConflictRules();
    const ruleById = new Map(rules.map(r => [r.id, r]));
    const P1A = new Set(['MCH-01','MCH-02','MCH-03','MCH-04','CMP-001','CHP-002','HYD-003','PMP-005']);
    const P2A = new Set(['MCH-05','MCH-06','MCH-07','MCH-08','CMP-002','CHP-003']);
    const zonePlant = (z?: string) =>
      !z ? null : z.includes('Zone A') || z.includes('Zone B') ? 'P1'
        : z.includes('Zone C') || z.includes('Zone D') ? 'P2' : null;
    const assetPlant = (a: string) =>
      P1A.has(a) ? 'P1' : P2A.has(a) ? 'P2' : null;

    // Source 1: explicitly registered active faults
    const fromFaults = Array.from(activeFaults.entries()).flatMap(([key, v]) => {
      const ruleId = key.split('::')[0];
      const rule = ruleById.get(ruleId);
      if (!rule) return [];
      const plant_id = (rule.assetScope === 'zone' ? zonePlant(v.zoneId) : assetPlant(v.assetId)) as 'P1'|'P2'|null;
      return [{
        ruleId,
        blockAgent:  rule.blockAgent,
        blockAction: rule.blockActionType,
        triggerAgent: rule.triggerAgent,
        scope:       rule.assetScope as 'asset' | 'zone',
        assetId:     v.assetId,
        zoneId:      v.zoneId,
        plant_id,
        reason:      rule.reason,
        since:       v.since,
      }];
    });

    // Source 2: live-state-derived blocks (mirrors checkConflict's fallback path).
    // Adds a synthetic entry for every critical machine matched by a pdm-triggered
    // asset-scoped rule, deduped against fromFaults so we don't double-count.
    const seen = new Set(fromFaults.map(b => `${b.ruleId}::${b.assetId}`));
    const fromLive: typeof fromFaults = [];
    try {
      const { getPlantState } = require('../simulation/engine');
      const state = getPlantState();
      const criticalMachines = (state.machines as any[]).filter(
        (m: any) => m.status === 'critical' && m.health < 60
      );
      const pdmAssetRules = rules.filter(r => r.triggerAgent === 'pdm' && r.assetScope === 'asset');
      for (const m of criticalMachines) {
        for (const r of pdmAssetRules) {
          const key = `${r.id}::${m.id}`;
          if (seen.has(key)) continue;
          seen.add(key);
          fromLive.push({
            ruleId:       r.id,
            blockAgent:   r.blockAgent,
            blockAction:  r.blockActionType,
            triggerAgent: r.triggerAgent,
            scope:        r.assetScope as 'asset' | 'zone',
            assetId:      m.id,
            zoneId:       undefined,
            plant_id:     assetPlant(m.id) as 'P1'|'P2'|null,
            reason:       r.reason.replace('PdM critical fault detected', `${m.name} is in critical state`),
            since:        new Date(),
          });
        }
      }
    } catch { /* simulation not ready yet */ }

    return [...fromFaults, ...fromLive];
  }

  checkConflict(action: AgentAction): { blocked: boolean; reason?: string; ruleId?: string } {
    const rules = getConflictRules();
    // Check ephemeral fault map first
    for (const rule of rules) {
      if (rule.blockAgent !== action.agent) continue;
      if (rule.blockActionType !== action.type) continue;
      for (const [faultKey, fault] of activeFaults) {
        if (!faultKey.startsWith(rule.id)) continue;
        if (rule.assetScope === 'asset' && action.assetId && fault.assetId !== action.assetId) continue;
        if (rule.assetScope === 'zone' && action.assetId && fault.zoneId && fault.zoneId !== action.assetId) continue;
        return { blocked: true, reason: rule.reason, ruleId: rule.id };
      }
    }
    // Fallback: check live plant state against ALL CSV-defined rules that target a machine asset scope.
    // Ensures blocked state persists even if activeFaults map was cleared (e.g. after restart).
    // Issue fix: was hardcoding 'yield', 'dcs_write', 'CR-001' — now fully CSV-rule-driven.
    try {
      const { getPlantState } = require('../simulation/engine');
      const state = getPlantState();
      // Hysteresis: only block on confirmed critical (not warning) to prevent rapid BLOCKED/NO CONFLICTS flipping
      // Machines must be status==='critical' (not just warning) to trigger semantic conflict
      const criticalMachines = (state.machines as any[]).filter(
        (m: any) => m.status === 'critical' && m.health < 60
      );
      if (criticalMachines.length > 0) {
        // Find any CSV rule that blocks this agent/action due to a pdm-triggered machine fault
        const matchingRule = rules.find(r =>
          r.blockAgent === action.agent &&
          r.blockActionType === action.type &&
          r.triggerAgent === 'pdm' &&
          r.assetScope === 'asset'
        );
        if (matchingRule) {
          const affectedMachine = action.assetId
            ? criticalMachines.find((m: any) => m.id === action.assetId) ?? criticalMachines[0]
            : criticalMachines[0];
          return {
            blocked: true,
            reason: matchingRule.reason.replace('PdM critical fault detected', `${affectedMachine.name} is in critical state`),
            ruleId: matchingRule.id,
          };
        }
      }
    } catch { /* simulation not ready yet */ }
    return { blocked: false };
  }

  async publishEvent(event: CrossAgentEvent): Promise<void> {
    // Persist to SQLite first — full audit trail
    persistSemanticEvent(event);
    // Keep in-memory for fast reads
    this.recentEvents.unshift(event);
    if (this.recentEvents.length > 500) this.recentEvents = this.recentEvents.slice(0, 500);
    this.emitter.emit('cross_agent_event', event);
    broadcastEvent(event as unknown as Record<string, unknown>);
    logger.info('Semantic event', { type: event.type, from: event.from, to: event.to });
  }

  async getRecentEvents(limit = 50): Promise<CrossAgentEvent[]> {
    try {
      // Read from SQLite for persistence across restarts
      const stored = getStoredEvents(limit);
      if (stored.length > 0) {
        return stored.map((r: any) => ({
          ...JSON.parse(r.payload ?? '{}'),
          id: r.event_id, type: r.event_type,
          from: r.from_agent, asset: r.asset_id,
          sev: r.severity, msg: r.message, ts: new Date(r.ts).toISOString(),
        }));
      }
    } catch { /* fall through to in-memory */ }
    return this.recentEvents.slice(0, limit);
  }

  async cache<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    const cached = this._cache.get(key);
    if (cached && Date.now() < cached.exp) return cached.val as T;
    const val = await fn();
    this._cache.set(key, { val, exp: Date.now() + ttl * 1000 });
    return val;
  }
}

export const semanticLayer = new SemanticLayerService();
