// ─────────────────────────────────────────────────────────────────────────────
// Shared plant lineage utility — single source of truth for plant filtering.
// Every route normalizes the incoming ?plant= selector and filters rows the same
// way, so plant scoping is consistent across all 8 agents and the Semantic Layer.
// ─────────────────────────────────────────────────────────────────────────────

export type PlantCode = 'P1' | 'P2';

export const P1_MACHINES = ['MCH-01', 'MCH-02', 'MCH-03', 'MCH-04'];
export const P2_MACHINES = ['MCH-05', 'MCH-06', 'MCH-07', 'MCH-08'];
export const P1_UTILITIES = ['CMP-001', 'CHP-002', 'HYD-003', 'PMP-005'];
export const P2_UTILITIES = ['CMP-002', 'CHP-003'];
export const P1_LINES = ['Line A', 'Line B'];
export const P2_LINES = ['Line C', 'Line D'];

export const P1_ASSETS = [...P1_MACHINES, ...P1_UTILITIES];
export const P2_ASSETS = [...P2_MACHINES, ...P2_UTILITIES];

/**
 * Normalize a raw ?plant= query value ('Plant 1' | 'Plant 2' | 'All Plants' | 'P1' | 'P2')
 * into a canonical plant code, or null for "all plants" / unspecified.
 */
export function normalizePlant(raw: unknown): PlantCode | null {
  if (raw === 'Plant 1' || raw === 'P1') return 'P1';
  if (raw === 'Plant 2' || raw === 'P2') return 'P2';
  return null; // 'All Plants', undefined, or anything else => no filter
}

/** True when a plant filter should be applied (i.e. not "All Plants"). */
export function hasPlantFilter(raw: unknown): boolean {
  return normalizePlant(raw) !== null;
}

/** Machines belonging to a plant code. */
export function machinesFor(code: PlantCode): string[] {
  return code === 'P1' ? P1_MACHINES : P2_MACHINES;
}

/** All assets (machines + utilities) belonging to a plant code. */
export function assetsFor(code: PlantCode): string[] {
  return code === 'P1' ? P1_ASSETS : P2_ASSETS;
}

/** Production lines belonging to a plant code. */
export function linesFor(code: PlantCode): string[] {
  return code === 'P1' ? P1_LINES : P2_LINES;
}

/**
 * Filter rows by a `plant` column. Rows with plant 'Both' (or no plant) are kept.
 * Pass the raw ?plant= value; returns all rows for "All Plants".
 */
export function filterByPlantColumn<T extends { plant?: string }>(rows: T[], raw: unknown): T[] {
  const code = normalizePlant(raw);
  if (!code) return rows;
  return rows.filter((r) => !r.plant || r.plant === code || r.plant === 'Both');
}

/**
 * Filter rows by an asset id field that maps to a plant (machines + utilities).
 */
export function filterByAsset<T>(rows: T[], raw: unknown, key: keyof T): T[] {
  const code = normalizePlant(raw);
  if (!code) return rows;
  const ids = new Set(assetsFor(code));
  return rows.filter((r) => {
    const v = r[key] as unknown as string;
    return !v || ids.has(v);
  });
}

/**
 * Filter rows by a production line field that maps to a plant.
 */
export function filterByLine<T>(rows: T[], raw: unknown, key: keyof T): T[] {
  const code = normalizePlant(raw);
  if (!code) return rows;
  const lines = linesFor(code);
  return rows.filter((r) => {
    const v = r[key] as unknown as string;
    return !v || lines.some((l) => String(v).includes(l));
  });
}
