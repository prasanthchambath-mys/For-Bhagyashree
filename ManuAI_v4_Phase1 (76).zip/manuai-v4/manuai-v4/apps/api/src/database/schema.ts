/**
 * ManuAI — Database Schema
 * Creates all tables on first startup if they don't exist.
 * Safe to run multiple times — uses IF NOT EXISTS.
 */

import { getDb } from './connection';
import { logger } from '../middleware/logger';

export function runMigrations(): void {
  const db = getDb();

  db.exec(`
    -- OEE readings — one row per machine per tick
    CREATE TABLE IF NOT EXISTS oee_readings (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      machine_id   TEXT    NOT NULL,
      machine_name TEXT    NOT NULL,
      line         TEXT    NOT NULL,
      ts           INTEGER NOT NULL,   -- Unix timestamp ms
      oee          REAL    NOT NULL,
      avail        REAL    NOT NULL,
      perf         REAL    NOT NULL,
      qual         REAL    NOT NULL,
      loss_type    TEXT,
      loss_min     INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_oee_machine_ts ON oee_readings(machine_id, ts);
    CREATE INDEX IF NOT EXISTS idx_oee_ts         ON oee_readings(ts);

    -- Machine health and sensor readings
    CREATE TABLE IF NOT EXISTS machine_health (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      machine_id   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      health       REAL    NOT NULL,
      rul          REAL    NOT NULL,
      vib          REAL    NOT NULL,
      temp         REAL    NOT NULL,
      status       TEXT    NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_health_machine_ts ON machine_health(machine_id, ts);

    -- Alerts fired by the simulation engine
    CREATE TABLE IF NOT EXISTS alerts (
      id           TEXT    PRIMARY KEY,
      machine_id   TEXT    NOT NULL,
      machine_name TEXT,
      line         TEXT,
      type         TEXT    NOT NULL,
      severity     TEXT    NOT NULL,
      message      TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      acked        INTEGER DEFAULT 0,
      acked_by     TEXT,
      acked_at     INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_alerts_ts       ON alerts(ts);
    CREATE INDEX IF NOT EXISTS idx_alerts_machine  ON alerts(machine_id);
    CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);

    -- Production batches
    CREATE TABLE IF NOT EXISTS batches (
      id           TEXT    PRIMARY KEY,
      product      TEXT    NOT NULL,
      qty_kg       INTEGER NOT NULL,
      plan_yield   REAL    NOT NULL,
      actual_yield REAL,
      status       TEXT    NOT NULL,
      started_at   INTEGER NOT NULL,
      completed_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_batches_ts ON batches(started_at);

    -- Yield parameter history
    CREATE TABLE IF NOT EXISTS yield_history (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      param_id     TEXT    NOT NULL,
      param_name   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      value        REAL    NOT NULL,
      target       REAL    NOT NULL,
      warn         INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_yield_param_ts ON yield_history(param_id, ts);

    -- Energy readings per asset
    CREATE TABLE IF NOT EXISTS energy_readings (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      asset_id     TEXT    NOT NULL,
      asset_name   TEXT    NOT NULL,
      ts           INTEGER NOT NULL,
      kw           REAL    NOT NULL,
      anomaly      INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_energy_asset_ts ON energy_readings(asset_id, ts);

    -- Safety events
    CREATE TABLE IF NOT EXISTS safety_events (
      id           TEXT    PRIMARY KEY,
      zone         TEXT    NOT NULL,
      event_type   TEXT    NOT NULL,
      severity     TEXT    NOT NULL,
      h2s          REAL    DEFAULT 0,
      co           REAL    DEFAULT 0,
      ch4          REAL    DEFAULT 0,
      ts           INTEGER NOT NULL,
      resolved_at  INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_safety_ts ON safety_events(ts);


  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — Dimension tables (enterprise data model)
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS dim_plant (
    plant_id     TEXT PRIMARY KEY,
    plant_name   TEXT NOT NULL,
    location     TEXT,
    timezone     TEXT DEFAULT 'Asia/Kolkata',
    currency     TEXT DEFAULT 'INR',
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_line (
    line_id      TEXT PRIMARY KEY,
    line_name    TEXT NOT NULL,
    plant_id     TEXT NOT NULL REFERENCES dim_plant(plant_id),
    line_type    TEXT,
    capacity_pct REAL DEFAULT 100,
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_asset (
    asset_id     TEXT PRIMARY KEY,
    asset_name   TEXT NOT NULL,
    asset_type   TEXT NOT NULL,
    line_id      TEXT REFERENCES dim_line(line_id),
    plant_id     TEXT NOT NULL,
    rated_kw     REAL,
    source_system TEXT DEFAULT 'PI_HISTORIAN',
    created_at   INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_dim_asset_line ON dim_asset(line_id);

  CREATE TABLE IF NOT EXISTS dim_supplier (
    supplier_id   TEXT PRIMARY KEY,
    supplier_name TEXT NOT NULL,
    country       TEXT,
    risk_category TEXT DEFAULT 'medium',
    single_source INTEGER DEFAULT 0,
    created_at    INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_material (
    material_id   TEXT PRIMARY KEY,
    material_name TEXT NOT NULL,
    unit          TEXT NOT NULL,
    category      TEXT,
    lead_days     INTEGER DEFAULT 14,
    created_at    INTEGER NOT NULL
  );

  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — Fact tables (enterprise event/reading model)
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS fact_sensor_reading (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id     TEXT NOT NULL REFERENCES dim_asset(asset_id),
    ts           INTEGER NOT NULL,
    reading_type TEXT NOT NULL,  -- vibration|temperature|pressure|current
    value        REAL NOT NULL,
    unit         TEXT NOT NULL,
    source_system TEXT DEFAULT 'PI_HISTORIAN',
    quality_flag  TEXT DEFAULT 'GOOD'
  );
  CREATE INDEX IF NOT EXISTS idx_fact_sensor_asset_ts ON fact_sensor_reading(asset_id, ts);
  CREATE INDEX IF NOT EXISTS idx_fact_sensor_type     ON fact_sensor_reading(reading_type, ts);

  CREATE TABLE IF NOT EXISTS fact_production_order (
    order_id     TEXT PRIMARY KEY,
    material_id  TEXT REFERENCES dim_material(material_id),
    line_id      TEXT REFERENCES dim_line(line_id),
    planned_qty  REAL NOT NULL,
    actual_qty   REAL,
    planned_yield REAL,
    actual_yield  REAL,
    status       TEXT NOT NULL,
    source_system TEXT DEFAULT 'SAP_PP',
    started_at   INTEGER,
    completed_at INTEGER,
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS fact_work_order (
    wo_id        TEXT PRIMARY KEY,
    asset_id     TEXT REFERENCES dim_asset(asset_id),
    wo_type      TEXT NOT NULL,  -- corrective|preventive|predictive
    priority     TEXT NOT NULL,
    description  TEXT,
    status       TEXT NOT NULL,
    assigned_to  TEXT,
    source_system TEXT DEFAULT 'SAP_PM',
    triggered_by  TEXT,  -- semantic_event_id that triggered this WO
    created_at   INTEGER NOT NULL,
    completed_at INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_fact_wo_asset ON fact_work_order(asset_id);

  CREATE TABLE IF NOT EXISTS fact_quality_event (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id     TEXT REFERENCES dim_asset(asset_id),
    line_id      TEXT REFERENCES dim_line(line_id),
    ts           INTEGER NOT NULL,
    defect_type  TEXT NOT NULL,
    severity     TEXT NOT NULL,
    confidence   REAL,
    action_taken TEXT,
    source_system TEXT DEFAULT 'VISION_AI',
    ncr_id       TEXT  -- SAP QM NCR reference
  );
  CREATE INDEX IF NOT EXISTS idx_fact_quality_ts ON fact_quality_event(ts);

  CREATE TABLE IF NOT EXISTS fact_energy_reading (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id     TEXT REFERENCES dim_asset(asset_id),
    ts           INTEGER NOT NULL,
    kw           REAL NOT NULL,
    kwh_cumulative REAL,
    tariff_zone  TEXT DEFAULT 'peak',
    anomaly      INTEGER DEFAULT 0,
    source_system TEXT DEFAULT 'SMART_METER'
  );
  CREATE INDEX IF NOT EXISTS idx_fact_energy_asset_ts ON fact_energy_reading(asset_id, ts);

  CREATE TABLE IF NOT EXISTS fact_safety_event (
    event_id     TEXT PRIMARY KEY,
    zone         TEXT NOT NULL,
    asset_id     TEXT,
    event_type   TEXT NOT NULL,
    severity     TEXT NOT NULL,
    h2s_ppm      REAL DEFAULT 0,
    co_ppm       REAL DEFAULT 0,
    ch4_lel_pct  REAL DEFAULT 0,
    source_system TEXT DEFAULT 'EHS_SYSTEM',
    ts           INTEGER NOT NULL,
    resolved_at  INTEGER,
    ptw_id       TEXT  -- linked PTW if any
  );
  CREATE INDEX IF NOT EXISTS idx_fact_safety_ts ON fact_safety_event(ts);

  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — KPI Engine tables
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS semantic_kpi_definition (
    kpi_id       TEXT PRIMARY KEY,
    kpi_name     TEXT NOT NULL,
    formula      TEXT NOT NULL,
    unit         TEXT NOT NULL,
    agents       TEXT NOT NULL,  -- comma-separated agent IDs
    source_system TEXT NOT NULL,
    governance   TEXT DEFAULT 'Semantic Layer',
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS semantic_kpi_value (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kpi_id       TEXT NOT NULL REFERENCES semantic_kpi_definition(kpi_id),
    asset_id     TEXT,
    scope        TEXT DEFAULT 'plant',  -- plant|line|asset
    ts           INTEGER NOT NULL,
    value        REAL NOT NULL,
    target       REAL,
    status       TEXT DEFAULT 'ok'  -- ok|warn|critical
  );
  CREATE INDEX IF NOT EXISTS idx_kpi_value_kpi_ts ON semantic_kpi_value(kpi_id, ts);
  CREATE INDEX IF NOT EXISTS idx_kpi_value_asset   ON semantic_kpi_value(asset_id, ts);

  -- ══════════════════════════════════════════════════════════════
  -- SEMANTIC CORE — Event orchestration tables
  -- ══════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS semantic_event (
    event_id     TEXT PRIMARY KEY,
    event_type   TEXT NOT NULL,
    from_agent   TEXT NOT NULL,
    asset_id     TEXT,
    severity     TEXT NOT NULL,
    message      TEXT NOT NULL,
    payload      TEXT,           -- JSON blob with full event data
    ts           INTEGER NOT NULL,
    resolved_at  INTEGER,
    scenario_id  TEXT            -- links to orchestration scenario
  );
  CREATE INDEX IF NOT EXISTS idx_sem_event_ts       ON semantic_event(ts);
  CREATE INDEX IF NOT EXISTS idx_sem_event_asset    ON semantic_event(asset_id);
  CREATE INDEX IF NOT EXISTS idx_sem_event_type     ON semantic_event(event_type);

  CREATE TABLE IF NOT EXISTS semantic_event_impact (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id     TEXT NOT NULL REFERENCES semantic_event(event_id),
    target_agent TEXT NOT NULL,
    impact_type  TEXT NOT NULL,  -- oee_loss|yield_risk|supply_risk|safety_risk|energy_impact|twin_divergence
    impact_value REAL,
    impact_unit  TEXT,
    description  TEXT NOT NULL,
    action_taken TEXT,
    action_ref   TEXT,           -- WO ID, PTW ID, PO ID etc
    ts           INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_sem_impact_event ON semantic_event_impact(event_id);
  CREATE INDEX IF NOT EXISTS idx_sem_impact_agent ON semantic_event_impact(target_agent, ts);

  CREATE TABLE IF NOT EXISTS orchestration_scenario (
    scenario_id  TEXT PRIMARY KEY,
    scenario_name TEXT NOT NULL,
    trigger_event TEXT NOT NULL,
    asset_id     TEXT,
    status       TEXT DEFAULT 'running',  -- running|complete|paused
    started_at   INTEGER NOT NULL,
    completed_at INTEGER,
    steps_total  INTEGER DEFAULT 0,
    steps_done   INTEGER DEFAULT 0,
    summary      TEXT
  );

    -- Schema version tracking
    CREATE TABLE IF NOT EXISTS schema_version (
      version      INTEGER PRIMARY KEY,
      applied_at   INTEGER NOT NULL
    );
  
  -- Issue 8: reference data persisted from CSVs for audit/queryability
  CREATE TABLE IF NOT EXISTS ref_supply_risks (
    supplier_id TEXT, supplier_name TEXT, sku TEXT, description TEXT,
    current_stock_days REAL, reorder_point_days REAL,
    lead_time_contracted_days INTEGER, lead_time_actual_days INTEGER,
    monthly_consumption REAL, unit_cost_inr REAL, single_source TEXT,
    country_of_origin TEXT, financial_risk_score REAL,
    loaded_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS ref_quality_defects (
    id TEXT, time TEXT, line TEXT, component TEXT, type TEXT,
    severity TEXT, action TEXT, confidence REAL, loaded_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS ref_twin_kpis (
    kpi_id TEXT, kpi_name TEXT, unit TEXT, actual REAL,
    twin_predicted REAL, divergence_threshold_pct REAL, asset_id TEXT, loaded_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS ref_safety_permits (
    ptw_id TEXT, asset_id TEXT, work_type TEXT, technician TEXT,
    status TEXT, jha_complete TEXT, isolation_verified TEXT,
    competency_valid TEXT, loaded_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS ref_yield_params (
    id TEXT, name TEXT, unit TEXT, val REAL, tgt REAL,
    min REAL, max REAL, drift_rate REAL, loaded_at INTEGER
  );

  -- ── Per-plant configuration (thresholds, targets, tariffs) ──────────────
  CREATE TABLE IF NOT EXISTS plant_config (
    plant_id    TEXT NOT NULL,
    config_key  TEXT NOT NULL,
    value       TEXT NOT NULL,
    label       TEXT,
    unit        TEXT,
    updated_at  INTEGER DEFAULT (strftime('%s','now') * 1000),
    PRIMARY KEY (plant_id, config_key)
  );
`);

  // Mark schema version
  const existing = db.prepare('SELECT version FROM schema_version WHERE version = 2').get();
  if (!existing) {
    db.prepare('INSERT OR IGNORE INTO schema_version (version, applied_at) VALUES (2, ?)').run(Date.now());
  }

  logger.info('[DB] Schema migrations complete');
}

export function isHistorySeeded(): boolean {
  const db = getDb();
  const row = db.prepare('SELECT COUNT(*) as cnt FROM oee_readings').get() as { cnt: number };
  return row.cnt > 1000; // If more than 1000 rows, history is already seeded
}

export function runPlantMigration(): void {
  const db = getDb();
  // Add plant_id to all fact tables — idempotent (ADD COLUMN IF NOT EXISTS not supported in SQLite 3.37,
  // so we check via PRAGMA and skip if already present)
  const addCol = (table: string, col: string, def: string) => {
    try {
      const cols = db.pragma(`table_info(${table})`) as any[];
      if (!cols.find((c: any) => c.name === col)) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`);
        logger.info(`[DB] Added ${col} to ${table}`);
      }
    } catch (e) { logger.warn(`[DB] Migration skip: ${table}.${col}`, { error: String(e) }); }
  };

  addCol('oee_readings',   'plant_id', "TEXT NOT NULL DEFAULT 'P1'");
  addCol('machine_health', 'plant_id', "TEXT NOT NULL DEFAULT 'P1'");
  addCol('safety_events',  'plant_id', "TEXT NOT NULL DEFAULT 'P1'");
  addCol('alerts',         'plant_id', "TEXT NOT NULL DEFAULT 'P1'");
  addCol('batches',        'plant_id', "TEXT NOT NULL DEFAULT 'P1'");
  addCol('yield_history',  'plant_id', "TEXT NOT NULL DEFAULT 'P1'");
  addCol('energy_readings','plant_id', "TEXT NOT NULL DEFAULT 'P1'");

  // Backfill from known machine→plant mapping for existing rows
  db.exec(`
    UPDATE oee_readings SET plant_id = 'P2'
    WHERE plant_id = 'P1' AND machine_id IN ('MCH-05','MCH-06','MCH-07','MCH-08');
    UPDATE machine_health SET plant_id = 'P2'
    WHERE plant_id = 'P1' AND machine_id IN ('MCH-05','MCH-06','MCH-07','MCH-08');
    UPDATE energy_readings SET plant_id = 'P2'
    WHERE plant_id = 'P1' AND asset_id IN ('MCH-05','MCH-06','MCH-07','MCH-08','CHP-002');
    UPDATE safety_events SET plant_id = 'P2'
    WHERE plant_id = 'P1' AND zone IN ('Zone C','Zone D');
    UPDATE alerts SET plant_id = 'P2'
    WHERE plant_id = 'P1' AND machine_id IN ('MCH-05','MCH-06','MCH-07','MCH-08');
  `);

  // Add indexes for plant_id queries
  try {
    db.exec(`
      CREATE INDEX IF NOT EXISTS idx_oee_plant_ts   ON oee_readings(plant_id, ts);
      CREATE INDEX IF NOT EXISTS idx_health_plant_ts ON machine_health(plant_id, ts);
      CREATE INDEX IF NOT EXISTS idx_safety_plant_ts ON safety_events(plant_id, ts);
      CREATE INDEX IF NOT EXISTS idx_energy_plant_ts ON energy_readings(plant_id, ts);
    `);
  } catch (e) { /* indexes may already exist */ }

  // Seed plant_config with per-plant defaults if empty
  const cfgCount = (db.prepare('SELECT COUNT(*) as cnt FROM plant_config').get() as {cnt:number}).cnt;
  if (cfgCount === 0) {
    const upsertCfg = db.prepare(
      'INSERT OR IGNORE INTO plant_config (plant_id, config_key, value, label, unit) VALUES (?, ?, ?, ?, ?)'
    );
    const plantConfigs = [
      // Plant 1 — Mumbai (P1)
      ['P1', 'oee_target',           '85',    'OEE Target',                '%'],
      ['P1', 'scrap_rate_target',     '2.5',   'Scrap Rate Target',          '%'],
      ['P1', 'energy_tariff_rs',      '6.50',  'Energy Tariff',             'Rs/kWh'],
      ['P1', 'peak_tariff_rs',        '9.20',  'Peak Tariff',               'Rs/kWh'],
      ['P1', 'rul_critical_days',     '14',    'RUL Critical Threshold',    'days'],
      ['P1', 'rul_warning_days',      '30',    'RUL Warning Threshold',     'days'],
      ['P1', 'carbon_intensity',      '0.82',  'Grid Carbon Intensity',     'kgCO2/kWh'],
      ['P1', 'sap_plant_code',        '1000',  'SAP Plant Code',            ''],
      ['P1', 'timezone',              'Asia/Kolkata', 'Timezone',           ''],
      ['P1', 'currency',              'INR',   'Currency',                  ''],
      ['P1', 'pi_server_name',        'PIServer-MUM', 'PI Server',          ''],
      ['P1', 'yield_target',          '89',    'Yield Target',              '%'],
      // Plant 2 — Pune (P2)
      ['P2', 'oee_target',           '88',    'OEE Target',                '%'],
      ['P2', 'scrap_rate_target',     '3.5',   'Scrap Rate Target',          '%'],
      ['P2', 'energy_tariff_rs',      '6.80',  'Energy Tariff',             'Rs/kWh'],
      ['P2', 'peak_tariff_rs',        '9.50',  'Peak Tariff',               'Rs/kWh'],
      ['P2', 'rul_critical_days',     '14',    'RUL Critical Threshold',    'days'],
      ['P2', 'rul_warning_days',      '30',    'RUL Warning Threshold',     'days'],
      ['P2', 'carbon_intensity',      '0.86',  'Grid Carbon Intensity',     'kgCO2/kWh'],
      ['P2', 'sap_plant_code',        '2000',  'SAP Plant Code',            ''],
      ['P2', 'timezone',              'Asia/Kolkata', 'Timezone',           ''],
      ['P2', 'currency',              'INR',   'Currency',                  ''],
      ['P2', 'pi_server_name',        'PIServer-PUN', 'PI Server',          ''],
      ['P2', 'yield_target',          '86',    'Yield Target',              '%'],
    ];
    db.transaction(() => {
      for (const [plantId, key, value, label, unit] of plantConfigs) {
        upsertCfg.run(plantId, key, value, label, unit);
      }
    })();
    logger.info('[DB] plant_config seeded with defaults for P1 and P2');
  }

  logger.info('[DB] Plant migration complete');
}
