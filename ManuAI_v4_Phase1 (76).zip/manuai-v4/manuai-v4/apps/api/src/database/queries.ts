/**
 * ManuAI — Database Queries
 * All historical data queries in one place.
 * Same queries work on Azure SQL in Phase 2 — just change DATABASE_URL.
 */

import { getDb } from './connection';

// ── OEE ───────────────────────────────────────────────────────────────────────

export function getOeeTrend(machineId: string, days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      datetime(ts/1000, 'unixepoch') as time,
      oee, avail, perf, qual,
      ts
    FROM oee_readings
    WHERE machine_id = ? AND ts >= ?
    ORDER BY ts ASC
  `).all(machineId, since) as Array<{ time: string; oee: number; avail: number; perf: number; qual: number; ts: number }>;
}

export function getPlantOeeTrend(days = 30, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const pidSql = plant && plant !== 'All Plants' ? ' AND o.plant_id = ?' : '';
  // Inner sub-queries (avg_yield from batches, avg_health from machine_health) must
  // ALSO filter by plant — otherwise they return cross-plant averages while the
  // outer query is plant-scoped, making the Yield % and Fleet Health % lines look
  // static when the user switches plants.
  const hPidSql = plant && plant !== 'All Plants' ? ' AND h.plant_id = ?' : '';
  const bPidSql = plant && plant !== 'All Plants' ? ' AND b.plant_id = ?' : '';
  const pidArg = (plant && plant !== 'All Plants') ? plant : null;
  return getDb().prepare(`
    SELECT
      strftime('%Y-%m-%d', datetime(o.ts/1000, 'unixepoch')) as day,
      AVG(o.oee)   as avg_oee,
      MIN(o.oee)   as min_oee,
      MAX(o.oee)   as max_oee,
      AVG(o.avail) as avg_avail,
      AVG(o.perf)  as avg_perf,
      AVG(o.qual)  as avg_qual,
      (SELECT AVG(h.health) FROM machine_health h
        WHERE strftime('%Y-%m-%d', datetime(h.ts/1000, 'unixepoch')) = strftime('%Y-%m-%d', datetime(o.ts/1000, 'unixepoch'))` + hPidSql + `
      ) as avg_health,
      (SELECT AVG(b.actual_yield) FROM batches b
        WHERE strftime('%Y-%m-%d', datetime(b.started_at/1000, 'unixepoch')) = strftime('%Y-%m-%d', datetime(o.ts/1000, 'unixepoch'))
          AND b.actual_yield > 0` + bPidSql + `
      ) as avg_yield
    FROM oee_readings o
    WHERE o.ts >= ?` + pidSql + `
    GROUP BY day
    ORDER BY day ASC
  `).all(...[
    ...(pidArg ? [pidArg] : []),  // for hPidSql
    ...(pidArg ? [pidArg] : []),  // for bPidSql
    since,
    ...(pidArg ? [pidArg] : []),  // for pidSql (outer)
  ]) as Array<{ day: string; avg_oee: number; min_oee: number; max_oee: number; avg_avail: number; avg_perf: number; avg_qual: number; avg_health: number | null; avg_yield: number | null }>;
}

export function getOeeSummary(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      machine_id,
      machine_name,
      line,
      AVG(oee)       as avg_oee,
      MIN(oee)       as min_oee,
      MAX(oee)       as max_oee,
      SUM(loss_min)  as total_loss_min
    FROM oee_readings
    WHERE ts >= ?
    GROUP BY machine_id
    ORDER BY avg_oee ASC
  `).all(since) as Array<{ machine_id: string; machine_name: string; line: string; avg_oee: number; min_oee: number; max_oee: number; total_loss_min: number }>;
}

// ── Machine Health ─────────────────────────────────────────────────────────────

export function getHealthTrend(machineId: string, days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      datetime(ts/1000, 'unixepoch') as time,
      health, rul, vib, temp, status, ts
    FROM machine_health
    WHERE machine_id = ? AND ts >= ?
    ORDER BY ts ASC
  `).all(machineId, since) as Array<{ time: string; health: number; rul: number; vib: number; temp: number; status: string; ts: number }>;
}

export function getAllHealthSummary() {
  const since = Date.now() - 7 * 24 * 3600 * 1000; // last 7 days
  return getDb().prepare(`
    SELECT
      machine_id,
      AVG(health) as avg_health,
      MIN(health) as min_health,
      AVG(vib)    as avg_vib,
      MAX(vib)    as max_vib,
      AVG(temp)   as avg_temp
    FROM machine_health
    WHERE ts >= ?
    GROUP BY machine_id
  `).all(since) as Array<{ machine_id: string; avg_health: number; min_health: number; avg_vib: number; max_vib: number; avg_temp: number }>;
}

// ── Alerts ─────────────────────────────────────────────────────────────────────

export function getAlertHistory(days = 30, severity?: string) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const query = severity
    ? `SELECT * FROM alerts WHERE ts >= ? AND severity = ? ORDER BY ts DESC LIMIT 200`
    : `SELECT * FROM alerts WHERE ts >= ? ORDER BY ts DESC LIMIT 200`;
  const params = severity ? [since, severity] : [since];
  return getDb().prepare(query).all(...params) as Array<{
    id: string; machine_id: string; machine_name: string; line: string;
    type: string; severity: string; message: string; ts: number;
    acked: number; acked_by: string; acked_at: number;
  }>;
}

export function getAlertStats(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      severity,
      COUNT(*) as total,
      SUM(acked) as acked,
      COUNT(*) - SUM(acked) as open
    FROM alerts
    WHERE ts >= ?
    GROUP BY severity
  `).all(since) as Array<{ severity: string; total: number; acked: number; open: number }>;
}

// ── Batches ────────────────────────────────────────────────────────────────────

export function getBatchHistory(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT *,
      datetime(started_at/1000, 'unixepoch') as start_time,
      datetime(completed_at/1000, 'unixepoch') as end_time
    FROM batches
    WHERE started_at >= ?
    ORDER BY started_at DESC
    LIMIT 100
  `).all(since) as Array<{
    id: string; product: string; qty_kg: number; plan_yield: number;
    actual_yield: number; status: string; started_at: number; completed_at: number;
    start_time: string; end_time: string;
  }>;
}

export function getBatchStats(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      product,
      COUNT(*) as total_batches,
      AVG(plan_yield)   as avg_plan,
      AVG(actual_yield) as avg_actual,
      MIN(actual_yield) as min_yield,
      MAX(actual_yield) as max_yield
    FROM batches
    WHERE started_at >= ? AND status = 'completed'
    GROUP BY product
  `).all(since) as Array<{ product: string; total_batches: number; avg_plan: number; avg_actual: number; min_yield: number; max_yield: number }>;
}

// ── Yield Params ──────────────────────────────────────────────────────────────

export function getYieldParamTrend(paramId: string, days = 7) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      datetime(ts/1000, 'unixepoch') as time,
      value, target, warn, ts
    FROM yield_history
    WHERE param_id = ? AND ts >= ?
    ORDER BY ts ASC
  `).all(paramId, since) as Array<{ time: string; value: number; target: number; warn: number; ts: number }>;
}

// ── Energy ────────────────────────────────────────────────────────────────────

export function getEnergyTrend(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      strftime('%Y-%m-%d', datetime(ts/1000, 'unixepoch')) as day,
      SUM(kw)  as total_kw,
      AVG(kw)  as avg_kw,
      SUM(anomaly) as anomalies
    FROM energy_readings
    WHERE ts >= ?
    GROUP BY day
    ORDER BY day ASC
  `).all(since) as Array<{ day: string; total_kw: number; avg_kw: number; anomalies: number }>;
}

export function getEnergyByAsset(days = 7) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      asset_id,
      asset_name,
      AVG(kw)  as avg_kw,
      MAX(kw)  as peak_kw,
      SUM(anomaly) as anomaly_count
    FROM energy_readings
    WHERE ts >= ?
    GROUP BY asset_id
    ORDER BY avg_kw DESC
  `).all(since) as Array<{ asset_id: string; asset_name: string; avg_kw: number; peak_kw: number; anomaly_count: number }>;
}

// ── Safety ────────────────────────────────────────────────────────────────────

export function getSafetyEventHistory(days = 30, plant?: string) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const plantSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const plantArg = plant && plant !== 'All Plants' ? plant : null;
  return getDb().prepare(`
    SELECT *,
      datetime(ts/1000, 'unixepoch') as event_time,
      CASE WHEN resolved_at IS NOT NULL
        THEN ROUND((resolved_at - ts) / 60000.0, 0)
        ELSE NULL
      END as resolution_min
    FROM safety_events
    WHERE ts >= ?` + plantSql + `
    ORDER BY ts DESC
    LIMIT 100
  `).all(...[since, ...(plantArg ? [plantArg] : [])]) as Array<{
    id: string; zone: string; event_type: string; severity: string;
    h2s: number; co: number; ch4: number; ts: number; resolved_at: number;
    event_time: string; resolution_min: number;
  }>;
}

export function getSafetyStats(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      severity,
      COUNT(*) as total,
      SUM(CASE WHEN resolved_at IS NOT NULL THEN 1 ELSE 0 END) as resolved,
      AVG(CASE WHEN resolved_at IS NOT NULL
        THEN (resolved_at - ts) / 60000.0
        ELSE NULL END) as avg_resolution_min
    FROM safety_events
    WHERE ts >= ?
    GROUP BY severity
  `).all(since) as Array<{ severity: string; total: number; resolved: number; avg_resolution_min: number }>;
}

// Monthly OEE grouped by line-cluster (Issue 14: real data split, not fabricated offset)
export function getMonthlyOeeByLineGroup(days = 180, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return getDb().prepare(`
    SELECT
      strftime('%Y-%m', ts/1000, 'unixepoch') as month,
      CASE WHEN plant_id = 'P1' THEN 'g1' ELSE 'g2' END as grp,
      AVG(oee) as avg_oee
    FROM oee_readings
    WHERE ts >= ?
    GROUP BY month, grp
    ORDER BY month ASC
  `).all(since) as Array<{ month: string; grp: string; avg_oee: number }>;
}

// Issue fix: real per-category loss aggregation (Six Big Losses were fabricated
// from fixed config weights; oee_readings has actual loss_type + loss_min)
export function getLossByType(days = 30, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const lossSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const lossArg = plant && plant !== 'All Plants' ? plant : null;
  return getDb().prepare(`
    SELECT loss_type,
           SUM(loss_min) as total_min,
           COUNT(DISTINCT machine_id) as machine_cnt,
           GROUP_CONCAT(DISTINCT machine_id) as machines
    FROM oee_readings
    WHERE ts >= ? AND loss_type IS NOT NULL AND loss_min > 0` + lossSql + `
    GROUP BY loss_type
    ORDER BY total_min DESC
  `).all(...[since, ...(lossArg ? [lossArg] : [])]) as Array<{ loss_type: string; total_min: number; machine_cnt: number; machines: string }>;
}

export function getWeeklyLossByType(days = 42, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const weekLossSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const weekLossArg = plant && plant !== 'All Plants' ? plant : null;
  return getDb().prepare(`
    SELECT strftime('%Y-%W', datetime(ts/1000, 'unixepoch')) as wk,
           loss_type,
           SUM(loss_min) as total_min
    FROM oee_readings
    WHERE ts >= ? AND loss_type IS NOT NULL AND loss_min > 0` + weekLossSql + `
    GROUP BY wk, loss_type
    ORDER BY wk ASC
  `).all(...[since, ...(weekLossArg ? [weekLossArg] : [])]) as Array<{ wk: string; loss_type: string; total_min: number }>;
}

// Issue fix: real per-shift OEE by hour-of-day bucket (was plantAvg x invented factor)
export function getOeeByHourRange(startHour: number, endHour: number, days = 7) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  // Handles overnight shifts (e.g. 22 -> 06) via OR
  const cond = startHour < endHour
    ? "CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) >= ? AND CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) < ?"
    : "(CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) >= ? OR CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) < ?)";
  const row = getDb().prepare(
    `SELECT AVG(oee) as avg_oee FROM oee_readings WHERE ts >= ? AND ${cond}`
  ).get(since, startHour, endHour) as { avg_oee: number | null };
  return row?.avg_oee != null ? +Number(row.avg_oee).toFixed(1) : null;
}
