/**
 * ManuAI — Live Data Writer
 *
 * Called by the simulation engine on every tick (every 4 seconds).
 * Writes current state to SQLite so history accumulates over time.
 *
 * Uses prepared statements cached on first call for performance.
 * Writes are non-blocking — failures logged but don't crash the engine.
 */

import { getDb } from './connection';
import { PlantState } from '../simulation/engine';
import { ingestSensorReadings, ingestEnergyReadings } from '../ingestion';
import { logger } from '../middleware/logger';

// Throttle — write OEE and health every 5 minutes to DB (not every 4 seconds)
// Alerts and safety events write immediately
const OEE_WRITE_INTERVAL_MS   = 5 * 60 * 1000;
const YIELD_WRITE_INTERVAL_MS = 5 * 60 * 1000;
const ENERGY_WRITE_INTERVAL_MS = 30 * 60 * 1000;

let lastOeeWrite   = 0;
let lastYieldWrite = 0;
let lastEnergyWrite = 0;

const writtenAlerts  = new Set<string>();
const writtenBatches = new Set<string>();
const writtenSafety  = new Set<string>();

export function writeStateToDB(state: PlantState): void {
  try {
    const db = getDb();
    const now = Date.now();

    // ── OEE + Health (every 5 min) ─────────────────────────────────────────
    if (now - lastOeeWrite >= OEE_WRITE_INTERVAL_MS) {
      const insertOee = db.prepare(`
        INSERT INTO oee_readings (plant_id, machine_id, machine_name, line, ts, oee, avail, perf, qual, loss_type, loss_min)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const insertHealth = db.prepare(`
        INSERT INTO machine_health (plant_id, machine_id, ts, health, rul, vib, temp, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);

      const writeOee = db.transaction(() => {
        for (const m of state.machines) {
          const pid = (m as any).plant ?? 'P1';
          insertOee.run(pid, m.id, m.name, m.line, now, m.oee, m.avail, m.perf, m.qual, m.loss, m.lossMin);
          insertHealth.run(pid, m.id, now, m.health, m.rul, m.vib, m.temp, m.status);
        }
      });
      writeOee();
      lastOeeWrite = now;
    }

    // ── Yield params (every 5 min) ─────────────────────────────────────────
    if (now - lastYieldWrite >= YIELD_WRITE_INTERVAL_MS) {
      const insertYield = db.prepare(`
        INSERT INTO yield_history (plant_id, param_id, param_name, ts, value, target, warn)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      const writeYield = db.transaction(() => {
        for (const p of state.yieldParams) {
          const ypid = (p as any).plant ?? 'P1';
          insertYield.run(ypid, p.id, p.name, now, p.val, p.tgt, p.warn ? 1 : 0);
        }
      });
      writeYield();
      lastYieldWrite = now;
    }

    // ── Energy (every 30 min) ─────────────────────────────────────────────
    if (now - lastEnergyWrite >= ENERGY_WRITE_INTERVAL_MS) {
      const insertEnergy = db.prepare(`
        INSERT INTO energy_readings (plant_id, asset_id, asset_name, ts, kw, anomaly)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      const writeEnergy = db.transaction(() => {
        for (const a of state.energyAssets) {
          const epid = (a as any).plant ?? 'P1';
          insertEnergy.run(epid, a.id, a.name, now, a.kw, a.anomaly ? 1 : 0);
        }
      });
      writeEnergy();
      lastEnergyWrite = now;
    }

    // ── Batch updates (whenever status changes) ────────────────────────────
    const b = state.batch;
    if (!writtenBatches.has(b.id + b.status)) {
      const bpid = (b as any).plantId ?? (String(b.product).includes('Z-04')||String(b.product).includes('PB-7') ? 'P2' : 'P1');
      db.prepare(`
        INSERT OR REPLACE INTO batches (plant_id, id, product, qty_kg, plan_yield, actual_yield, status, started_at, completed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        bpid, b.id, b.product, b.qty, b.plan,
        b.actual ?? null, b.status,
        b.startedAt,
        b.status === 'completed' ? now : null
      );
      writtenBatches.add(b.id + b.status);
    }

  } catch (err) {
    logger.warn('[DB] Write error (non-fatal)', { error: String(err) });
  }
}

export function writeAlertToDB(alert: {
  id: string; machineId: string; machineName: string; line: string;
  type: string; severity: string; message: string; ts: number; plantId?: string;
}): void {
  if (writtenAlerts.has(alert.id)) return;
  try {
    getDb().prepare(`
      INSERT OR IGNORE INTO alerts (plant_id, id, machine_id, machine_name, line, type, severity, message, ts, acked)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    `).run(alert.plantId ?? 'P1', alert.id, alert.machineId, alert.machineName, alert.line, alert.type, alert.severity, alert.message, alert.ts);
    writtenAlerts.add(alert.id);
  } catch (err) {
    logger.warn('[DB] Alert write error', { error: String(err) });
  }
}

export function writeSafetyEventToDB(event: {
  id: string; zone: string; type: string; severity: string;
  h2s: number; co: number; ch4: number; ts: number; plantId?: string;
}): void {
  if (writtenSafety.has(event.id)) return;
  try {
    const ZONE_PLANT: Record<string,string> = {'Zone A':'P1','Zone B':'P1','Zone C':'P2','Zone D':'P2'};
    const spid = ZONE_PLANT[event.zone] ?? event.plantId ?? 'P1';
    getDb().prepare(`
      INSERT OR IGNORE INTO safety_events (plant_id, id, zone, event_type, severity, h2s, co, ch4, ts)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(spid, event.id, event.zone, event.type, event.severity, event.h2s, event.co, event.ch4, event.ts);
    writtenSafety.add(event.id);
  } catch (err) {
    logger.warn('[DB] Safety event write error', { error: String(err) });
  }
}

export function ackAlertInDB(alertId: string, ackedBy: string): boolean {
  try {
    const result = getDb().prepare(`
      UPDATE alerts SET acked = 1, acked_by = ?, acked_at = ? WHERE id = ?
    `).run(ackedBy, Date.now(), alertId);
    return result.changes > 0;
  } catch (err) {
    logger.warn('[DB] Ack error', { error: String(err) });
    return false;
  }
}
