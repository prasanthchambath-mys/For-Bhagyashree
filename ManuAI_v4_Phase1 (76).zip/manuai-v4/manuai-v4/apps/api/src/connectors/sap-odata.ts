import axios from 'axios';
import { logger } from '../middleware/logger';

// Per-plant SAP plant codes:
// SAP_PLANT_CODE_P1 = '1000' (Mumbai), SAP_PLANT_CODE_P2 = '2000' (Pune)
// Falls back to SAP_PLANT_CODE for backward compatibility
export function getSapPlantCode(plantId = 'P1'): string {
  return process.env[`SAP_PLANT_CODE_${plantId}`] ?? process.env.SAP_PLANT_CODE ?? '1000';
}

const MOCK_MODE = !process.env.SAP_ODATA_BASE_URL;
if (MOCK_MODE) logger.warn('SAP_ODATA_BASE_URL not set — SAP OData running in mock mode');

// ── Mock responses ────────────────────────────────────────────────────────────
let mockWOCounter = 4842;
let mockPRCounter = 5021;
let mockQNCounter = 301;

const MOCK_PRODUCTION_ORDERS = [
  { id:'PP-88412', product:'Compound X-12 Grade A', qty:'2400 kg', plan:91.0, actual:91.3, status:'completed', start:'Apr 16 06:00', end:'Apr 16 14:00' },
  { id:'PP-88413', product:'Compound Y-07 Grade B', qty:'1800 kg', plan:89.5, actual:88.2, status:'completed', start:'Apr 16 14:00', end:'Apr 16 22:00' },
  { id:'PP-88414', product:'Compound X-12 Grade A', qty:'2400 kg', plan:91.0, actual:null,  status:'in_process',start:'Apr 17 06:00', end:'Apr 17 14:00' },
  { id:'PP-88415', product:'Compound Z-04 Grade S', qty:'900 kg',  plan:87.0, actual:null,  status:'planned',   start:'Apr 17 14:00', end:'Apr 17 18:00' },
];

const MOCK_MAINTENANCE_ORDERS = [
  { id:'WO-4841', equipment:'MCH-06', text:'Servo Drive J1 Replacement', status:'open',        priority:'1' },
  { id:'WO-4840', equipment:'MCH-03', text:'Spindle Bearing Replacement', status:'in_progress', priority:'1' },
  { id:'WO-4839', equipment:'CMP-001',text:'Piston Ring Inspection',      status:'scheduled',   priority:'2' },
];

// ── OAuth token cache (live mode only) ────────────────────────────────────────
let cachedToken: { value: string; expires: number } | null = null;

async function getToken(): Promise<string> {
  if (MOCK_MODE) return 'mock-token';
  if (cachedToken && Date.now() < cachedToken.expires - 30_000) return cachedToken.value;
  const res = await axios.post(process.env.SAP_OAUTH_TOKEN_URL!, new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: process.env.SAP_OAUTH_CLIENT_ID!,
    client_secret: process.env.SAP_OAUTH_CLIENT_SECRET!,
  }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
  cachedToken = { value: res.data.access_token, expires: Date.now() + res.data.expires_in * 1000 };
  return cachedToken.value;
}

async function sapGet<T>(path: string, params?: Record<string, string>): Promise<T> {
  const token = await getToken();
  const res = await axios.get(`${process.env.SAP_ODATA_BASE_URL}${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
    params: { $format: 'json', ...params },
    timeout: 12_000,
  });
  return (res.data.value ?? res.data) as T;
}

async function sapPost<T>(path: string, body: unknown): Promise<T> {
  const token = await getToken();
  const csrfRes = await axios.get(`${process.env.SAP_ODATA_BASE_URL}/`, {
    headers: { Authorization: `Bearer ${token}`, 'X-CSRF-Token': 'Fetch' },
  });
  const res = await axios.post(`${process.env.SAP_ODATA_BASE_URL}${path}`, body, {
    headers: {
      Authorization: `Bearer ${token}`,
      'X-CSRF-Token': csrfRes.headers['x-csrf-token'],
      'Content-Type': 'application/json',
    },
    timeout: 15_000,
  });
  return res.data as T;
}

// ── Public API ────────────────────────────────────────────────────────────────

export async function getProductionOrders(plant?: string, plantId = 'P1') {
  const sapPlant = plant ?? getSapPlantCode(plantId);
  if (MOCK_MODE) return MOCK_PRODUCTION_ORDERS;
  return sapGet('/PP_PROD_ORDER_SRV/A_ProductionOrder', {
    $filter: `Plant eq '${plant}'`, $top: '50', $orderby: 'ScheduledStartDate desc',
  });
}

export async function getMaterialStock(materials: string[]) {
  if (MOCK_MODE) return materials.map(m => ({ Material: m, UnrestrictedQty: Math.floor(Math.random() * 500 + 50), Plant: '1000' }));
  const filter = materials.map(m => `Material eq '${m}'`).join(' or ');
  return sapGet('/API_MATERIAL_STOCK_SRV/A_MatlStkInAcctMod', { $filter: filter });
}

export async function createPurchaseRequisition(payload: {
  material: string; plant: string; quantity: number; text: string; deliveryDate: string;
}) {
  if (MOCK_MODE) {
    const id = `PR-${mockPRCounter++}`;
    logger.info(`[MOCK] SAP MM: purchase requisition created ${id}`, payload);
    return { PurchaseRequisition: id };
  }
  logger.info('SAP MM: creating purchase requisition', { material: payload.material });
  return sapPost<{ PurchaseRequisition: string }>('/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionHeader', {
    Material: payload.material, Plant: payload.plant,
    PurgDocOrderQuantity: String(payload.quantity),
    PurReqnDescription: payload.text, DeliveryDate: payload.deliveryDate,
  });
}

export async function createMaintenanceNotification(payload: {
  equipment: string; text: string; priority?: string;
}) {
  if (MOCK_MODE) {
    const id = `WO-${mockWOCounter++}`;
    logger.info(`[MOCK] SAP PM: maintenance notification created ${id}`, payload);
    return { MaintenanceNotification: id };
  }
  logger.info('SAP PM: creating notification', { equipment: payload.equipment });
  return sapPost<{ MaintenanceNotification: string }>('/PM_NOTIFICATION_SRV/A_MaintNotification', {
    NotifType: 'M1', Equipment: payload.equipment,
    NotifText: payload.text, PriorityType: payload.priority ?? '2',
  });
}

export async function getMaintenanceOrders(plant?: string, plantId = 'P1') {
  const sapPlant = plant ?? getSapPlantCode(plantId);
  if (MOCK_MODE) return MOCK_MAINTENANCE_ORDERS;
  return sapGet('/PM_ORDER_SRV/A_MaintenanceOrder', {
    $filter: `Plant eq '${plant}' and MaintenanceOrderStatus ne 'TECO'`, $top: '30',
  });
}

export async function createNonconformanceReport(payload: {
  material: string; plant: string; text: string; defectCode?: string;
}) {
  if (MOCK_MODE) {
    const id = `QN-${mockQNCounter++}`;
    logger.info(`[MOCK] SAP QM: NCR created ${id}`, payload);
    return { QualityNotification: id };
  }
  logger.info('SAP QM: creating NCR', { material: payload.material });
  return sapPost<{ QualityNotification: string }>('/API_QUALNOTIFICATION_SRV/A_QualNotification', {
    NotifType: 'Q1', Material: payload.material, Plant: payload.plant, NotifText: payload.text,
  });
}

export async function checkSAPHealth(): Promise<boolean> {
  if (MOCK_MODE) return true;
  try { await getToken(); return true; } catch { return false; }
}
