import React,{createContext,useContext,useState,useEffect,useMemo,useCallback} from 'react';
import{useStore}from'./store';
import{
  fetchMachines,fetchUtilities,fetchPlatformConfig,fetchTechStack,fetchSemanticKpiDefs,
  fetchPersonas,fetchBaselines,fetchPdmRules,fetchEnergyWaste,fetchCarbonTrend,
  fetchSupplyRisks,fetchDemandForecast,fetchQualityDefects,fetchSafetyEvents,
  fetchSafetyPermits,fetchTwinScenarios,fetchDivergenceLog,fetchQualityLines,
  fetchEnergyAssets,fetchEnergyTrend,fetchWorkOrders,fetchShifts,fetchOeeTrend,
  fetchSixLosses,fetchLossTrend,fetchOeeScorecard,fetchRulTrend,fetchLims,
  fetchDcsSetpoints,fetchProductionOrders
}from'./csvApi';

export interface AppState {
  // Agent data arrays
  energyWaste:any[]; carbonTrend:any[]; supplyRisksData:any[];
  demandForecast:any[]; defectTrend:any[]; defectLog:any[];
  safetyEvents:any[]; ptwList:any[]; twinScenarios:any[];
  divergenceLog:any[]; qualityLines:any[]; energyAssets:any[];
  energyTrend:any[]; pdmRules:any[];
  // OEE/PdM/Yield data
  mch:any[]; util:any[]; wos:any[]; shifts:any[];
  oeeTrend:any[]; sixLosses:any[]; lossTrend:any[];
  oeeScorecard:any[]; rulTrend:any[];
  lims:any[]; dcs:any[]; sapOrders:any[];
  // Config
  appCfg:any; baselines:any; personasCfg:any; techStacks:any; semanticDefs:any[];
  // Live computed from store
  agsMachines:any[]; agsOee:number; critical:number; agsYield:any[];
  crossEvents:any[];
  // shared config ref
  _sharedCfg:{cfg:any,appCfg:any,baselines:any,techStacks:any};
}

const SC:{cfg:any,appCfg:any,baselines:any,techStacks:any}=
  {cfg:{},appCfg:{},baselines:{},techStacks:{}};

const defaultState:AppState={
  energyWaste:[],carbonTrend:[],supplyRisksData:[],demandForecast:[],
  defectTrend:[],defectLog:[],safetyEvents:[],ptwList:[],
  twinScenarios:[],divergenceLog:[],qualityLines:[],energyAssets:[],
  energyTrend:[],pdmRules:[],
  mch:[],util:[],wos:[],shifts:[],
  oeeTrend:[],sixLosses:[],lossTrend:[],oeeScorecard:[],rulTrend:[],
  lims:[],dcs:[],sapOrders:[],
  appCfg:{},baselines:{},personasCfg:{},techStacks:{},semanticDefs:[],
  agsMachines:[],agsOee:0,critical:0,agsYield:[],crossEvents:[],
  _sharedCfg:SC,
};

export const AppCtx=createContext<AppState>(defaultState);
export function useApp(){return useContext(AppCtx);}

export function AppProvider({children}:{children:React.ReactNode}){
  const{machines:agsMachines,yieldParams:agsYield,crossEvents}=useStore();
  const agsOee=agsMachines.length
    ?+((agsMachines as any[]).reduce((s:number,m:any)=>s+Number(m.oee??0),0)/(agsMachines as any[]).length).toFixed(1)
    :0;
  const critical=(agsMachines as any[]).filter((m:any)=>m.status==='critical').length;

  const[energyWaste,setEnergyWaste]=useState<any[]>([]);
  const[carbonTrend,setCarbonTrend]=useState<any[]>([]);
  const[supplyRisksData,setSupplyRisksData]=useState<any[]>([]);
  const[demandForecast,setDemandForecast]=useState<any[]>([]);
  const[defectTrend,setDefectTrend]=useState<any[]>([]);
  const[defectLog,setDefectLog]=useState<any[]>([]);
  const[safetyEvents,setSafetyEvents]=useState<any[]>([]);
  const[ptwList,setPtwList]=useState<any[]>([]);
  const[twinScenarios,setTwinScenarios]=useState<any[]>([]);
  const[divergenceLog,setDivergenceLog]=useState<any[]>([]);
  const[qualityLines,setQualityLines]=useState<any[]>([]);
  const[energyAssets,setEnergyAssets]=useState<any[]>([]);
  const[energyTrend,setEnergyTrend]=useState<any[]>([]);
  const[appCfg,setAppCfg]=useState<any>({});
  const[techStacks,setTechStacks]=useState<any>({});
  const[semanticDefs,setSemanticDefs]=useState<any[]>([]);
  const[personasCfg,setPersonasCfg]=useState<any>({});
  const[baselines,setBaselines]=useState<any>({});
  const[pdmRules,setPdmRules]=useState<any[]>([]);
  // OEE/PdM/Yield local data
  const[mch,setMch]=useState<any[]>([]);
  const[util,setUtil]=useState<any[]>([]);
  const[wos,setWos]=useState<any[]>([]);
  const[shifts,setShifts]=useState<any[]>([]);
  const[oeeTrend,setOeeTrend]=useState<any[]>([]);
  const[sixLosses,setSixLosses]=useState<any[]>([]);
  const[lossTrend,setLossTrend]=useState<any[]>([]);
  const[oeeScorecard,setOeeScorecard]=useState<any[]>([]);
  const[rulTrend,setRulTrend]=useState<any[]>([]);
  const[lims,setLims]=useState<any[]>([]);
  const[dcs,setDcs]=useState<any[]>([]);
  const[sapOrders,setSapOrders]=useState<any[]>([]);

  // Issue fix: plant selector — must be declared before useEffect that depends on it
  const plantSel=useStore(s=>s.plant);

  // Keep SC in sync
  SC.appCfg=appCfg; SC.cfg=appCfg; SC.baselines=baselines; SC.techStacks=techStacks;

  useEffect(()=>{
    const delay=(ms:number,fn:()=>void)=>setTimeout(fn,ms);
    const cleanupFns: Array<()=>void> = [];
    // Batch 1 — critical config + quality (immediate, highest priority)
    fetchPlatformConfig().then(d=>{setAppCfg(d);SC.appCfg=d;SC.cfg=d;}).catch(()=>{});
    fetchBaselines(plantSel).then(d=>{setBaselines(d??{});SC.baselines=d??{};}).catch(()=>{});
    fetchMachines(plantSel).then(d=>{setMch(d??[]);}).catch(()=>{});
    // Quality defects loaded immediately — critical for dashboard.
    // Also polled every 30s so the Quality dashboard shows fresh defects
    // (was previously polled by QualityDash; consolidated here to remove duplicate fetches).
    const loadQuality=()=>fetch(`/api/quality/defects?plant=${encodeURIComponent(plantSel)}`).then(r=>r.json()).then((res:any)=>{
      setDefectLog(res.log??[]);
      setDefectTrend(res.trend??[]);
    }).catch(()=>{});
    loadQuality();
    const qualityIv=setInterval(loadQuality,30000);
    cleanupFns.push(()=>clearInterval(qualityIv));
    // Batch 2 — OEE/PdM data (100ms delay)
    delay(100,()=>{
      fetchOeeTrend(30,plantSel).then(d=>{setOeeTrend(d??[]);}).catch(()=>{});
      fetchSixLosses(7,plantSel).then(d=>{setSixLosses(d??[]);}).catch(()=>{});  // 7-day rolling window
      fetchLossTrend(7,plantSel).then(d=>{setLossTrend(d??[]);}).catch(()=>{});
      fetchRulTrend(14,plantSel).then(d=>{setRulTrend(d??[]);}).catch(()=>{});
      fetchWorkOrders(plantSel).then(d=>{setWos(d??[]);}).catch(()=>{});
    });
    // Batch 3 — Quality/Supply/Energy (250ms delay)
    delay(250,()=>{
      // Quality defects already loaded in Batch 1
      fetchQualityLines(plantSel).then(d=>{setQualityLines(d??[]);}).catch(()=>{});
      fetchSupplyRisks(plantSel).then(d=>{setSupplyRisksData(d??[]);}).catch(()=>{});
      fetchEnergyWaste(plantSel).then(d=>{setEnergyWaste(d??[]);}).catch(()=>{});
      fetchEnergyAssets(plantSel).then(d=>{setEnergyAssets(d??[]);}).catch(()=>{});
      // Issue fix: energy assets are live (sim ticks kW/anomaly) — poll every 5s
      const energyIv=setInterval(()=>{fetchEnergyAssets(plantSel).then(d=>{setEnergyAssets(d??[]);}).catch(()=>{});},10000);
      cleanupFns.push(()=>clearInterval(energyIv));
    });
    // Batch 4 — Safety/Twin/Yield/Config (450ms delay)
    delay(450,()=>{
      fetchSafetyEvents(7,plantSel).then(d=>{setSafetyEvents(d??[]);}).catch(()=>{}); // 7 days for sufficient event history
      fetchSafetyPermits(plantSel).then(d=>{setPtwList(d??[]);}).catch(()=>{});
      fetchTwinScenarios(plantSel).then(d=>{setTwinScenarios(d??[]);}).catch(()=>{});
      fetchDivergenceLog(plantSel).then(d=>{setDivergenceLog(d??[]);}).catch(()=>{});
      fetchCarbonTrend(plantSel).then(d=>{setCarbonTrend(d??[]);}).catch(()=>{});
      fetchDemandForecast(plantSel).then(d=>{setDemandForecast(d??[]);}).catch(()=>{});
    });
    // Batch 5 — Secondary config (650ms delay)
    delay(650,()=>{
      fetchTechStack().then(d=>{if(Object.keys(d).length){setTechStacks(d);SC.techStacks=d;}}).catch(()=>{});
      fetchSemanticKpiDefs().then(d=>{if(d.length)setSemanticDefs(d);}).catch(()=>{});
      fetchPersonas().then(d=>{if(Object.keys(d).length)setPersonasCfg(d);}).catch(()=>{});
      fetchPdmRules().then(d=>{if(d.length)setPdmRules(d);}).catch(()=>{});
      fetchUtilities(plantSel).then(d=>{setUtil(d??[]);}).catch(()=>{});
      fetchShifts(plantSel).then(d=>{setShifts(d??[]);}).catch(()=>{});
      fetchOeeScorecard(plantSel).then(d=>{setOeeScorecard(d??[]);}).catch(()=>{});
      fetchLims(plantSel).then(d=>{setLims(d??[]);}).catch(()=>{});
      fetchDcsSetpoints(plantSel).then(d=>{setDcs(d??[]);}).catch(()=>{});
      fetchProductionOrders(plantSel).then(d=>{setSapOrders(d??[]);}).catch(()=>{});
      fetchEnergyTrend(1,plantSel).then(d=>{setEnergyTrend((d??[]).map((r:any)=>({h:r.day?.slice(11,16)??r.day,kw:Number(r.total_kw??r.avg_kw??0)})));}).catch(()=>{});
    });
    return()=>{cleanupFns.forEach(fn=>fn());};
  },[plantSel]);

  const mchFiltered=useMemo(()=>plantSel==='All Plants'?mch:mch.filter((m:any)=>m.plant===(plantSel==='Plant 1'?'P1':'P2')),[mch,plantSel]);
  const value:AppState={
    energyWaste,carbonTrend,supplyRisksData,demandForecast,
    defectTrend,defectLog,safetyEvents,ptwList,
    twinScenarios,divergenceLog,qualityLines,energyAssets,
    energyTrend,pdmRules,
    mch:mchFiltered,util,wos,shifts,
    oeeTrend,sixLosses,lossTrend,oeeScorecard,rulTrend,
    lims,dcs,sapOrders,
    appCfg,baselines,personasCfg,techStacks,semanticDefs,
    agsMachines:agsMachines as any[],agsOee,critical,
    agsYield:agsYield as any[],crossEvents:crossEvents as any[],
    _sharedCfg:SC,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
