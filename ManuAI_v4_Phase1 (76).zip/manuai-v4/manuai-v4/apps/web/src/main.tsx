import React, { useEffect, Suspense, lazy } from 'react';
import ReactDOM from 'react-dom/client';
import { useStore } from './store';
import { useDevAuth } from './hooks';
import { ErrorBoundary } from './ErrorBoundary';

// Lazy-load App. App.tsx statically imports recharts (~540 KB), so deferring
// App lets the browser paint the shell HTML immediately while the chart bundle
// streams in. Reduces time-to-first-paint substantially on slow connections.
const App = lazy(() => import('./App'));

function LoadingShell() {
  return (
    <div style={{
      fontFamily: "'Inter','Segoe UI',system-ui,sans-serif",
      height: '100vh', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: 16,
      background: '#f5f6fa', color: '#1a1a2e'
    }}>
      <div style={{ fontSize: 22, fontWeight: 900, letterSpacing: 0.5 }}>
        <span style={{ color: '#1565c0' }}>Manu</span><span style={{ color: '#00695c' }}>AI</span>
      </div>
      <div style={{ fontSize: 13, color: '#546e7a' }}>Loading manufacturing intelligence platform…</div>
      <div style={{ width: 220, height: 3, background: '#e0e0e0', borderRadius: 2, overflow: 'hidden' }}>
        <div style={{ width: '40%', height: '100%', background: '#1565c0',
          animation: 'manuai-pulse 1.2s ease-in-out infinite' }} />
      </div>
      <style>{`@keyframes manuai-pulse { 0%{margin-left:0} 100%{margin-left:60%} }`}</style>
    </div>
  );
}

function Root() {
  useDevAuth();
  const initWebSocket = useStore(s => s.initWebSocket);
  useEffect(() => { initWebSocket(); }, []);
  return (
    <Suspense fallback={<LoadingShell />}>
      <App />
    </Suspense>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <Root />
    </ErrorBoundary>
  </React.StrictMode>,
);

// ── Production: wrap Root in MsalProvider ─────────────────────
// import { PublicClientApplication } from '@azure/msal-browser';
// import { MsalProvider } from '@azure/msal-react';
// const pca = new PublicClientApplication({
//   auth: {
//     clientId: import.meta.env.VITE_AZURE_CLIENT_ID,
//     authority: `https://login.microsoftonline.com/${import.meta.env.VITE_AZURE_TENANT_ID}`,
//     redirectUri: window.location.origin,
//   },
// });
// ReactDOM.createRoot(document.getElementById('root')!).render(
//   <MsalProvider instance={pca}><Root /></MsalProvider>
// );
