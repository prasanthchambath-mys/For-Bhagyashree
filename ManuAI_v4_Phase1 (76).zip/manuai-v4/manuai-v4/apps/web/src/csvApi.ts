/**
 * ManuAI — CSV Data API
 *
 * All frontend data comes from the backend API which reads CSV files.
 * Edit any CSV in data/csv/ folder → restart → changes appear here.
 *
 * REPLACE WITH comments show where real system connectors go in Phase 3.
 */

import api from './api';

// ── Machines (machines.csv → /api/pdm/assets) ─────────────────────────────
export async function fetchMachines(plant='All Plants') {
  const r = await api.get(`/api/pdm/assets?plant=${encodeURIComponent(plant)}`);
  return (r.data.assets ?? []).map((m: any) => ({
    id:       m.id,
    name:     m.name,
    line:     m.line,
    plant:    m.plant ?? 'P1',
    oee:      Number(m.oee),
    avail:    Number(m.avail),
    perf:     Number(m.perf),
    qual:     Number(m.qual),
    health:   Number(m.health),
    rul:      Number(m.rul),
    status:   m.status,
    loss:     m.loss,
    lossMin:  Number(m.lossMin ?? m.loss_min ?? 0),
    vib:      Number(m.vib),
    temp:     Number(m.temp),
  }));
}

// ── Utilities (utilities.csv → /api/pdm/assets) ───────────────────────────
export async function fetchUtilities(plant='All Plants') {
  const r = await api.get(`/api/pdm/assets?plant=${encodeURIComponent(plant)}`);
  return (r.data.utilityAssets ?? []).map((u: any) => ({
    id:      u.id,
    name:    u.name,
    type:    'Utility',
    health:  Number(u.health),
    rul:     Number(u.rul),
    status:  u.status,
    vib:     Number(u.vib),
    temp:    Number(u.temp),
    press:   Number(u.pressure ?? 0),
    oeeLink: u.oeeLink ?? null,
  }));
}

// ── Yield Params (yield_params.csv → /api/yield/params) ───────────────────
export async function fetchYieldParams(plant='All Plants') {
  const r = await api.get(`/api/yield/params?plant=${encodeURIComponent(plant)}`);
  return (r.data.params ?? []).map((p: any) => ({
    id:      p.id,
    name:    p.name,
    val:     Number(p.val ?? p.value),
    tgt:     Number(p.tgt ?? p.target),
    unit:    p.unit,
    min:     Number(p.min),
    max:     Number(p.max),
    warn:    Boolean(p.warn),
    blocked: Boolean(p.blocked),
  }));
}

// ── DCS Set-points (yield_params.csv → /api/yield/params) ─────────────────
export async function fetchDcsSetpoints(plant='All Plants') {
  const r = await api.get(`/api/yield/params?plant=${encodeURIComponent(plant)}`);
  return (r.data.dcs ?? r.data.params ?? []).map((p: any) => ({
    tag:      p.id,
    desc:     p.name,
    cur:      Number(p.val ?? p.value),
    rec:      Number(p.tgt ?? p.target),
    unit:     p.unit,
    status:   p.blocked ? 'blocked' : p.warn ? 'pending' : 'ok',
    delta:    ((Number(p.tgt ?? p.target) - Number(p.val ?? p.value)) >= 0 ? '+' : '') +
              (Number(p.tgt ?? p.target) - Number(p.val ?? p.value)).toFixed(1),
    impact:   p.impact ?? '—',
    blockedBy: p.blocked_by ?? null,
  }));
}

// ── LIMS Results (lims_results.csv → /api/yield/lims) ─────────────────────
export async function fetchLims(plant='All Plants') {
  const r = await api.get(`/api/yield/lims?plant=${encodeURIComponent(plant)}`);
  return (r.data.results ?? []).map((l: any) => ({
    id:      l.id,
    time:    l.time,
    batch:   l.batch,
    test:    l.test,
    result:  l.result,
    limit:   l.limit,
    status:  l.status,
    analyst: l.analyst,
  }));
}

// ── Production Orders (production_orders.csv → /api/yield/orders) ─────────
export async function fetchProductionOrders(plant='All Plants') {
  const r = await api.get(`/api/yield/orders?plant=${encodeURIComponent(plant)}`);
  return (r.data.orders ?? []).map((o: any) => ({
    id:      o.id,
    product: o.product,
    qty:     o.qty_kg ? `${Number(o.qty_kg).toLocaleString()} kg` : o.qty,
    start:   o.start_date ?? o.start,
    end:     o.end_date ?? o.end,
    status:  o.status,
    actual:  o.actual!=null ? Number(o.actual) : (o.actual_yield!=null ? Number(o.actual_yield) : null),
    plan:    Number(o.plan_yield ?? o.plan ?? 0),
  }));
}

// ── Work Orders (work_orders.csv → /api/pdm/workorders) ───────────────────
export async function fetchWorkOrders(plant='All Plants') {
  const r = await api.get(`/api/pdm/workorders?plant=${encodeURIComponent(plant)}`);
  return (r.data.orders ?? r.data.workorders ?? []).map((w: any) => ({
    id:       w.id,
    name:     w.name ?? w.id,
    asset:    w.asset_name ?? w.asset,
    type:     w.type,
    pri:      w.pri ?? w.priority,
    desc:     w.desc ?? w.description,
    status:   w.status,
    assignee: w.assigned ?? w.assigned_to ?? w.assignee,
    oeeLink:  w.oeeLink ?? w.oee_link ?? false,
  }));
}

// ── Supply Risks (supply_risks.csv → /api/supply/risks) ───────────────────
export async function fetchSupplyRisks(plant='All Plants') {
  const r = await api.get(`/api/supply/risks?plant=${encodeURIComponent(plant)}`);
  // Issue 10 fix: prefer server-scored; fallback computes locally (identical logic)
  if (Array.isArray(r.data.scored) && r.data.scored.length) return r.data.scored;
  return (r.data.risks ?? []).map((s: any) => {
    const leadDrift = Number(s.lead_time_actual_days ?? 0) - Number(s.lead_time_contracted_days ?? 0);
    const stockDays = Number(s.current_stock_days ?? 0);
    const risk = stockDays < 14 ? 'critical' : stockDays < 30 ? 'high' : 'medium';
    return {
      supplier:  s.supplier_name,
      sku:       s.sku,
      desc:      s.description,
      risk,
      stockDays,
      leadDrift,
      exposure:  s.monthly_consumption ? `\u20b9${(Number(s.monthly_consumption) * Number(s.unit_cost_inr ?? 0) / 100000).toFixed(1)}L/mo` : '\u2014',
      reason:    s.financial_risk_score > 6 ? 'Financial distress' : s.country_of_origin !== 'Germany' && s.single_source === 'true' ? 'Geopolitical risk' : 'Lead time drift',
      action:    stockDays < 14 ? 'Emergency PO required' : 'Expedite delivery',
    };
  });
}

export async function fetchTwinKPIs() {
  const r = await api.get('/api/twin/status');
  return (r.data.kpis ?? []).map((k: any) => ({
    id:        k.kpi_id ?? k.id,
    name:      k.kpi_name ?? k.name,
    unit:      k.unit,
    actual:    Number(k.actual),
    predicted: Number(k.twin_predicted ?? k.predicted),
    threshold: Number(k.divergence_threshold_pct ?? k.threshold ?? 2),
    asset:     k.asset_id ?? k.asset,
    diverging: Math.abs(Number(k.actual) - Number(k.twin_predicted ?? k.predicted)) >
               Number(k.divergence_threshold_pct ?? 2),
  }));
}

// ── Alerts (SQLite DB → /api/oee/alerts) ──────────────────────────────────
export async function fetchAlerts(plant='All Plants') {
  const r = await api.get(`/api/oee/alerts?plant=${encodeURIComponent(plant)}`);
  return r.data.alerts ?? [];
}

// ── OEE Trend (SQLite history → /api/history/oee/plant-trend) ─────────────
export async function fetchOeeTrend(days = 30, plant='All Plants') {
  const r = await api.get(`/api/history/oee/plant-trend?days=${days}&plant=${encodeURIComponent(plant)}`);
  return (r.data.data ?? []).map((d: any) => ({
    day:    d.day,
    oee:    +Number(d.avg_oee).toFixed(1),
    avail:  +Number(d.avg_avail).toFixed(1),
    perf:   +Number(d.avg_perf).toFixed(1),
    qual:   +Number(d.avg_qual).toFixed(1),
    yld:    d.avg_yield  != null ? +Number(d.avg_yield).toFixed(1)  : null,
    health: d.avg_health != null ? +Number(d.avg_health).toFixed(1) : null,
    target: 85,
  }));
}

// ── OEE Summary / Scorecard (SQLite → /api/history/oee/summary) ───────────
export async function fetchOeeSummary(days = 30) {
  const r = await api.get(`/api/history/oee/summary?days=${days}`);
  return r.data.data ?? [];
}

// ── Six Big Losses (computed from OEE summary) ─────────────────────────────
export async function fetchSixLosses(days = 30, plant='All Plants') {
  // Server-side computed (weights from platform_config.csv) — Issue 13 fix
  const r = await api.get(`/api/history/oee/six-losses?days=${days}&plant=${encodeURIComponent(plant)}`);
  return r.data.losses ?? [];
}

// ── Loss Trend by week (computed from plant trend) ─────────────────────────
export async function fetchLossTrend(days = 30, plant='All Plants') {
  // Server-side computed (multipliers from platform_config.csv) — Issue 13 fix
  const r = await api.get(`/api/history/oee/loss-trend?days=${days}&plant=${encodeURIComponent(plant)}`);
  return r.data.weeks ?? [];
}

// ── RUL Trend for critical machines (SQLite health history) ────────────────
export async function fetchRulTrend(days = 14, plant='All Plants') {
  // Issue fix: derive the 3 most-critical assets live (was hardcoded MCH-03/MCH-06/CMP-001)
  let ids = ['MCH-03', 'MCH-06', 'CMP-001'];
  let names: Record<string,string> = {};
  try {
    const a = await api.get(`/api/pdm/assets?plant=${encodeURIComponent(plant)}`);
    const all = [...(a.data.assets ?? []), ...(a.data.utilityAssets ?? [])]
      .sort((x: any, y: any) => Number(x.rul) - Number(y.rul));
    if (all.length >= 3) { ids = all.slice(0, 3).map((m: any) => m.id); }
    for (const m of all) names[m.id] = m.name;
  } catch { /* keep defaults */ }
  const [m3, m6, cmp] = await Promise.all(ids.map(id =>
    api.get(`/api/history/pdm/health/${id}?days=${days}`)));
  const m3data  = m3.data.data  ?? [];
  const m6data  = m6.data.data  ?? [];
  const cmpdata = cmp.data.data ?? [];

  // Sample every 24h
  const sample = (arr: any[]) => arr.filter((_: any, i: number) => i % 288 === 0);
  const s3 = sample(m3data); const s6 = sample(m6data); const sc = sample(cmpdata);
  const len = Math.max(s3.length, s6.length, sc.length);

  const rows = Array.from({ length: Math.min(len, 10) }, (_, i) => ({
    d:   s3[i]?.time?.slice(5, 10) ?? `D${i+1}`,
    m3:  s3[i]  ? +Number(s3[i].rul).toFixed(0)  : null,
    m6:  s6[i]  ? +Number(s6[i].rul).toFixed(0)  : null,
    cmp: sc[i]  ? +Number(sc[i].rul).toFixed(0)  : null,
  }));
  // Attach legend metadata so the chart labels match the plotted assets
  (rows as any).meta = { m3: names[ids[0]] ?? ids[0], m6: names[ids[1]] ?? ids[1], cmp: names[ids[2]] ?? ids[2] };
  return rows;
}

// ── Sensor history for PdM chart (last 24h from health history) ────────────
export async function fetchSensorHistory(machineId: string) {
  const r = await api.get(`/api/history/pdm/health/${machineId}?days=2`);
  const data: any[] = r.data.data ?? [];
  // Take last 24 readings (one per hour approx)
  const hourly = data.filter((_: any, i: number) => i % 12 === 0).slice(-24);
  return hourly.map((d: any) => ({
    t:   d.time?.slice(11, 16) ?? '00:00',
    vib: +Number(d.vib).toFixed(2),
    tmp: +Number(d.temp).toFixed(1),
  }));
}

// ── OEE Scorecard — monthly summary ───────────────────────────────────────
export async function fetchOeeScorecard(plant='All Plants') {
  // Real line-group split (Lines A+B vs C+D) computed server-side — Issue 14 fix
  const r = await api.get(`/api/history/oee/scorecard?days=180&plant=${encodeURIComponent(plant)}`);
  return r.data.scorecard ?? [];
}

// ── Scatter data (health vs OEE) from OEE summary ──────────────────────────
export async function fetchScatterData() {
  // Issue 15 fix: real health from PdM health-summary joined with OEE summary
  const [oeeR, healthR] = await Promise.all([
    api.get('/api/history/oee/summary?days=7'),
    api.get('/api/history/pdm/health-summary'),
  ]);
  const healthMap: Record<string, any> = {};
  for (const h of (healthR.data.data ?? [])) healthMap[h.machine_id] = h;
  return (oeeR.data.data ?? []).map((m: any) => {
    const h = healthMap[m.machine_id] ?? {};
    return {
      name:   m.machine_name,
      health: +Number(h.avg_health ?? m.avg_oee).toFixed(1),
      oee:    +Number(m.avg_oee).toFixed(1),
      rul:    Math.round(Number(h.avg_health ?? 50)),
      size:   Math.round(Number(h.avg_health ?? 50)),
    };
  });
}

export async function fetchShifts(plant='All Plants') {
  const r = await api.get(`/api/history/oee/shifts?plant=${encodeURIComponent(plant)}`);
  return r.data.data ?? [];
}

// ── Twin Components (CSV → /api/twin/components) ───────────────────────────
export async function fetchTwinComponents(plant='All Plants') {
  const r = await api.get(`/api/twin/components?plant=${encodeURIComponent(plant)}`);
  return r.data.components ?? {};
}

// ── Parts (CSV → /api/pdm/parts) ─────────────────────────────────────────
export async function fetchParts(plant='All Plants') {
  const r = await api.get(`/api/pdm/parts?plant=${encodeURIComponent(plant)}`);
  return { orders: r.data.orders ?? [], inventory: r.data.inventory ?? [] };
}

// Issue fix: real maintenance parts spend (parts.csv), not electricity cost
export async function fetchPartsSpend(plant='All Plants') {
  const r = await api.get(`/api/pdm/parts-spend?plant=${encodeURIComponent(plant)}`);
  return r.data.data ?? [];
}

// ── Platform Config (platform_config.csv → /api/config) ───────────────────
// Edit platform_config.csv in Excel → restart → all values update in UI
// ── Per-plant config from DB ─────────────────────────────────────────────────
export async function fetchPlantConfig(plantId: string) {
  const r = await api.get(`/api/config/plant/${plantId}`);
  return (r.data.config ?? {}) as Record<string, {value:string, label:string, unit:string}>;
}

export async function fetchAllPlants() {
  const r = await api.get('/api/config/plants');
  return (r.data.plants ?? []) as Array<{
    plant_id:string, plant_name:string, location:string, timezone:string, currency:string,
    oee_target:string, sap_plant_code:string, energy_tariff_rs:string, yield_target:string, pi_server_name:string
  }>;
}

export async function fetchPlatformConfig() {
  const r = await api.get('/api/config');
  return r.data;
}

// ── Energy Waste (energy_waste.csv → /api/energy/waste) ───────────────────
export async function fetchEnergyWaste(plant='All Plants') {
  const r = await api.get(`/api/energy/waste?plant=${encodeURIComponent(plant)}`);
  return r.data.waste ?? [];
}

// ── Carbon Trend (carbon_trend.csv → /api/energy/carbon) ─────────────────
export async function fetchCarbonTrend(plant='All Plants') {
  const r = await api.get(`/api/energy/carbon?plant=${encodeURIComponent(plant)}`);
  return r.data.data ?? [];
}

// ── Demand Forecast (demand_forecast.csv → /api/supply/forecast) ──────────
// Issue fix: this is supply-domain data — use the supply route (was wrongly
// routed through the energy router; that endpoint remains for back-compat).
export async function fetchDemandForecast(plant='All Plants') {
  const r = await api.get(`/api/supply/forecast?plant=${encodeURIComponent(plant)}`);
  return r.data.forecast ?? r.data.data ?? [];
}

// ── Energy Dispatch (energy_dispatch.csv → /api/energy/dispatch) ──────────
export async function fetchEnergyDispatch(plant='All Plants') {
  const r = await api.get(`/api/energy/dispatch?plant=${encodeURIComponent(plant)}`);
  return r.data.actions ?? [];
}

// ── Twin Scenarios (twin_scenarios.csv → /api/twin/scenarios) ─────────────
export async function fetchTwinScenarios(plant='All Plants') {
  const r = await api.get(`/api/twin/scenarios?plant=${encodeURIComponent(plant)}`);
  return r.data.scenarios ?? [];
}

// ── Twin Divergence (twin_kpis.csv → /api/twin/divergence) ────────────────
export async function fetchDivergenceLog(plant='All Plants') {
  // Try divergence-detail first (richer: includes action, source_mode)
  // Falls back to /divergence which has kpi/actual/twin/delta/status
  try {
    const r = await api.get(`/api/twin/divergence-detail?plant=${encodeURIComponent(plant)}`);
    const data = r.data.divergence ?? r.data.data ?? [];
    if (data.length) return data;
  } catch { /* fallback */ }
  const r = await api.get(`/api/twin/divergence?plant=${encodeURIComponent(plant)}`);
  return r.data.divergence ?? r.data.data ?? [];
}

// ── Quality Defects + Trend (quality_defects.csv → /api/quality/defects) ──
export async function fetchQualityDefects(plant='All Plants') {
  const r = await api.get(`/api/quality/defects?plant=${encodeURIComponent(plant)}`);
  return { log: r.data.log ?? [], trend: r.data.trend ?? [] };
}

// ── Quality Lines (quality_lines.csv → /api/quality/lines) ───────────────
export async function fetchQualityLines(plant='All Plants') {
  const r = await api.get(`/api/quality/lines?plant=${encodeURIComponent(plant)}`);
  return (r.data.lines ?? []).map((l: any) => ({
    line:    l.line,
    rate:    Number(l.rate ?? l.quality_rate_pct ?? 0),
    defects: Number(l.defects_today ?? l.defects ?? 0),
    escapes: Number(l.escapes_today ?? l.escapes ?? 0),
    model:   l.model_version ?? l.model ?? '',
  }));
}

// ── Safety Permits (safety_permits.csv → /api/safety/permits) ─────────────
export async function fetchSafetyPermits(plant='All Plants') {
  const r = await api.get(`/api/safety/permits?plant=${encodeURIComponent(plant)}`);
  return (r.data.permits ?? []).map((p: any) => ({
    // csv-loader already maps ptw_id→id, asset_id→asset, work_type→type, technician→tech
    // jha_complete→jha (boolean), isolation_verified→isolation, competency_valid→competency
    id:           p.id        ?? p.ptw_id,
    asset:        p.asset     ?? p.asset_id,
    type:         p.type      ?? p.work_type,
    tech:         p.tech      ?? p.technician,
    status:       p.status,
    jha:          (p.jha===true||p.jha==='true'||p.jha_complete===true||p.jha_complete==='true')?'Complete':'Incomplete',
    isolation:    (p.isolation===true||p.isolation==='true'||p.isolation_verified===true||p.isolation_verified==='true')?'Verified':'Not verified',
    competency:   (p.competency===true||p.competency==='true'||p.competency_valid===true||p.competency_valid==='true')?'Valid':'Expired',
  }));
}

// ── Safety Events (SQLite → /api/history/safety/events) ──────────────────
export async function fetchSafetyEvents(days = 1, plant='All Plants') {
  const r = await api.get(`/api/history/safety/events?days=${days}&plant=${encodeURIComponent(plant)}`);
  return (r.data.data ?? []).map((e: any) => ({
    id:       e.id,
    time:     e.event_time?.slice(11,16) ?? '00:00',
    zone:     e.zone,
    type:     e.event_type,
    signal:   `H2S ${e.h2s}ppm CO ${e.co}ppm CH4 ${e.ch4}%LEL`,
    severity: e.severity,
    action:   e.action ?? (e.resolved_at ? `Resolved — ${e.zone} readings normalised.` : `Precursor detected — ${e.zone}.`),
    status:   e.resolved_at ? 'resolved' : 'open',
  }));
}

// ── Energy Assets live (energy_assets.csv → /api/energy/live) ─────────────
export async function fetchEnergyAssets(plant='All Plants') {
  const r = await api.get(`/api/energy/live?plant=${encodeURIComponent(plant)}`);
  return (r.data.assets ?? r.data ?? []).map((a: any) => ({
    id:      a.id,
    name:    a.name,
    kw:      Number(a.kw ?? a.current_kw ?? a.rated_kw),
    anomaly: Boolean(a.anomaly),
  }));
}

// ── Tech Stack (tech_stack.csv → /api/config/tech-stack) ──────────────────
// Phase 2: Replace with Azure App Configuration client
export async function fetchTechStack() {
  const r = await api.get('/api/config/tech-stack');
  return r.data.stacks ?? {};
}

// ── Semantic KPI Definitions (semantic_kpi_definitions.csv → /api/config/semantic-kpis) ──
// Phase 2: Replace with Azure SQL query
export async function fetchSemanticKpiDefs() {
  const r = await api.get('/api/config/semantic-kpis');
  return r.data.definitions ?? [];
}

// ── Semantic KPI live values (KPI engine → /api/semantic/core/kpis/summary)
// Issue fix: governed live values were computed but never surfaced to the UI
export async function fetchSemanticKpiSummary(plant='All Plants') {
  const r = await api.get(`/api/semantic/core/kpis/summary?plant=${encodeURIComponent(plant)}`);
  return r.data.summary ?? [];
}

// ── Unified active-blocks (every Semantic Layer conflict across all rules)
// Backs the "X recs blocked" counter so it reflects yield DCS + PTW + WO + dispatch,
// not just yield. Returns total count + per-block-agent breakdown.
export async function fetchActiveBlocks(plant='All Plants') {
  const r = await api.get(`/api/semantic/active-blocks?plant=${encodeURIComponent(plant)}`);
  return {
    total:   Number(r.data.total ?? 0),
    byAgent: (r.data.byAgent ?? {}) as Record<string, number>,
    blocks:  (r.data.blocks ?? []) as any[],
  };
}

// ── Personas (personas.csv → /api/config/personas) ────────────────────────
// Phase 2: Replace with Azure AD role mapping + Azure SQL
export async function fetchPersonas() {
  const r = await api.get('/api/config/personas');
  return r.data.personas ?? {};
}

// ── Baselines (baselines.csv → /api/config/baselines) ─────────────────────
// Phase 2: Replace with Azure SQL — compute against live data
export async function fetchBaselines(plant='All Plants') {
  const r = await api.get(`/api/config/baselines?plant=${encodeURIComponent(plant)}`);
  return r.data.baselines ?? {};
}

// ── PdM Business Rules (pdm_rules.csv → /api/pdm/rules) ──────────────────
export async function fetchPdmRules() {
  const r = await api.get('/api/pdm/rules');
  return (r.data.rules ?? []).map((r: any) => [r.id, r.cond, r.sev === 'critical' ? '#ef4444' : '#f97316']);
}

// ── Energy Trend (SQLite energy history → /api/history/energy/trend) ──────
// Phase 3: REPLACE WITH Azure SQL or real-time energy data stream
export async function fetchEnergyTrend(days = 1, plant='All Plants') {
  const r = await api.get(`/api/history/energy/trend?days=${days}&plant=${encodeURIComponent(plant)}`);
  return r.data.data ?? [];
}
