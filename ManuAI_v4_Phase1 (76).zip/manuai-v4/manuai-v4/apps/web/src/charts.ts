// Lazy-loaded Recharts re-export.
// Importing recharts here (not in App.tsx) lets Vite/Rollup split it into a
// separate chunk that the browser fetches AFTER the initial paint, instead of
// blocking it. The chart bundle is ~540 KB; deferring it makes the dashboard
// shell render immediately and stream charts in.
export {
  LineChart, Line,
  BarChart, Bar,
  AreaChart, Area,
  ComposedChart,
  PieChart, Pie, Cell,
  ScatterChart, Scatter, ZAxis,
  XAxis, YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
