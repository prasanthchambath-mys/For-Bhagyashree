import { create } from 'zustand';
import { getSocket, subscribeChannels, oeeApi, yieldApi } from '../api';

export type Page = 'overview' | 'semantic' | 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety';

interface Store {
  page: Page;
  rightPanel: 'insights' | 'chat';
  plant: string;
  setPage: (p: Page) => void;
  setRightPanel: (p: 'insights' | 'chat') => void;
  setPlant: (p: string) => void;

  machines: unknown[];
  machinesAll: unknown[];
  plantOEE: number;
  fetchMachines: () => Promise<void>;

  yieldParams: unknown[];
  fetchYieldParams: () => Promise<void>;

  crossEvents: unknown[];
  addEvent: (e: unknown) => void;

  wsConnected: boolean;
  initWebSocket: () => void;
}

const filterByPlant = (arr: any[], plant: string) =>
  plant === 'All Plants' ? arr : arr.filter((m: any) => m.plant === (plant === 'Plant 1' ? 'P1' : 'P2'));

export const useStore = create<Store>((set, get) => ({
  page: 'overview',
  rightPanel: 'insights',
  plant: 'All Plants',
  setPage: (page) => set({ page }),
  setRightPanel: (rightPanel) => set({ rightPanel }),
  // Issue fix: plant selector now actually filters machine data
  setPlant: (plant) => set(s => ({ plant, machines: filterByPlant(s.machinesAll as any[], plant) })),

  machines: [],
  machinesAll: [],
  plantOEE: 0,
  fetchMachines: async () => {
    try {
      const data = await oeeApi.getLive();
      set(s => ({ machinesAll: data.machines, machines: filterByPlant(data.machines, s.plant), plantOEE: data.plantOEE }));
    } catch {}
  },

  yieldParams: [],
  fetchYieldParams: async () => {
    try {
      const plant = get().plant;
      const data = await yieldApi.getParams(plant);
      set({ yieldParams: data.params });
    } catch {}
  },

  crossEvents: [],
  addEvent: (e) => set(s => ({ crossEvents: [e, ...s.crossEvents].slice(0, 100) })),

  wsConnected: false,
  initWebSocket: () => {
    const socket = getSocket();
    subscribeChannels(['oee','yield','pdm','quality','energy','supply','twin','safety','semantic','alerts']);
    socket.on('connect', () => set({ wsConnected: true }));
    socket.on('disconnect', () => set({ wsConnected: false }));
    socket.on('cross_agent_event', (e: unknown) => set(s => {
      const ev = e as any;
      // Deduplicate by event id — prevents duplicate renders on reconnect / double-tick
      if (ev?.id && s.crossEvents.some((x:any) => x.id === ev.id)) return s;
      return { crossEvents: [e, ...s.crossEvents].slice(0, 100) };
    }));
    // Backend emits 'update' with { channel, data } wrapper
    socket.on('update', (payload: any) => {
      const { channel, data } = payload ?? {};
      if (channel === 'oee' && data?.machines) {
        set(s => ({ machinesAll: data.machines, machines: filterByPlant(data.machines, s.plant), plantOEE: data.plantOEE ?? 0 }));
      }
      if (channel === 'yield' && data?.params) {
        set({ yieldParams: data.params });
      }
    });
  },
}));
