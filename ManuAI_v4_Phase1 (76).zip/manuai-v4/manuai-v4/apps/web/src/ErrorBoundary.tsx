import React from 'react';

interface State { hasError: boolean; error: Error | null; info: string; }

export class ErrorBoundary extends React.Component<{children: React.ReactNode}, State> {
  constructor(props: {children: React.ReactNode}) {
    super(props);
    this.state = { hasError: false, error: null, info: '' };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Surface the full component stack on screen and in console
    this.setState({ info: info.componentStack || '' });
    // eslint-disable-next-line no-console
    console.error('[ManuAI ErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      const { error, info } = this.state;
      return (
        <div style={{
          fontFamily: "'Inter','Segoe UI',system-ui,sans-serif",
          padding: '32px', maxWidth: 900, margin: '40px auto',
          background: '#fff', border: '1px solid #d1d9e6', borderRadius: 12,
          boxShadow: '0 4px 20px rgba(0,0,0,.08)'
        }}>
          <div style={{ fontSize: 20, fontWeight: 800, color: '#c62828', marginBottom: 8 }}>
            ⚠️ ManuAI hit a runtime error
          </div>
          <div style={{ fontSize: 13, color: '#546e7a', marginBottom: 16 }}>
            The dashboard failed to render. The exact error and component are below — share this with the developer.
          </div>
          <div style={{
            background: '#1a1a2e', color: '#f48fb1', borderRadius: 8, padding: 16,
            fontFamily: "'Courier New',monospace", fontSize: 13, marginBottom: 16,
            whiteSpace: 'pre-wrap', wordBreak: 'break-word'
          }}>
            <strong style={{ color: '#80cbc4' }}>{error?.name}:</strong> {error?.message}
          </div>
          {error?.stack && (
            <details style={{ marginBottom: 12 }}>
              <summary style={{ cursor: 'pointer', fontSize: 12, fontWeight: 700, color: '#1565c0' }}>
                Stack trace
              </summary>
              <pre style={{
                background: '#f1f4f9', borderRadius: 6, padding: 12, fontSize: 11,
                overflow: 'auto', maxHeight: 200, marginTop: 8, color: '#37474f'
              }}>{error.stack}</pre>
            </details>
          )}
          {info && (
            <details>
              <summary style={{ cursor: 'pointer', fontSize: 12, fontWeight: 700, color: '#1565c0' }}>
                Component stack (which component crashed)
              </summary>
              <pre style={{
                background: '#f1f4f9', borderRadius: 6, padding: 12, fontSize: 11,
                overflow: 'auto', maxHeight: 240, marginTop: 8, color: '#37474f'
              }}>{info}</pre>
            </details>
          )}
          <button onClick={() => this.setState({ hasError: false, error: null, info: '' })}
            style={{
              marginTop: 16, padding: '8px 16px', borderRadius: 8, border: 'none',
              background: '#1565c0', color: '#fff', fontWeight: 700, cursor: 'pointer', fontSize: 13
            }}>
            Try to recover
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
