import { energyRouter } from './all-routes';
import {
  loadEnergyWaste, loadCarbonTrend,
  loadDemandForecast, loadEnergyDispatch,
} from '../data/csv-loader';
import { getEnergyTrend } from '../database/queries';

energyRouter.get('/spend', (req, res) => {
  const days = Number(req.query.days ?? 180);
  const trend = getEnergyTrend(days);
  const monthly: Record<string, { planned: number; unplanned: number }> = {};
  for (const row of trend as any[]) {
    const m = (row.day as string).slice(0, 7);
    if (!monthly[m]) monthly[m] = { planned: 0, unplanned: 0 };
    const kwhCost = 7.5;
    monthly[m].planned    += Math.round(row.avg_kw * 16 * kwhCost);
    monthly[m].unplanned  += Math.round(row.avg_kw * 8 * kwhCost * (row.anomalies > 0 ? 0.3 : 0.05));
  }
  const data = Object.entries(monthly).slice(-6).map(([m, v]) => ({
    m: new Date(m + '-01').toLocaleString('default', { month: 'short' }),
    planned: v.planned, unplanned: v.unplanned,
  }));
  res.json({ data });
});

energyRouter.get('/waste',           (_req, res) => res.json({ waste:   loadEnergyWaste() }));
energyRouter.get('/carbon',          (_req, res) => res.json({ data:    loadCarbonTrend() }));
energyRouter.get('/demand-forecast', (_req, res) => res.json({ data:    loadDemandForecast() }));
energyRouter.get('/dispatch',        (_req, res) => res.json({ actions: loadEnergyDispatch() }));

energyRouter.get('/live', (_req, res) => {
  // REPLACE WITH: Azure IoT Hub / SCADA real-time energy feed in Phase 3
  // Issue fix: serve live simulation state (ticking kW + computed anomaly),
  // falling back to static CSV only if the sim is unavailable.
  try {
    const { getPlantState } = require('../simulation/engine');
    const simAssets = getPlantState().energyAssets;
    if (Array.isArray(simAssets) && simAssets.length) {
      return res.json({ assets: simAssets.map((a: any) => ({
        id: a.id, name: a.name, kw: a.kw, anomaly: !!a.anomaly,
      })) });
    }
  } catch { /* fall through to CSV */ }
  try {
    const { loadEnergyAssets } = require('../data/csv-loader');
    res.json({ assets: loadEnergyAssets() });
  } catch {
    res.json({ assets: [] });
  }
});

export default energyRouter;
