/**
 * ManuAI — KPI Engine
 * Computes all governed KPIs from plant state → persists to semantic_kpi_value.
 * Agent APIs serve from this table, not from raw simulation state directly.
 * Phase 3: swap getPlantState() for real source system queries.
 */
import { getDb } from '../database/connection';
import { getPlantState } from '../simulation/engine';
import { logger } from '../middleware/logger';

let lastKpiWrite = 0;
const KPI_WRITE_INTERVAL_MS = 5 * 60 * 1000;

export interface ComputedKPIs {
  plant_oee: number; plant_availability: number; plant_performance: number;
  plant_quality: number; avg_health: number; min_rul: number;
  yield_pct: number; energy_kwh_per_unit: number; carbon_intensity: number;
  defect_rate: number; near_miss_rate: number; computed_at: number;
  per_asset: Array<{ asset_id:string; oee:number; health:number; rul:number; vib:number; temp:number; status:string }>;
}

export function computeKPIs(): ComputedKPIs {
  const state = getPlantState();
  const machines = state.machines;
  const now = Date.now();
  const plant_oee          = machines.reduce((s,m)=>s+m.oee,0)/machines.length;
  const plant_availability = machines.reduce((s,m)=>s+m.avail,0)/machines.length;
  const plant_performance  = machines.reduce((s,m)=>s+m.perf,0)/machines.length;
  const plant_quality      = machines.reduce((s,m)=>s+m.qual,0)/machines.length;
  const avg_health = machines.reduce((s,m)=>s+m.health,0)/machines.length;
  const min_rul    = Math.min(...machines.map(m=>m.rul));
  const batch = state.batch;
  const yield_pct = batch.actual !== null ? (batch.actual/batch.plan)*100 : batch.plan;
  const total_kw = state.energyAssets.reduce((s,a)=>s+a.kw,0);
  const energy_kwh_per_unit = plant_oee>0 ? +(total_kw/(plant_oee/100*100)).toFixed(3) : 0;
  const carbon_intensity    = +(energy_kwh_per_unit*0.69).toFixed(3);
  const defect_rate = +(100-plant_quality).toFixed(2);
  const spiking = state.safetyZones.filter(z=>(z as any)._spiking).length;
  const near_miss_rate = +(spiking/Math.max(state.tickCount,1)*1000).toFixed(3);
  return {
    plant_oee:+plant_oee.toFixed(2), plant_availability:+plant_availability.toFixed(2),
    plant_performance:+plant_performance.toFixed(2), plant_quality:+plant_quality.toFixed(2),
    avg_health:+avg_health.toFixed(2), min_rul:+min_rul.toFixed(1),
    yield_pct:+yield_pct.toFixed(2), energy_kwh_per_unit, carbon_intensity,
    defect_rate, near_miss_rate, computed_at:now,
    per_asset: machines.map(m=>({ asset_id:m.id, oee:+m.oee.toFixed(2), health:+m.health.toFixed(2),
      rul:+m.rul.toFixed(1), vib:+m.vib.toFixed(2), temp:+m.temp.toFixed(1), status:m.status })),
  };
}

export function persistKPIs(kpis: ComputedKPIs): void {
  const now = Date.now();
  if (now - lastKpiWrite < KPI_WRITE_INTERVAL_MS) return;
  try {
    const db = getDb();
    const insert = db.prepare(
      'INSERT INTO semantic_kpi_value (kpi_id,asset_id,scope,ts,value,target,status) VALUES (?,?,?,?,?,?,?)'
    );
    const st = (v:number,t:number,w=0.95) => v<t*w?'critical':v<t?'warn':'ok';
    const write = db.transaction(()=>{
      insert.run('oee',null,'plant',now,kpis.plant_oee,85,st(kpis.plant_oee,85));
      insert.run('availability',null,'plant',now,kpis.plant_availability,90,st(kpis.plant_availability,90));
      insert.run('performance',null,'plant',now,kpis.plant_performance,90,st(kpis.plant_performance,90));
      insert.run('quality',null,'plant',now,kpis.plant_quality,98,st(kpis.plant_quality,98));
      insert.run('asset_health_pct',null,'plant',now,kpis.avg_health,70,st(kpis.avg_health,70));
      insert.run('rul_days',null,'plant',now,kpis.min_rul,30,kpis.min_rul<10?'critical':kpis.min_rul<30?'warn':'ok');
      insert.run('yield_pct',null,'plant',now,kpis.yield_pct,90,st(kpis.yield_pct,90));
      insert.run('kwh_per_unit',null,'plant',now,kpis.energy_kwh_per_unit,0,'ok');
      insert.run('carbon_intensity',null,'plant',now,kpis.carbon_intensity,0,'ok');
      insert.run('defect_rate',null,'plant',now,kpis.defect_rate,2,kpis.defect_rate>5?'critical':kpis.defect_rate>2?'warn':'ok');
      for(const a of kpis.per_asset){
        insert.run('oee',a.asset_id,'asset',now,a.oee,85,st(a.oee,85));
        insert.run('asset_health_pct',a.asset_id,'asset',now,a.health,70,st(a.health,70));
        insert.run('rul_days',a.asset_id,'asset',now,a.rul,30,a.rul<10?'critical':a.rul<30?'warn':'ok');
      }
    });
    write();
    lastKpiWrite = now;
  } catch(err){ logger.warn('[KPI] Write error',{error:String(err)}); }
}

export function getLatestKPIs(scope:'plant'|'asset'='plant', assetId?:string) {
  const db = getDb();
  if(assetId){
    return db.prepare('SELECT kpi_id,value,target,status,ts FROM semantic_kpi_value WHERE asset_id=? ORDER BY ts DESC LIMIT 10').all(assetId);
  }
  return db.prepare('SELECT kpi_id,value,target,status,ts FROM semantic_kpi_value WHERE scope=? AND asset_id IS NULL ORDER BY ts DESC LIMIT 20').all(scope);
}

export function getKPITrend(kpiId:string, days=30, assetId?:string) {
  const db = getDb();
  const since = Date.now()-days*86400000;
  const dayMs = 86400000;
  return db.prepare(`
    SELECT (ts/${dayMs})*${dayMs} as day_ts, AVG(value) as avg_value, MIN(value) as min_value, MAX(value) as max_value
    FROM semantic_kpi_value
    WHERE kpi_id=? AND scope=? AND (asset_id=? OR (?  IS NULL AND asset_id IS NULL)) AND ts>=?
    GROUP BY day_ts ORDER BY day_ts ASC
  `).all(kpiId, assetId?'asset':'plant', assetId??null, assetId??null, since);
}
