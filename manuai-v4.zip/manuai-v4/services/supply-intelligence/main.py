"""
ManuAI — Supply Intelligence Service  v2.0
Predicts supply shortfalls 4–8 weeks ahead using composite risk scoring
across lead-time drift, supplier financial health, and geopolitical exposure.

Mock mode uses rule-based risk logic with realistic Indian manufacturing context.
Live mode: set DNB_API_KEY + SAP_ODATA_BASE_URL for live ERP/D&B integration.
"""

import os, random, logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Supply Intelligence", version="2.0.0")

MOCK = not bool(os.getenv("SAP_ODATA_BASE_URL"))
if MOCK:
    logger.warning("SAP_ODATA_BASE_URL not set — supply intelligence running in mock/rule mode")


# ── Models ────────────────────────────────────────────────────────────────────

class SupplierInput(BaseModel):
    supplier_id: str
    supplier_name: str
    sku: str
    description: str
    current_stock_days: float       # days of cover
    reorder_point_days: float
    lead_time_contracted_days: int
    lead_time_actual_days: int      # recent rolling average
    open_po_qty: float
    monthly_consumption: float
    unit_cost_inr: float
    single_source: bool
    country_of_origin: str
    financial_risk_score: float     # 0–100 (D&B paydex proxy)

class RiskAssessment(BaseModel):
    supplier_id: str
    supplier_name: str
    sku: str
    description: str
    overall_risk: str               # "critical" | "high" | "medium" | "low"
    risk_score: float               # 0–100
    lead_time_drift_days: int
    shortfall_probability_pct: float
    weeks_to_stockout: float
    exposure_inr: float
    risk_factors: List[str]
    recommended_action: str
    suggested_safety_stock_uplift_pct: float
    alternate_suppliers: List[str]

class SupplyForecastPoint(BaseModel):
    week_label: str
    forecast_consumption: float
    forecast_stock: float
    reorder_trigger: bool
    risk_flag: bool

class SupplyResponse(BaseModel):
    assessments: List[RiskAssessment]
    overall_plant_risk: str
    critical_count: int
    total_exposure_inr: float
    model_source: str


# ── Static supplier catalogue (replaces ERP fetch in mock mode) ───────────────

MOCK_SUPPLIERS: List[dict] = [
    {"supplier_id":"SUP-001","supplier_name":"Siemens AG","sku":"SRV-750W",
     "description":"750W Servo Drive J1","current_stock_days":8,"reorder_point_days":15,
     "lead_time_contracted_days":21,"lead_time_actual_days":39,"open_po_qty":4,
     "monthly_consumption":6,"unit_cost_inr":84000,"single_source":True,
     "country_of_origin":"Germany","financial_risk_score":18},

    {"supplier_id":"SUP-002","supplier_name":"Alfa Laval","sku":"HX-PLATES",
     "description":"Plate Heat Exchanger Elements","current_stock_days":22,"reorder_point_days":20,
     "lead_time_contracted_days":28,"lead_time_actual_days":35,"open_po_qty":1,
     "monthly_consumption":0.5,"unit_cost_inr":420000,"single_source":False,
     "country_of_origin":"Sweden","financial_risk_score":32},

    {"supplier_id":"SUP-003","supplier_name":"SKF India","sku":"BRG-6205",
     "description":"Deep Groove Ball Bearing 6205","current_stock_days":45,"reorder_point_days":10,
     "lead_time_contracted_days":7,"lead_time_actual_days":7,"open_po_qty":20,
     "monthly_consumption":30,"unit_cost_inr":1200,"single_source":False,
     "country_of_origin":"India","financial_risk_score":12},

    {"supplier_id":"SUP-004","supplier_name":"BASF Chemicals","sku":"CMPD-X12",
     "description":"Compound X-12 Base Resin","current_stock_days":6,"reorder_point_days":14,
     "lead_time_contracted_days":30,"lead_time_actual_days":51,"open_po_qty":0,
     "monthly_consumption":12,"unit_cost_inr":96000,"single_source":True,
     "country_of_origin":"Germany","financial_risk_score":55},

    {"supplier_id":"SUP-005","supplier_name":"Parker Hannifin India","sku":"HYD-SEAL-KIT",
     "description":"Hydraulic Seal Kit HPU","current_stock_days":30,"reorder_point_days":12,
     "lead_time_contracted_days":14,"lead_time_actual_days":16,"open_po_qty":3,
     "monthly_consumption":4,"unit_cost_inr":8500,"single_source":False,
     "country_of_origin":"India","financial_risk_score":20},
]


def _compute_risk(s: SupplierInput) -> RiskAssessment:
    score = 0.0
    factors = []
    alts = []

    lead_drift = s.lead_time_actual_days - s.lead_time_contracted_days
    if lead_drift > 0:
        score += min(lead_drift * 1.8, 40)
        factors.append(f"Lead-time drift +{lead_drift}d over contract")

    # Financial risk
    if s.financial_risk_score > 50:
        score += (s.financial_risk_score - 50) * 0.8
        factors.append("Elevated supplier financial risk (D&B score)")

    # Single source
    if s.single_source:
        score += 20
        factors.append("Single-source supplier — no alternate")
        alts.append("Identify alternate source urgently")
    else:
        alts.append("Alternate suppliers on panel")

    # Stock coverage vs reorder
    if s.current_stock_days < s.reorder_point_days:
        score += 25
        factors.append(f"Stock below reorder point ({s.current_stock_days:.0f}d < {s.reorder_point_days:.0f}d)")

    # Geopolitical
    high_risk_countries = ["Germany", "China", "Taiwan", "Ukraine", "Russia"]
    if s.country_of_origin in high_risk_countries and lead_drift > 5:
        score += 12
        factors.append(f"Origin: {s.country_of_origin} — trade/logistics risk flag")

    score = min(score, 100)

    if score >= 70:   overall = "critical"
    elif score >= 45: overall = "high"
    elif score >= 25: overall = "medium"
    else:             overall = "low"

    daily_consumption = s.monthly_consumption / 30
    weeks_to_stockout = (s.current_stock_days / 7) if daily_consumption > 0 else 99

    if s.current_stock_days < 7:
        shortfall_prob = 85
        action = "Emergency procurement — expedite now"
        safety_uplift = 50
    elif score >= 70:
        shortfall_prob = 65
        action = "Dual-source immediately; safety stock +40%"
        safety_uplift = 40
    elif score >= 45:
        shortfall_prob = 40
        action = "Increase safety stock and issue early PO"
        safety_uplift = 20
    else:
        shortfall_prob = 10
        action = "Monitor; no action required"
        safety_uplift = 0

    exposure = s.unit_cost_inr * s.monthly_consumption * 1.5

    return RiskAssessment(
        supplier_id=s.supplier_id,
        supplier_name=s.supplier_name,
        sku=s.sku,
        description=s.description,
        overall_risk=overall,
        risk_score=round(score, 1),
        lead_time_drift_days=lead_drift,
        shortfall_probability_pct=shortfall_prob,
        weeks_to_stockout=round(weeks_to_stockout, 1),
        exposure_inr=round(exposure, 0),
        risk_factors=factors,
        recommended_action=action,
        suggested_safety_stock_uplift_pct=safety_uplift,
        alternate_suppliers=alts,
    )


@app.get("/assess", response_model=SupplyResponse)
def assess():
    """Run supply risk assessment against the mock supplier catalogue."""
    suppliers = [SupplierInput(**s) for s in MOCK_SUPPLIERS]
    assessments = [_compute_risk(s) for s in suppliers]
    assessments.sort(key=lambda a: -a.risk_score)

    critical = sum(1 for a in assessments if a.overall_risk == "critical")
    high     = sum(1 for a in assessments if a.overall_risk == "high")
    overall  = "critical" if critical else ("high" if high else "medium")
    total_exp = sum(a.exposure_inr for a in assessments)

    return SupplyResponse(
        assessments=assessments,
        overall_plant_risk=overall,
        critical_count=critical,
        total_exposure_inr=round(total_exp, 0),
        model_source="rule_engine",
    )


@app.post("/assess/custom", response_model=RiskAssessment)
def assess_custom(supplier: SupplierInput):
    return _compute_risk(supplier)


@app.get("/forecast/{sku}", response_model=List[SupplyForecastPoint])
def forecast(sku: str):
    s = next((SupplierInput(**x) for x in MOCK_SUPPLIERS if x["sku"] == sku), None)
    if not s:
        raise HTTPException(404, f"SKU {sku} not in catalogue")
    daily_cons = s.monthly_consumption / 30
    stock = s.current_stock_days * daily_cons
    result = []
    for i in range(8):
        label = f"W{i+17}"
        consumption = daily_cons * 7 * (1 + random.uniform(-0.05, 0.05))
        stock = max(0, stock - consumption + (daily_cons * 7 if i == 3 else 0))
        result.append(SupplyForecastPoint(
            week_label=label,
            forecast_consumption=round(consumption, 1),
            forecast_stock=round(stock, 1),
            reorder_trigger=stock < s.reorder_point_days * daily_cons,
            risk_flag=stock < daily_cons * 7,
        ))
    return result


@app.get("/health")
def health():
    return {"status": "ok", "service": "supply-intelligence", "mode": "mock" if MOCK else "live"}
