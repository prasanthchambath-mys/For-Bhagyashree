# Deploying ManuAI to Azure — Step by Step

This document tells you exactly what to do, in order.
Estimated time: **45–60 minutes** (mostly waiting for Azure to provision).

---

## Before you start — 3 things to install

### 1. Make sure Docker Desktop is running
Look at your taskbar (bottom right). You should see the Docker whale icon 🐳.
If not, search "Docker Desktop" in your Start menu and open it.
Wait until it says **Engine running**.

### 2. Install Azure CLI
This is a small tool that lets your laptop talk to Azure.

Go to: **https://aka.ms/installazurecli**
Download and run the Windows installer. Takes 2 minutes.

After installing, open a new Command Prompt and type:
```
az version
```
You should see a version number. If yes, it's working.

### 3. Make sure you have an Azure subscription
Log in to **https://portal.azure.com** and confirm you can see your subscription.
If you don't have one, you can create a free account at **https://azure.microsoft.com/free**
(₹13,500 free credits for 30 days).

---

## Step 1 — Open a terminal in your project folder

1. Open File Explorer
2. Go to your `manuai-v4` folder (wherever you extracted the ZIP)
3. Click the address bar at the top
4. Type `cmd` and press Enter

A black command window opens inside the right folder.

---

## Step 2 — Run the deployment script

Type this exactly and press Enter:

```
deploy-azure.sh
```

A browser window will open asking you to log in to Azure.
Log in with your Azure account. Come back to the command window.

**That's it.** The script does everything else automatically:
- Creates all the Azure resources
- Builds all 10 Docker images
- Pushes them to Azure
- Deploys and connects everything

You'll see progress messages as it runs.

---

## Step 3 — Get your URL

When the script finishes, it prints something like:

```
══════════════════════════════════════════════════════
✓ ManuAI v4 deployed successfully!

   🌐  Open this URL in your browser:

       https://manuai-web.jolly-sand-abc123.centralindia.azurecontainerapps.io
```

Copy that URL and share it with your team. Anyone can open it in a browser.

---

## What it costs on Azure

| Resource | Cost |
|---|---|
| Container Apps (web + api) | ~₹0–5/day when idle, ~₹15–25/day under active use |
| Container Registry (Basic) | ~₹135/month |
| Redis Cache (Basic C0) | ~₹1,100/month |
| **Total estimate** | ~₹1,500–2,500/month |

**To stop all costs completely:**
```
az group delete --name manuai-rg --yes
```
This deletes everything. You can redeploy anytime by running the script again.

---

## If something goes wrong

**"docker: command not found"**
→ Docker Desktop is installed but not running. Open it from Start menu, wait for Engine running.

**"az: command not found"**
→ Azure CLI not installed or terminal not restarted after install. Close and reopen terminal.

**"The subscription is not registered"**
→ Your Azure account needs to enable Container Apps. Run:
```
az provider register --namespace Microsoft.App
az provider register --namespace Microsoft.OperationalInsights
```
Then wait 2 minutes and re-run the script.

**"ACR name already taken"**
→ The registry name must be globally unique. Open `deploy-azure.sh` in Notepad,
change `ACR_NAME="manuaiacr"` to something unique like `manuaiacr2024`, save and re-run.

**Script stops halfway**
→ Just re-run `deploy-azure.sh`. Azure resources that already exist will be skipped.

---

## Updating after code changes

Made changes to CSVs or code? Just re-run:
```
deploy-azure.sh
```
It rebuilds only what changed and redeploys.

---

## Connecting real data sources later

When you're ready to connect SAP, PI, IoT Hub etc. — open `.env.local`,
add the credentials, and re-run `deploy-azure.sh`.
The new environment variables get injected into the containers automatically.
