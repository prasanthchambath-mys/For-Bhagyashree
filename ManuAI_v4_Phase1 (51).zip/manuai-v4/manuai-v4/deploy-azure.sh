#!/bin/bash
# ══════════════════════════════════════════════════════════════════════════════
# ManuAI v4 — Azure Deployment Script
#
# What this does:
#   1. Creates a Resource Group
#   2. Creates Azure Container Registry (free basic tier)
#   3. Builds and pushes all Docker images
#   4. Creates Azure Redis Cache (basic free-tier compatible)
#   5. Deploys all containers to Azure Container Apps
#   6. Prints the final URL
#
# Requirements:
#   - Azure CLI installed (https://aka.ms/installazurecli)
#   - Docker Desktop running
#   - Azure subscription
#
# Usage:
#   chmod +x deploy-azure.sh
#   ./deploy-azure.sh
# ══════════════════════════════════════════════════════════════════════════════

set -e  # stop on any error

# ── CONFIGURATION — edit these before running ─────────────────────────────────
RESOURCE_GROUP="manuai-rg"
LOCATION="centralindia"           # closest Azure region to Mumbai
ACR_NAME="manuaiacr"              # must be globally unique, lowercase, no hyphens
ENVIRONMENT="manuai-env"          # Container Apps environment name
APP_NAME="manuai"

# ── colours for output ────────────────────────────────────────────────────────
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[DONE]${NC} $1"; }
warn()    { echo -e "${YELLOW}[NOTE]${NC} $1"; }

# ── Step 0: Check prerequisites ───────────────────────────────────────────────
info "Checking prerequisites..."
command -v az     >/dev/null 2>&1 || { echo "Azure CLI not installed. Get it from https://aka.ms/installazurecli"; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "Docker not found. Make sure Docker Desktop is running."; exit 1; }
docker info       >/dev/null 2>&1 || { echo "Docker is not running. Please start Docker Desktop."; exit 1; }
success "Prerequisites OK"

# ── Step 1: Azure login ───────────────────────────────────────────────────────
info "Logging in to Azure..."
az login --only-show-errors
success "Logged in"

# ── Step 2: Create Resource Group ────────────────────────────────────────────
info "Creating resource group: $RESOURCE_GROUP in $LOCATION..."
az group create \
  --name "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --only-show-errors
success "Resource group ready"

# ── Step 3: Create Azure Container Registry ───────────────────────────────────
info "Creating container registry: $ACR_NAME..."
az acr create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$ACR_NAME" \
  --sku Basic \
  --admin-enabled true \
  --only-show-errors
success "Container registry ready"

# Get registry credentials
ACR_SERVER=$(az acr show --name "$ACR_NAME" --query loginServer -o tsv)
ACR_USER=$(az acr credential show --name "$ACR_NAME" --query username -o tsv)
ACR_PASS=$(az acr credential show --name "$ACR_NAME" --query "passwords[0].value" -o tsv)
info "Registry: $ACR_SERVER"

# ── Step 4: Build and push images ────────────────────────────────────────────
info "Logging Docker into Azure Container Registry..."
echo "$ACR_PASS" | docker login "$ACR_SERVER" -u "$ACR_USER" --password-stdin

info "Building and pushing API image..."
docker build \
  -f infra/docker/Dockerfile.api \
  -t "$ACR_SERVER/manuai-api:latest" \
  .
docker push "$ACR_SERVER/manuai-api:latest"
success "API image pushed"

info "Building and pushing Web image..."
docker build \
  -f infra/docker/Dockerfile.web \
  --build-arg VITE_API_URL="" \
  --build-arg VITE_WS_URL="" \
  -t "$ACR_SERVER/manuai-web:latest" \
  ./apps/web
docker push "$ACR_SERVER/manuai-web:latest"
success "Web image pushed"

info "Building and pushing Python service images..."
for svc in pdm-inference yield-optimizer energy-optimizer quality-vision supply-intelligence twin-sync safety-monitor; do
  docker build \
    -f infra/docker/Dockerfile.python \
    -t "$ACR_SERVER/manuai-$svc:latest" \
    ./services/$svc
  docker push "$ACR_SERVER/manuai-$svc:latest"
  success "$svc image pushed"
done

# ── Step 5: Create Redis Cache ────────────────────────────────────────────────
info "Creating Redis Cache (Basic C0 — lowest cost)..."
REDIS_NAME="manuai-redis-$RANDOM"
az redis create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$REDIS_NAME" \
  --location "$LOCATION" \
  --sku Basic \
  --vm-size C0 \
  --only-show-errors

REDIS_HOST=$(az redis show --resource-group "$RESOURCE_GROUP" --name "$REDIS_NAME" --query hostName -o tsv)
REDIS_KEY=$(az redis list-keys --resource-group "$RESOURCE_GROUP" --name "$REDIS_NAME" --query primaryKey -o tsv)
REDIS_URL="rediss://:${REDIS_KEY}@${REDIS_HOST}:6380"
success "Redis ready: $REDIS_HOST"

# ── Step 6: Create Container Apps Environment ─────────────────────────────────
info "Creating Container Apps environment..."
az containerapp env create \
  --name "$ENVIRONMENT" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --only-show-errors
success "Container Apps environment ready"

# ── Step 7: Deploy API ────────────────────────────────────────────────────────
info "Deploying API container..."
az containerapp create \
  --name "manuai-api" \
  --resource-group "$RESOURCE_GROUP" \
  --environment "$ENVIRONMENT" \
  --image "$ACR_SERVER/manuai-api:latest" \
  --registry-server "$ACR_SERVER" \
  --registry-username "$ACR_USER" \
  --registry-password "$ACR_PASS" \
  --target-port 4000 \
  --ingress external \
  --min-replicas 1 \
  --max-replicas 2 \
  --cpu 0.5 \
  --memory 1.0Gi \
  --env-vars \
    NODE_ENV=production \
    MOCK_AUTH=true \
    MOCK_DATA_ENGINE=true \
    CSV_DATA_DIR=/app/data/csv \
    REDIS_URL="$REDIS_URL" \
  --only-show-errors

API_URL=$(az containerapp show \
  --name "manuai-api" \
  --resource-group "$RESOURCE_GROUP" \
  --query properties.configuration.ingress.fqdn -o tsv)
success "API deployed: https://$API_URL"

# ── Step 8: Deploy Python services ───────────────────────────────────────────
info "Deploying Python microservices..."
declare -A SVC_PORTS=(
  [pdm-inference]=8001
  [yield-optimizer]=8002
  [energy-optimizer]=8003
  [quality-vision]=8004
  [supply-intelligence]=8005
  [twin-sync]=8006
  [safety-monitor]=8007
)

for svc in pdm-inference yield-optimizer energy-optimizer quality-vision supply-intelligence twin-sync safety-monitor; do
  az containerapp create \
    --name "manuai-$svc" \
    --resource-group "$RESOURCE_GROUP" \
    --environment "$ENVIRONMENT" \
    --image "$ACR_SERVER/manuai-$svc:latest" \
    --registry-server "$ACR_SERVER" \
    --registry-username "$ACR_USER" \
    --registry-password "$ACR_PASS" \
    --target-port 8000 \
    --ingress internal \
    --min-replicas 1 \
    --max-replicas 1 \
    --cpu 0.25 \
    --memory 0.5Gi \
    --only-show-errors
  success "$svc deployed"
done

# ── Step 9: Deploy Web frontend ───────────────────────────────────────────────
info "Deploying Web frontend..."
az containerapp create \
  --name "manuai-web" \
  --resource-group "$RESOURCE_GROUP" \
  --environment "$ENVIRONMENT" \
  --image "$ACR_SERVER/manuai-web:latest" \
  --registry-server "$ACR_SERVER" \
  --registry-username "$ACR_USER" \
  --registry-password "$ACR_PASS" \
  --target-port 80 \
  --ingress external \
  --min-replicas 1 \
  --max-replicas 2 \
  --cpu 0.25 \
  --memory 0.5Gi \
  --only-show-errors

WEB_URL=$(az containerapp show \
  --name "manuai-web" \
  --resource-group "$RESOURCE_GROUP" \
  --query properties.configuration.ingress.fqdn -o tsv)

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo "══════════════════════════════════════════════════════"
success "ManuAI v4 deployed successfully!"
echo ""
echo "  🌐  Open this URL in your browser:"
echo ""
echo "      https://$WEB_URL"
echo ""
echo "  📡  API endpoint:  https://$API_URL"
echo "  🔑  Resource group: $RESOURCE_GROUP (Azure Portal)"
echo ""
echo "  To update after code changes:"
echo "      ./deploy-azure.sh  (re-run this script)"
echo ""
echo "  To shut everything down (stop all costs):"
echo "      az group delete --name $RESOURCE_GROUP --yes"
echo "══════════════════════════════════════════════════════"
