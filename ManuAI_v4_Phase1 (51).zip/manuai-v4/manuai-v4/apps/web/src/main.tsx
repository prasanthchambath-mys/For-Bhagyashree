import React, { useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { useStore } from './store';
import { useDevAuth } from './hooks';

function Root() {
  useDevAuth();
  const initWebSocket = useStore(s => s.initWebSocket);
  useEffect(() => { initWebSocket(); }, []);
  return <App />;
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>,
);

// ── Production: wrap Root in MsalProvider ─────────────────────
// import { PublicClientApplication } from '@azure/msal-browser';
// import { MsalProvider } from '@azure/msal-react';
// const pca = new PublicClientApplication({
//   auth: {
//     clientId: import.meta.env.VITE_AZURE_CLIENT_ID,
//     authority: `https://login.microsoftonline.com/${import.meta.env.VITE_AZURE_TENANT_ID}`,
//     redirectUri: window.location.origin,
//   },
// });
// ReactDOM.createRoot(document.getElementById('root')!).render(
//   <MsalProvider instance={pca}><Root /></MsalProvider>
// );
