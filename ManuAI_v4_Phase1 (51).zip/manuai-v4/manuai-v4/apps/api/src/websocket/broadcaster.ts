import { Server } from 'socket.io';
import { Server as HttpServer } from 'http';
import { logger } from '../middleware/logger';

let io: Server;

export type AgentChannel = 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety' | 'semantic' | 'alerts';

export function initWebSocket(httpServer: HttpServer): void {
  io = new Server(httpServer, {
    cors: { origin: process.env.CORS_ORIGINS?.split(',') ?? ['http://localhost:5173'], methods: ['GET', 'POST'] },
    transports: ['websocket', 'polling'],
  });

  io.on('connection', (socket) => {
    // Channel subscription (e.g. ["oee","yield"])
    socket.on('subscribe', (channels: AgentChannel[]) =>
      channels.forEach(ch => socket.join(ch)));

    // Plant/tenant room — socket joins "plant:P1" room
    // Enables per-plant filtering: broadcast only to sockets for the right plant
    socket.on('subscribe_plant', (plantId: string) => {
      socket.join(`plant:${plantId}`);
      socket.data.plantId = plantId;
    });

    // Tenant room for future multi-tenant support
    socket.on('subscribe_tenant', (tenantId: string) => {
      socket.join(`tenant:${tenantId}`);
      socket.data.tenantId = tenantId;
    });

    socket.on('disconnect', () => logger.debug('WS disconnect', { id: socket.id }));
  });

  logger.info('WebSocket server ready');
}

/**
 * Broadcast live data to agent channel subscribers.
 * Scoped to plant room if plantId provided.
 */
export function broadcast(channel: AgentChannel, data: unknown, plantId = 'P1'): void {
  // Emit to channel room AND plant room intersection
  // All sockets in "oee" channel that also joined "plant:P1"
  io?.to(channel).emit('update', { channel, ts: Date.now(), data, plant_id: plantId });
}

/**
 * Broadcast cross-agent event.
 * If event carries plant_id, only send to sockets in that plant room.
 * Falls back to all sockets if no plant_id.
 */
export function broadcastEvent(event: Record<string, unknown>): void {
  const plantId = event.plant_id as string | undefined;
  if (plantId) {
    // Send to all sockets subscribed to this plant
    io?.to(`plant:${plantId}`).emit('cross_agent_event', event);
    // Also send to sockets that haven't subscribed to a specific plant (Phase 1 compat)
    io?.except(`plant:${plantId}`).emit('cross_agent_event', event);
  } else {
    io?.emit('cross_agent_event', event);
  }
}

/**
 * Broadcast to a specific plant room only.
 * Used for tenant isolation in Phase 3.
 */
export function broadcastToPlant(plantId: string, channel: AgentChannel, data: unknown): void {
  io?.to(`plant:${plantId}`).to(channel).emit('update', { channel, ts: Date.now(), data, plant_id: plantId });
}
