/**
 * ManuAI — KPI Engine
 * Computes all governed KPIs from plant state → persists to semantic_kpi_value.
 * Agent APIs serve from this table, not from raw simulation state directly.
 * Phase 3: swap getPlantState() for real source system queries.
 */
import { getDb } from '../database/connection';
import { getPlantState } from '../simulation/engine';
import { logger } from '../middleware/logger';
import { loadCsvRaw } from '../data/csv-loader';

let lastKpiWrite = 0;
// India grid carbon factor (CEA standard) — overridable via env
const CARBON_GRID_FACTOR = parseFloat(process.env.CARBON_GRID_FACTOR ?? '0.82');

const KPI_WRITE_INTERVAL_MS = 5 * 60 * 1000;

export interface ComputedKPIs {
  plant_oee: number; plant_availability: number; plant_performance: number;
  plant_quality: number; avg_health: number; min_rul: number;
  yield_pct: number; energy_kwh_per_unit: number; carbon_intensity: number;
  defect_rate: number; near_miss_rate: number;
  supply_risk_score: number; twin_divergence: number; permit_compliance: number;
  computed_at: number;
  per_asset: Array<{ asset_id:string; oee:number; health:number; rul:number; vib:number; temp:number; status:string }>;
}

export function computeKPIs(): ComputedKPIs {
  const state = getPlantState();
  const machines = state.machines;
  const now = Date.now();
  const plant_oee          = machines.reduce((s,m)=>s+m.oee,0)/machines.length;
  const plant_availability = machines.reduce((s,m)=>s+m.avail,0)/machines.length;
  const plant_performance  = machines.reduce((s,m)=>s+m.perf,0)/machines.length;
  const plant_quality      = machines.reduce((s,m)=>s+m.qual,0)/machines.length;
  const avg_health = machines.reduce((s,m)=>s+m.health,0)/machines.length;
  const min_rul    = Math.min(...machines.map(m=>m.rul));
  const batch = state.batch;
  const yield_pct = batch.actual !== null ? (batch.actual/batch.plan)*100 : batch.plan;
  const total_kw = state.energyAssets.reduce((s,a)=>s+a.kw,0);
  const energy_kwh_per_unit = plant_oee>0 ? +(total_kw/(plant_oee/100*100)).toFixed(3) : 0;
  const carbon_intensity    = +(energy_kwh_per_unit*CARBON_GRID_FACTOR).toFixed(3);
  const defect_rate = +(100-plant_quality).toFixed(2);
  const spiking = state.safetyZones.filter(z=>(z as any)._spiking).length;
  const near_miss_rate = +(spiking/Math.max(state.tickCount,1)*1000).toFixed(3);
  // Issue 4: KPIs from Phase 1 CSV reference data
  const supplyRows = loadCsvRaw('supply_risks.csv');
  const supply_risk_score = supplyRows.length
    ? +(supplyRows.reduce((s: number, r: any) => {
        const stock = Number(r.current_stock_days ?? 30);
        const fin = Number(r.financial_risk_score ?? 0); // 0-20 scale in CSV
        const stockRisk = stock < 14 ? 6 : stock < 30 ? 3 : 1;        // 0-6
        const finRisk = Math.min(fin / 20, 1) * 4;                     // 0-4
        return s + Math.min(stockRisk + finRisk, 10);                  // cap at 10
      }, 0) / supplyRows.length).toFixed(2)
    : 0;
  const twinRows = loadCsvRaw('twin_kpis.csv');
  const twin_divergence = twinRows.length
    ? +(twinRows.reduce((s: number, k: any) => {
        const tp = Number(k.twin_predicted ?? 0);
        return s + (tp !== 0 ? Math.abs(Number(k.actual ?? 0) - tp) / Math.abs(tp) * 100 : 0);
      }, 0) / twinRows.length).toFixed(2)
    : 0;
  const ptwRows = loadCsvRaw('safety_permits.csv');
  const validPtw = ptwRows.filter((p: any) => p.status === 'approved' || p.status === 'active' || p.status === 'valid').length;
  const permit_compliance = ptwRows.length ? +(validPtw / ptwRows.length * 100).toFixed(1) : 100;
  return {
    plant_oee:+plant_oee.toFixed(2), plant_availability:+plant_availability.toFixed(2),
    plant_performance:+plant_performance.toFixed(2), plant_quality:+plant_quality.toFixed(2),
    avg_health:+avg_health.toFixed(2), min_rul:+min_rul.toFixed(1),
    yield_pct:+yield_pct.toFixed(2), energy_kwh_per_unit, carbon_intensity,
    defect_rate, near_miss_rate, supply_risk_score, twin_divergence, permit_compliance, computed_at:now,
    per_asset: machines.map(m=>({ asset_id:m.id, oee:+m.oee.toFixed(2), health:+m.health.toFixed(2),
      rul:+m.rul.toFixed(1), vib:+m.vib.toFixed(2), temp:+m.temp.toFixed(1), status:m.status })),
  };
}

export function persistKPIs(kpis: ComputedKPIs): void {
  const now = Date.now();
  if (now - lastKpiWrite < KPI_WRITE_INTERVAL_MS) return;
  try {
    const db = getDb();
    const insert = db.prepare(
      'INSERT INTO semantic_kpi_value (kpi_id,asset_id,scope,ts,value,target,status) VALUES (?,?,?,?,?,?,?)'
    );
    const st = (v:number,t:number,w=0.95) => v<t*w?'critical':v<t?'warn':'ok';
    // Issue fix: OEE target from platform_config.csv benchmark.your_target (was hardcoded 85)
    let OEE_TGT = 85;
    try {
      const { loadPlatformConfig } = require('../data/csv-loader');
      OEE_TGT = Number(loadPlatformConfig()?.benchmarks?.your_target ?? 85);
    } catch { /* keep fallback */ }
    const write = db.transaction(()=>{
      insert.run('oee',null,'plant',now,kpis.plant_oee,OEE_TGT,st(kpis.plant_oee,OEE_TGT));
      insert.run('availability',null,'plant',now,kpis.plant_availability,90,st(kpis.plant_availability,90));
      insert.run('performance',null,'plant',now,kpis.plant_performance,90,st(kpis.plant_performance,90));
      insert.run('quality',null,'plant',now,kpis.plant_quality,98,st(kpis.plant_quality,98));
      insert.run('asset_health_pct',null,'plant',now,kpis.avg_health,70,st(kpis.avg_health,70));
      insert.run('rul_days',null,'plant',now,kpis.min_rul,30,kpis.min_rul<10?'critical':kpis.min_rul<30?'warn':'ok');
      insert.run('yield_pct',null,'plant',now,kpis.yield_pct,90,st(kpis.yield_pct,90));
      insert.run('kwh_per_unit',null,'plant',now,kpis.energy_kwh_per_unit,0,'ok');
      insert.run('carbon_intensity',null,'plant',now,kpis.carbon_intensity,0,'ok');
      insert.run('defect_rate',null,'plant',now,kpis.defect_rate,2,kpis.defect_rate>5?'critical':kpis.defect_rate>2?'warn':'ok');
      insert.run('near_miss_rate',null,'plant',now,kpis.near_miss_rate,5,kpis.near_miss_rate>10?'critical':kpis.near_miss_rate>5?'warn':'ok');
      insert.run('supply_risk_score',null,'plant',now,kpis.supply_risk_score,5,kpis.supply_risk_score>7?'critical':kpis.supply_risk_score>5?'warn':'ok');
      insert.run('twin_divergence',null,'plant',now,kpis.twin_divergence,3,kpis.twin_divergence>5?'critical':kpis.twin_divergence>3?'warn':'ok');
      insert.run('permit_compliance',null,'plant',now,kpis.permit_compliance,95,kpis.permit_compliance<90?'critical':kpis.permit_compliance<95?'warn':'ok');
      for(const a of kpis.per_asset){
        insert.run('oee',a.asset_id,'asset',now,a.oee,OEE_TGT,st(a.oee,OEE_TGT));
        insert.run('asset_health_pct',a.asset_id,'asset',now,a.health,70,st(a.health,70));
        insert.run('rul_days',a.asset_id,'asset',now,a.rul,30,a.rul<10?'critical':a.rul<30?'warn':'ok');
      }
    });
    write();
    lastKpiWrite = now;
  } catch(err){ logger.warn('[KPI] Write error',{error:String(err)}); }
}

export function getLatestKPIs(scope:'plant'|'asset'='plant', assetId?:string) {
  const db = getDb();
  if(assetId){
    return db.prepare('SELECT kpi_id,value,target,status,ts FROM semantic_kpi_value WHERE asset_id=? ORDER BY ts DESC LIMIT 10').all(assetId);
  }
  return db.prepare('SELECT kpi_id,value,target,status,ts FROM semantic_kpi_value WHERE scope=? AND asset_id IS NULL ORDER BY ts DESC LIMIT 20').all(scope);
}

export function getKPITrend(kpiId:string, days=30, assetId?:string) {
  const db = getDb();
  const since = Date.now()-days*86400000;
  const dayMs = 86400000;
  return db.prepare(`
    SELECT (ts/${dayMs})*${dayMs} as day_ts, AVG(value) as avg_value, MIN(value) as min_value, MAX(value) as max_value
    FROM semantic_kpi_value
    WHERE kpi_id=? AND scope=? AND (asset_id=? OR (?  IS NULL AND asset_id IS NULL)) AND ts>=?
    GROUP BY day_ts ORDER BY day_ts ASC
  `).all(kpiId, assetId?'asset':'plant', assetId??null, assetId??null, since);
}
