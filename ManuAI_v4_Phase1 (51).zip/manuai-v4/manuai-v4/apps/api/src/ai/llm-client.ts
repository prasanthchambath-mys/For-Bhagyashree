/**
 * ManuAI — Unified LLM Client
 *
 * Phase 1: LLM_PROVIDER=stargate  → StargateAI (free, internal)
 * Phase 2: LLM_PROVIDER=azure_openai → Azure OpenAI
 * Fallback: LLM_PROVIDER=anthropic  → Anthropic Claude
 *
 * Switch by changing LLM_PROVIDER in .env.local — no code changes.
 */

import axios from 'axios';
import { logger } from '../middleware/logger';

export interface ChatMessage { role: 'user' | 'assistant'; content: string; }

const PROVIDER = process.env.LLM_PROVIDER ?? 'stargate';

const SYSTEM_9_AGENT = `You are the ManuAI Unified Platform AI with context across all 8 agents:
OEE Visibility, Yield Optimisation, Predictive Maintenance, Quality Vision,
Energy Optimisation, Supply Chain Resilience, Digital Twin, Safety & Compliance, AI Chat.
Be specific and data-driven. Highlight cross-agent impacts. Max 150 words unless asked for detail.`;

const AGENT_PROMPTS: Record<string, string> = {
  yield:   'You are the Yield Optimisation agent. Recommend DCS set-point adjustments. Max 80 words.',
  pdm:     'You are the Predictive Maintenance agent. RUL < 14d = critical, RUL < 30d = urgent. Max 80 words.',
  oee:     'You are the OEE Visibility agent. Identify top Six Big Losses. Max 80 words.',
  quality: 'You are the Quality Vision agent. Analyse defect patterns. Max 80 words.',
  energy:  'You are the Energy Optimisation agent. Recommend demand response actions. Max 80 words.',
  supply:  'You are the Supply Chain agent. Analyse supplier risk 4-8 weeks ahead. Max 80 words.',
  safety:  'You are the Safety agent. Never understate risk severity. Max 80 words.',
  twin:    'You are the Digital Twin agent. Flag KPI divergence from twin predictions. Max 80 words.',
};

async function openAICompatibleChat(
  messages: Array<{ role: string; content: string }>,
  systemPrompt: string,
  maxTokens = 600
): Promise<string> {
  const isStargate = PROVIDER === 'stargate';
  const isAzure = PROVIDER === 'azure_openai';

  const baseUrl = isStargate
    ? (process.env.STARGATE_BASE_URL ?? 'https://api-stargate.infocepts.com/')
    : (process.env.AZURE_OPENAI_ENDPOINT ?? '');

  const apiKey = isStargate
    ? (process.env.STARGATE_API_KEY ?? '')
    : (process.env.AZURE_OPENAI_API_KEY ?? '');

  const model = isStargate
    ? (process.env.STARGATE_MODEL ?? 'gptoss-20b')
    : (process.env.AZURE_OPENAI_DEPLOYMENT ?? 'gpt-4o');

  if (!apiKey) {
    logger.warn(`[LLM] ${PROVIDER} API key not set`);
    return 'AI service not configured. Please set the API key in .env.local.';
  }

  const url = isAzure
    ? `${baseUrl}/openai/deployments/${model}/chat/completions?api-version=2024-02-01`
    : `${baseUrl}v1/chat/completions`;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(isAzure ? { 'api-key': apiKey } : { 'Authorization': `Bearer ${apiKey}` }),
  };

  const res = await axios.post(url, {
    model,
    max_tokens: maxTokens,
    messages: [{ role: 'system', content: systemPrompt }, ...messages],
  }, { headers, timeout: 30000 });

  return res.data?.choices?.[0]?.message?.content ?? 'No response.';
}

async function anthropicChat(
  messages: ChatMessage[],
  systemPrompt: string,
  maxTokens = 600
): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return 'AI service not configured.';

  const res = await axios.post('https://api.anthropic.com/v1/messages', {
    model: process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-4-20250514',
    max_tokens: maxTokens,
    system: systemPrompt,
    messages,
  }, {
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    timeout: 30000,
  });

  return res.data?.content?.find((b: any) => b.type === 'text')?.text ?? 'No response.';
}

export async function unifiedChat(messages: ChatMessage[], liveContext?: string): Promise<string> {
  const system = liveContext
    ? `${SYSTEM_9_AGENT}\n\n--- LIVE PLANT STATE ---\n${liveContext}`
    : SYSTEM_9_AGENT;
  try {
    if (PROVIDER === 'anthropic') return await anthropicChat(messages, system);
    return await openAICompatibleChat(messages, system);
  } catch (err) {
    logger.error('[LLM] Chat error', { provider: PROVIDER, error: String(err) });
    throw new Error('AI service temporarily unavailable');
  }
}

export async function agentRecommendation(agent: string, context: string, question: string): Promise<string> {
  const system = `${AGENT_PROMPTS[agent] ?? SYSTEM_9_AGENT}\n\nContext:\n${context}`;
  try {
    if (PROVIDER === 'anthropic') return await anthropicChat([{ role: 'user', content: question }], system, 300);
    return await openAICompatibleChat([{ role: 'user', content: question }], system, 300);
  } catch (err) {
    logger.error('[LLM] Agent error', { agent, error: String(err) });
    return 'AI recommendation temporarily unavailable.';
  }
}

export async function semanticQuery(question: string, kpiContext: string): Promise<string> {
  const system = `You are the ManuAI Semantic Layer. Answer using only the KPI data provided. Max 200 words.\n\nKPIs:\n${kpiContext}`;
  try {
    if (PROVIDER === 'anthropic') return await anthropicChat([{ role: 'user', content: question }], system, 500);
    return await openAICompatibleChat([{ role: 'user', content: question }], system, 500);
  } catch (err) {
    logger.error('[LLM] Semantic error', { error: String(err) });
    return 'Query temporarily unavailable.';
  }
}

logger.info(`[LLM] Provider: ${PROVIDER}`);
