/**
 * ManuAI — CSV Data Loader
 *
 * Reads all CSV files from data/csv/ and returns typed objects.
 * Every connector and route that needs seed data calls this loader.
 *
 * HOW TO SWAP TO REAL DATA:
 * --------------------------
 * Each function below has a comment: // REPLACE WITH: <connector>
 * When you're ready, delete the CSV read and replace with the connector call.
 * Nothing else in the codebase needs to change.
 *
 * EDITING MOCK DATA:
 * ------------------
 * Open any file in data/csv/ in Excel, edit values, save as CSV.
 * Restart the API — changes take effect immediately.
 */

import fs from 'fs';
import path from 'path';
import { logger } from '../middleware/logger';

// ── CSV path resolver ─────────────────────────────────────────────────────────
const CSV_DIR = process.env.CSV_DATA_DIR
  ?? path.resolve(__dirname, '../../../../data/csv');

function csvPath(filename: string): string {
  return path.join(CSV_DIR, filename);
}

// ── Generic CSV parser (no external dependency) ───────────────────────────────
function parseCSV(filename: string): Record<string, string>[] {
  const fullPath = csvPath(filename);
  if (!fs.existsSync(fullPath)) {
    logger.warn(`CSV not found: ${fullPath}`);
    return [];
  }
  const raw = fs.readFileSync(fullPath, 'utf-8');
  const lines = raw.trim().split('\n').filter(l => l.trim());
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.trim());
  return lines.slice(1).map(line => {
    // Handle commas inside quoted fields
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    for (const ch of line) {
      if (ch === '"') { inQuotes = !inQuotes; continue; }
      if (ch === ',' && !inQuotes) { values.push(current.trim()); current = ''; continue; }
      current += ch;
    }
    values.push(current.trim());
    return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
  });
}

function num(v: string | undefined, fallback = 0): number {
  const n = parseFloat(v ?? '');
  return isNaN(n) ? fallback : n;
}
function bool(v: string | undefined): boolean {
  return (v ?? '').toLowerCase() === 'true';
}
// Alias used by appended loader functions
const loadCsv = parseCSV;
// Raw row accessor for config sections (Issue 9/13 fix)
export const loadCsvRaw = parseCSV;


// ── Loaders ───────────────────────────────────────────────────────────────────

export function loadMachines() {
  // REPLACE WITH: PI Historian getTagsBatch() + SAP MES data
  return parseCSV('machines.csv').map(r => ({
    id:          r.id,
    name:        r.name,
    line:        r.line,
    plant:       r.plant,
    oee:         num(r.oee),
    avail:       num(r.avail),
    perf:        num(r.perf),
    qual:        num(r.qual),
    health:      num(r.health),
    rul:         num(r.rul),
    status:      r.status as 'good' | 'caution' | 'warning' | 'critical',
    loss:        r.loss,
    lossMin:     num(r.loss_min),
    vib:         num(r.vib),
    temp:        num(r.temp),
    _degradeRate:num(r.degrade_rate, 0.05),
    _inMaintenance: false,
    _maintenanceTicksLeft: 0,
  }));
}

export function loadUtilities() {
  // REPLACE WITH: PI Historian + IoT Hub sensor readings
  return parseCSV('utilities.csv').map(r => ({
    id:          r.id,
    name:        r.name,
    health:      num(r.health),
    rul:         num(r.rul),
    status:      r.status,
    vib:         num(r.vib),
    temp:        num(r.temp),
    press:       num(r.pressure),
    oeeLink:     r.oee_link || null,
    _degradeRate:num(r.degrade_rate, 0.05),
  }));
}

export function loadYieldParams() {
  // REPLACE WITH: PI Historian getTagsBatch() for process tags
  return parseCSV('yield_params.csv').map(r => ({
    id:           r.id,
    name:         r.name,
    unit:         r.unit,
    val:          num(r.value),
    tgt:          num(r.target),
    min:          num(r.min),
    max:          num(r.max),
    warn:         Math.abs(num(r.value) - num(r.target)) / (num(r.max) - num(r.min)) > 0.06,
    blocked:      false,
    _driftRate:   num(r.drift_rate, 0.05),
    _driftDir:    (num(r.drift_direction, 1) >= 0 ? 1 : -1) as 1 | -1,
  }));
}

export function loadProductionOrders() {
  // REPLACE WITH: SAP OData getProductionOrders()
  return parseCSV('production_orders.csv').map(r => ({
    id:       r.id,
    product:  r.product,
    qty:      `${r.qty_kg} kg`,
    plan:     num(r.plan_yield),
    actual:   r.actual_yield ? num(r.actual_yield) : null,
    status:   r.status,
    start:    r.start_date,
    end:      r.end_date,
  }));
}

export function loadLimsResults() {
  // REPLACE WITH: LIMS connector getTodayResults()
  return parseCSV('lims_results.csv').map(r => ({
    id:       r.id,
    batch:    r.batch,
    test:     r.test,
    result:   r.result,
    limit:    r.limit,
    status:   r.status as 'pass' | 'fail',
    analyst:  r.analyst,
    time:     r.time,
  }));
}

export function loadWorkOrders() {
  // REPLACE WITH: SAP PM getMaintenanceOrders()
  return parseCSV('work_orders.csv').map(r => ({
    id:          r.id,
    asset:       r.asset_id,
    name:        r.asset_name,
    type:        r.type,
    pri:         r.priority,
    desc:        r.description,
    status:      r.status,
    assigned:    r.assigned_to,
    oeeLink:     bool(r.oee_link),
  }));
}

export function loadSupplyRisks() {
  // REPLACE WITH: SAP MM getMaterialStock() + D&B API for financial scores
  return parseCSV('supply_risks.csv').map(r => ({
    supplier_id:                r.supplier_id,
    supplier_name:              r.supplier_name,
    sku:                        r.sku,
    description:                r.description,
    current_stock_days:         num(r.current_stock_days),
    reorder_point_days:         num(r.reorder_point_days),
    lead_time_contracted_days:  num(r.lead_time_contracted_days),
    lead_time_actual_days:      num(r.lead_time_actual_days),
    monthly_consumption:        num(r.monthly_consumption),
    unit_cost_inr:              num(r.unit_cost_inr),
    single_source:              bool(r.single_source),
    country_of_origin:          r.country_of_origin,
    financial_risk_score:       num(r.financial_risk_score),
  }));
}

export function loadEnergyAssets() {
  // REPLACE WITH: Smart meter API / Azure IoT Hub energy telemetry
  return parseCSV('energy_assets.csv').map(r => ({
    id:                     r.id,
    name:                   r.name,
    kw:                     num(r.current_kw),
    anomaly:                false,
    _baseKw:                num(r.rated_kw),
    shiftable:              bool(r.shiftable),
    critical:               bool(r.critical),
    anomalyThresholdPct:    num(r.anomaly_threshold_pct, 12),
  }));
}

export function loadEnergyHourly() {
  // REPLACE WITH: Smart meter historical data API
  return parseCSV('energy_hourly.csv').map(r => ({
    h:  r.hour,
    kw: num(r.kw_base),
  }));
}

export function loadSafetyZones() {
  // REPLACE WITH: IoT Hub gas sensor stream
  return parseCSV('safety_zones.csv').map(r => ({
    zone:        r.zone_id,
    h2s:         num(r.h2s_ppm_baseline),
    co:          num(r.co_ppm_baseline),
    ch4:         num(r.ch4_pct_lel_baseline),
    thresholds: {
      h2s: { alarm1: num(r.h2s_alarm1), alarm2: num(r.h2s_alarm2), evac: num(r.h2s_evac) },
      co:  { alarm1: num(r.co_alarm1),  alarm2: num(r.co_alarm2),  evac: num(r.co_evac)  },
      ch4: { alarm1: num(r.ch4_alarm1), alarm2: num(r.ch4_alarm2), evac: num(r.ch4_evac) },
    },
    personnelNormal: num(r.personnel_normal),
    amrEnabled:      bool(r.amr_enabled),
    _spiking:        false,
    _spikeTicks:     0,
  }));
}

export function loadSafetyPermits() {
  // REPLACE WITH: CMMS / PTW system API
  return parseCSV('safety_permits.csv').map(r => ({
    id:                 r.ptw_id,
    asset:              r.asset_id,
    type:               r.work_type,
    tech:               r.technician,
    status:             r.status,
    jha:                bool(r.jha_complete),
    isolation:          bool(r.isolation_verified),
    competency:         bool(r.competency_valid),
  }));
}

export function loadQualityDefects() {
  // REPLACE WITH: Vision AI service / MES quality module
  return parseCSV('quality_defects.csv').map(r => ({
    id:         r.id,
    time:       r.time,
    line:       r.line,
    component:  r.component,
    type:       r.defect_type,
    severity:   r.severity as 'major' | 'minor' | 'cosmetic',
    action:     r.action,
    confidence: num(r.confidence),
  }));
}

export function loadQualityLines() {
  // REPLACE WITH: Vision AI model status API
  return parseCSV('quality_lines.csv').map(r => ({
    line:     r.line,
    rate:     num(r.quality_rate_pct),
    defects:  num(r.defects_today),
    escapes:  num(r.escapes_today),
    model:    r.model_version,
  }));
}

export function loadTwinKPIs() {
  // REPLACE WITH: Azure Digital Twins API
  return parseCSV('twin_kpis.csv').map(r => ({
    kpi_id:               r.kpi_id,
    kpi_name:             r.kpi_name,
    unit:                 r.unit,
    actual:               num(r.actual),
    twin_predicted:       num(r.twin_predicted),
    threshold_pct:        num(r.divergence_threshold_pct),
    asset_id:             r.asset_id || null,
  }));
}

// ── Reload all (call on file-change watch if needed) ──────────────────────────
export function reloadAll() {
  logger.info('[CSV] Reloading all CSV data files');
  return {
    machines:         loadMachines(),
    utilities:        loadUtilities(),
    yieldParams:      loadYieldParams(),
    productionOrders: loadProductionOrders(),
    limsResults:      loadLimsResults(),
    workOrders:       loadWorkOrders(),
    supplyRisks:      loadSupplyRisks(),
    energyAssets:     loadEnergyAssets(),
    energyHourly:     loadEnergyHourly(),
    safetyZones:      loadSafetyZones(),
    safetyPermits:    loadSafetyPermits(),
    qualityDefects:   loadQualityDefects(),
    qualityLines:     loadQualityLines(),
    twinKPIs:         loadTwinKPIs(),
  };
}

export function loadTwinComponents(): Record<string, any[]> {
  const rows = loadCsv('twin_components.csv');
  const result: Record<string, any[]> = {};
  for (const r of rows) {
    if (!result[r.asset_id]) result[r.asset_id] = [];
    result[r.asset_id].push({
      c: r.component,
      h: Number(r.health),
      t: Number(r.temp),
      v: Number(r.vib),
      a: r.alert === 'true',
    });
  }
  return result; // REPLACE WITH: CMMS component registry API
}

export function loadParts(): { orders: any[]; inventory: any[] } {
  const rows = loadCsv('parts.csv');
  const orders = rows.map(r => ({
    id: r.order_id, sku: r.sku, part: r.part_name,
    asset: r.asset_id, qty: Number(r.qty),
    cost: Number(r.unit_cost_inr) * Number(r.qty),
    status: r.status, rules: r.rules,
    rul: Number(r.rul_days), lead: Number(r.lead_days),
  }));
  const inventory = rows.map(r => ({
    sku: r.sku, name: r.part_name, asset: r.asset_id,
    stock: Number(r.stock), reorder: Number(r.reorder_qty),
    lead: Number(r.lead_days), cost: Number(r.unit_cost_inr),
    autoOrder: r.auto_order === 'true',
  }));
  return { orders, inventory }; // REPLACE WITH: ERP/CMMS spare parts API
}

export function loadPlatformConfig() {
  const rows = loadCsv('platform_config.csv');

  const get = (section: string) => rows.filter(r => r.section === section);

  // Benchmark trend
  const benchmarkTrend = get('benchmark_trend').map(r => ({
    day: r.label, p1: Number(r.value), p2: Number(r.extra1), bench: Number(r.extra2),
  }));

  // Benchmarks
  const benchmarks: Record<string, number> = {};
  for (const r of get('benchmark')) benchmarks[r.key] = Number(r.value);

  // Feature importance
  const yieldFeats = get('yield_feature').map(r => ({ f: r.label, v: Number(r.value) }));
  const pdmFeats   = get('pdm_feature').map(r => ({ f: r.label, v: Number(r.value) }));

  // Model history
  const modelYield = get('model_yield').map(r => ({
    date: r.label, r2: Number(r.value), mse: Number(r.extra1),
    samples: Number(r.extra2), status: r.extra3,
  }));
  const modelPdm = get('model_pdm').map(r => ({
    date: r.label, f1: Number(r.value), prec: Number(r.extra1),
    rec: Number(r.extra2), samples: Number(r.extra3), status: r.extra4,
  }));

  // Adoption trend
  const adoptionTrend = get('adoption').map(r => ({
    day: r.label, accepted: Number(r.value), rejected: Number(r.extra1),
  }));

  // Semantic KPIs
  const semanticKpi: Record<string, any> = {};
  for (const r of get('semantic_kpi')) {
    semanticKpi[r.key] = {
      name:    r.label,
      value:   r.value,
      unit:    r.unit,
      formula: r.extra1,
      src:     r.extra2,
      agents:  r.extra3 ? r.extra3.split(';') : [],
    };
  }

  const qualityModel = get('quality_model').map(r => ({
    date: r.label, mAP: Number(r.value), precision: Number(r.extra1),
    recall: Number(r.extra2), samples: Number(r.extra3), status: r.extra4,
  }));
  const qualityFeats = get('quality_feature').map(r => ({ f: r.label, v: Number(r.value) }));
  // Issue fix: keep the sub/notes column (was dropped — UI hardcoded the notes)
  const qualityKpis: Record<string, any> = {};
  for (const r of get('quality_kpi')) qualityKpis[r.key] = { value: r.value, sub: r.extra1 ?? '' };
  const retraining: Record<string, any> = {};
  for (const r of get('retraining')) retraining[r.key] = {
    version: r.value, date: r.extra1, sub: r.extra2, algo: r.extra3, nextVersion: r.extra4,
  };

  // Issue fix: OEE economics factors (were hardcoded *48000 and *1.03 in the UI)
  const oeeEconomics: Record<string, number> = {};
  for (const r of get('oee_economics')) oeeEconomics[r.key] = Number(r.value);
  // Issue fix: energy thresholds/targets (were render-layer literals)
  const energyConfig: Record<string, any> = {};
  for (const r of get('energy_config')) energyConfig[r.key] = { value: r.value, unit: r.unit };
  // Issue fix: PdM roadmap (was a static array in the UI)
  const pdmRoadmap = get('pdm_roadmap').map(r => ({ ver: r.label, status: r.value, desc: r.extra1 }));
  // Issue fix: twin sync settings (was a '30s' literal in the Calibration tab)
  const twinConfig: Record<string, any> = {};
  for (const r of get('twin_config')) twinConfig[r.key] = { value: r.value, unit: r.unit };

  return { benchmarkTrend, benchmarks, yieldFeats, pdmFeats, modelYield, modelPdm,
           adoptionTrend, semanticKpi, qualityModel, qualityFeats, qualityKpis, retraining,
           oeeEconomics, energyConfig, pdmRoadmap, twinConfig };
}

export function loadEnergyWaste() {
  return loadCsv('energy_waste.csv').map(r => ({
    type: r.type, kwh: Number(r.kwh),
    cost: Number(r.cost_inr), asset: r.asset, desc: r.description,
  })); // REPLACE WITH: Energy anomaly detection API
}

export function loadCarbonTrend() {
  return loadCsv('carbon_trend.csv').map(r => ({
    m: r.month.slice(0,3), v: Number(r.carbon_intensity), unit: r.unit,
  })); // REPLACE WITH: Carbon accounting API / smart meter data
}

export function loadDemandForecast() {
  return loadCsv('demand_forecast.csv').map(r => ({
    w: r.week,
    actual: r.actual_kg ? Number(r.actual_kg) : null,
    forecast: r.forecast_kg ? Number(r.forecast_kg) : null,
  })); // REPLACE WITH: SAP PP demand planning API
}

export function loadTwinScenarios() {
  return loadCsv('twin_scenarios.csv').map(r => ({
    id: r.id, name: r.name, status: r.status, type: r.type, desc: r.description,
    impact: r.impact, confidence: Number(r.confidence), horizon: r.horizon,
  })); // REPLACE WITH: Azure Digital Twins scenario API
}

export function loadEnergyDispatch() {
  return loadCsv('energy_dispatch.csv').map(r => ({
    id: r.id, asset: r.asset, action: r.action,
    saving: `${r.saving_kwh} kWh - Rs${r.saving_inr}`,
    status: r.status, type: r.type,
  })); // REPLACE WITH: SCADA demand response API
}

export function loadTechStack(): Record<string, any[]> {
  const rows = loadCsv('tech_stack.csv');
  const result: Record<string, any[]> = {};
  for (const r of rows) {
    if (!result[r.agent]) result[r.agent] = [];
    result[r.agent].push({
      label: r.label,
      col:   r.color_token,
      items: r.items.split('|'),
    });
  }
  return result;
  // Phase 2: REPLACE WITH Azure App Configuration — az appconfig kv list
}

export function loadSemanticKpiDefs(): any[] {
  return loadCsv('semantic_kpi_definitions.csv').map(r => ({
    id:         r.kpi_id,
    name:       r.name,
    formula:    r.formula,
    unit:       r.unit,
    agents:     r.agents.split(';'),
    src:        r.source_system,
    governance: r.governance,
  }));
  // Phase 2: REPLACE WITH Azure SQL — SELECT * FROM semantic_kpi_definitions
}

export function loadPersonas(): Record<string, any> {
  const colorMap: Record<string, string> = {
    blue: '#2563eb', oee: '#f59e0b', pdm: '#8b5cf6', yield: '#10b981',
  };
  const result: Record<string, any> = {};
  for (const r of loadCsv('personas.csv')) {
    const kpis: [string, string][] = [];
    for (let i = 1; i <= 4; i++) {
      const label = r[`kpi_${i}_label`];
      const key   = r[`kpi_${i}_key`];
      if (label) kpis.push([label, key]);
    }
    result[r.persona_id] = {
      label: r.label,
      col:   colorMap[r.color_token] ?? r.color_token,
      kpis,
    };
  }
  return result;
  // Phase 2: REPLACE WITH Azure SQL + Azure AD role mapping
}

export function loadBaselines(): Record<string, any> {
  const result: Record<string, any> = {};
  for (const r of loadCsv('baselines.csv')) {
    result[r.metric_id] = {
      agent:       r.agent,
      label:       r.label,
      baseline:    Number(r.baseline_value),
      unit:        r.baseline_unit,
      date:        r.baseline_date,
      target:      Number(r.target_value),
      targetLabel: r.target_label,
      current:     Number(r.current_value),
      note:        r.measurement_note,
      // delta = how much improved vs baseline (positive = improvement)
      delta:       +(((Number(r.baseline_value) - Number(r.current_value)) /
                      Number(r.baseline_value)) * 100).toFixed(1),
    };
  }
  return result;
  // Phase 2: REPLACE WITH Azure SQL — compute delta vs actual live data
}

export function loadTechnicians() {
  return loadCsv('technicians.csv').map(r => ({
    id: r.id, name: r.name, role: r.role,
    shift: r.shift, spec: r.specialisation,
  })); // REPLACE WITH: HR system / CMMS technician registry
}

export function loadShifts() {
  return loadCsv('shifts.csv').map(r => ({
    id:      r.shift_id,
    name:    r.name,
    role:    r.role,
    start:   r.start_time,
    end:     r.end_time,
    assets:  Number(r.assets_managed),
    wos:     Number(r.open_wos),
  })); // REPLACE WITH: HR shift management system
}

export function loadPdmRules() {
  return loadCsv('pdm_rules.csv').map(r => ({
    id:   r.rule_id,
    cond: r.condition,
    act:  r.action,
    sev:  r.severity,
    desc: r.description,
  })); // REPLACE WITH: Business rules engine / Azure App Configuration
}

export function loadConflictRules(): ConflictRule[] {
  return loadCsv('conflict_rules.csv').map(r => ({
    id:              r.rule_id,
    description:     r.description,
    triggerAgent:    r.trigger_agent,
    blockAgent:      r.block_agent,
    blockActionType: r.block_action_type,
    assetScope:      r.asset_scope as 'asset' | 'zone' | 'global',
    reason:          r.reason,
  }));
  // REPLACE WITH: CMMS conflict rule API or config service
}

export interface ConflictRule {
  id:              string;
  description:     string;
  triggerAgent:    string;
  blockAgent:      string;
  blockActionType: string;
  assetScope:      'asset' | 'zone' | 'global';
  reason:          string;
}

export function loadScenarioSteps(): ScenarioStepConfig[] {
  return loadCsv('scenario_steps.csv').map(r => ({
    stepNum:          Number(r.step_num),
    agent:            r.agent,
    actionType:       r.action_type,
    delayMs:          Number(r.delay_ms),
    impactType:       r.impact_type,
    impactUnit:       r.impact_unit,
    descriptionTpl:   r.description_template,
    actionLabelOk:    r.action_label_if_ok,
    actionLabelNotOk: r.action_label_if_not_ok,
    eventType:        r.event_type,
    severity:         r.severity as 'critical' | 'warning' | 'info',
  }));
  // REPLACE WITH: config service / admin UI in Phase 2
}

export interface ScenarioStepConfig {
  stepNum:          number;
  agent:            string;
  actionType:       string;
  delayMs:          number;
  impactType:       string;
  impactUnit:       string;
  descriptionTpl:   string;
  actionLabelOk:    string;
  actionLabelNotOk: string;
  eventType:        string;
  severity:         'critical' | 'warning' | 'info';
}

export function loadDemandCurve(): number[] {
  const rows = parseCSV('demand_curve.csv');
  const curve = new Array(24).fill(1.0);
  for (const r of rows) {
    const h = Number(r.hour);
    if (h >= 0 && h < 24 && r.factor !== undefined) curve[h] = Number(r.factor);
  }
  return curve;
}
