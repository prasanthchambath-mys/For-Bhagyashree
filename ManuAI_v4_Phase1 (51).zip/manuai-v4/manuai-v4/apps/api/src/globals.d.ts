/// <reference types="node" />
// Declare Node.js globals for environments where @types/node is not available
declare const process: NodeJS.Process;
declare const __dirname: string;
declare const __filename: string;
declare function setInterval(callback: (...args: any[]) => void, ms?: number): NodeJS.Timeout;
declare function clearInterval(intervalId: NodeJS.Timeout | undefined): void;
declare function setTimeout(callback: (...args: any[]) => void, ms?: number): NodeJS.Timeout;
declare function clearTimeout(timeoutId: NodeJS.Timeout | undefined): void;
declare function require(id: string): any;
