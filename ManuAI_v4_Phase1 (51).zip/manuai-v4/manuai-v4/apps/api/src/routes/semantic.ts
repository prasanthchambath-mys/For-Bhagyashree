import { semanticRouter } from './all-routes';
export default semanticRouter;
