/**
 * ManuAI — History Routes
 * Serves all historical data from SQLite database.
 * These endpoints power the trend charts across all 8 agents.
 */

import { Router } from 'express';
import {
  getOeeTrend, getPlantOeeTrend, getOeeSummary, getLossByType, getWeeklyLossByType, getOeeByHourRange,
  getHealthTrend, getAllHealthSummary,
  getAlertHistory, getAlertStats,
  getBatchHistory, getBatchStats,
  getYieldParamTrend,
  getEnergyTrend, getEnergyByAsset,
  getSafetyEventHistory, getSafetyStats,
  getMonthlyOeeByLineGroup } from '../database/queries';
import { loadShifts, loadTechnicians } from '../data/csv-loader';
import { ackAlertInDB } from '../database/writer';
import { logger } from '../middleware/logger';

const router = Router();

// ── OEE History ────────────────────────────────────────────────────────────────
router.get('/oee/trend/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = getOeeTrend(req.params.machineId, days);
  res.json({ machineId: req.params.machineId, days, data });
});

router.get('/oee/plant-trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getPlantOeeTrend(days) });
});

router.get('/oee/summary', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getOeeSummary(days) });
});

// ── PdM Health History ─────────────────────────────────────────────────────────
router.get('/pdm/health/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ machineId: req.params.machineId, days, data: getHealthTrend(req.params.machineId, days) });
});

router.get('/pdm/health-summary', (_req, res) => {
  res.json({ data: getAllHealthSummary() });
});

// ── Alerts History ─────────────────────────────────────────────────────────────
router.get('/alerts/history', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const severity = req.query.severity as string | undefined;
  const data = getAlertHistory(days, severity);
  res.json({ days, total: data.length, data });
});

router.get('/alerts/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getAlertStats(days) });
});

router.post('/alerts/:id/ack', (req, res) => {
  const ackedBy = req.user?.name ?? 'Unknown';
  const ok = ackAlertInDB(req.params.id, ackedBy);
  if (!ok) { res.status(404).json({ error: 'Alert not found' }); return; }
  logger.info('Alert acknowledged', { id: req.params.id, by: ackedBy });
  res.json({ success: true, alertId: req.params.id, ackedBy });
});

// ── Batch / Yield History ──────────────────────────────────────────────────────
router.get('/yield/batches', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchHistory(days) });
});

router.get('/yield/batch-stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchStats(days) });
});

router.get('/yield/param-trend/:paramId', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ paramId: req.params.paramId, days, data: getYieldParamTrend(req.params.paramId, days) });
});

// ── Energy History ─────────────────────────────────────────────────────────────
router.get('/energy/trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getEnergyTrend(days) });
});

router.get('/energy/by-asset', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ days, data: getEnergyByAsset(days) });
});

// ── Safety History ─────────────────────────────────────────────────────────────
router.get('/safety/events', (req, res) => {
  const days = Number(req.query.days ?? 30);
  // Issue fix: serve a real action field (was synthesized in the frontend access layer)
  const data = (getSafetyEventHistory(days) as any[]).map((e:any)=>({ ...e,
    action: e.resolved_at ? `Resolved — ${e.zone} readings normalised.`
          : e.severity === 'critical' ? `Evacuation alert issued for ${e.zone}. Hot-work permits blocked.`
          : `Precursor detected in ${e.zone}. Monitor and investigate.` }));
  res.json({ days, data });
});

router.get('/safety/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getSafetyStats(days) });
});


// ── Pre-computed Six Losses + Loss Trend (Issue 13: weights from config) ──────
router.get('/oee/six-losses', (req, res) => {
  const days = Number(req.query.days ?? 30);
  // Issue fix: aggregate REAL loss minutes per loss_type from oee_readings
  // (was total x fixed config weights — fabricated ratios)
  const CAT = [
    { name: 'Unplanned Breakdown', col: '#ef4444' },
    { name: 'Speed Loss',          col: '#f97316' },
    { name: 'Minor Stops',         col: '#fbbf24' },
    { name: 'Changeover & Setup',  col: '#f59e0b' },
    { name: 'Startup Defects',     col: '#84cc16' },
    { name: 'In-process Defects',  col: '#a3e635' },
  ];
  const rows = getLossByType(days) as any[];
  const totalMin = rows.reduce((s, r) => s + Number(r.total_min), 0);
  const byType: Record<string, any> = {};
  for (const r of rows) byType[r.loss_type] = r;
  const losses = CAT.map(c => {
    const r = byType[c.name];
    return {
      name: c.name, col: c.col,
      min:  r ? Math.round(Number(r.total_min)) : 0,
      pct:  r && totalMin > 0 ? +(Number(r.total_min) / totalMin * 100).toFixed(1) : 0,
      cnt:  r ? Number(r.machine_cnt) : 0,
      machines: r?.machines ? String(r.machines).split(',') : [],
    };
  });
  res.json({ days, losses });
});

router.get('/oee/loss-trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  // Issue fix: weekly bars from REAL loss minutes per loss_type
  // (was (100 - avgOee) x fixed multipliers — fabricated)
  const rows = getWeeklyLossByType(Math.max(days, 42)) as any[];
  const byWeek: Record<string, Record<string, number>> = {};
  for (const r of rows) {
    byWeek[r.wk] = byWeek[r.wk] ?? {};
    byWeek[r.wk][r.loss_type] = Math.round(Number(r.total_min));
  }
  const weeks = Object.keys(byWeek).sort().map((wk, i) => ({
    w: `W${String(i + 1).padStart(2, '0')}`,
    brk: byWeek[wk]['Unplanned Breakdown'] ?? 0,
    chg: byWeek[wk]['Changeover & Setup'] ?? 0,
    mst: byWeek[wk]['Minor Stops'] ?? 0,
    spd: byWeek[wk]['Speed Loss'] ?? 0,
    def: byWeek[wk]['In-process Defects'] ?? 0,
  }));
  res.json({ days, weeks: weeks.slice(-6) });
});


router.get('/oee/scorecard', (req, res) => {
  const days = Number(req.query.days ?? 180);
  const rows = getMonthlyOeeByLineGroup(days);
  const months: Record<string, { p1?: number; p2?: number }> = {};
  for (const r of rows) {
    if (!months[r.month]) months[r.month] = {};
    if (r.grp === 'g1') months[r.month].p1 = +Number(r.avg_oee).toFixed(1);
    else months[r.month].p2 = +Number(r.avg_oee).toFixed(1);
  }
  const out = Object.entries(months).slice(-6).map(([m, v]) => ({
    m: new Date(m + '-01').toLocaleString('default', { month: 'short' }),
    p1: v.p1 ?? 0, p2: v.p2 ?? 0, target: 85,
  }));
  res.json({ days, scorecard: out });
});

export default router;

// ── Shifts (computed from OEE history by hour of day) ─────────────────────────
router.get('/oee/shifts', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = getPlantOeeTrend(days);
  // Group into shift buckets from daily data
  // Morning 06-14, Afternoon 14-22, Night 22-06
  const shiftDefs = loadShifts();
  const techList  = loadTechnicians();
  const now = new Date();
  const nowHour = now.getHours();
  const shifts = shiftDefs.map((s, i) => {
    const startH = parseInt(s.start);
    const endH   = parseInt(s.end);
    const active = nowHour >= startH && (endH === 6 ? nowHour >= 22 || nowHour < 6 : nowHour < endH);
    const tech   = techList.find(t => t.shift === s.name);
    return {
      shift:  s.name,
      tech:   tech?.name ?? 'Unassigned',
      role:   s.role,
      assets: s.assets,
      wos:    s.wos,
      status: active ? 'active' : i === ((shiftDefs.findIndex((_,j)=>{const sH=parseInt(shiftDefs[j].start);return nowHour>=sH;})+1)%shiftDefs.length) ? 'upcoming' : 'scheduled',
      start:  s.start,
      end:    s.end,
      // Issue fix: real OEE for this shift's hour window (was plantAvg x invented 0.97+i*0.01)
      avgOee: (() => {
        try {
          const sh = parseInt(String(s.start).split(':')[0]);
          const eh = parseInt(String(s.end).split(':')[0]);
          const v = getOeeByHourRange(isNaN(sh)?0:sh, isNaN(eh)?24:eh, 7);
          return v ?? (data.length ? +(data.reduce((s2,d)=>s2+d.avg_oee,0)/data.length).toFixed(1) : 0);
        } catch { return data.length ? +(data.reduce((s2,d)=>s2+d.avg_oee,0)/data.length).toFixed(1) : 0; }
      })(),
    };
  });
  res.json({ data: shifts });
});
