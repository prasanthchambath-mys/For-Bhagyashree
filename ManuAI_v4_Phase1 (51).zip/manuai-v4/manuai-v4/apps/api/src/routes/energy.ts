import { energyRouter } from './all-routes';
import {
  loadEnergyWaste, loadCarbonTrend,
  loadDemandForecast, loadEnergyDispatch,
} from '../data/csv-loader';


energyRouter.get('/waste',           (_req, res) => res.json({ waste:   loadEnergyWaste() }));
energyRouter.get('/carbon',          (_req, res) => res.json({ data:    loadCarbonTrend() }));
energyRouter.get('/demand-forecast', (_req, res) => res.json({ data:    loadDemandForecast() }));
energyRouter.get('/dispatch',        (_req, res) => res.json({ actions: loadEnergyDispatch() }));

energyRouter.get('/live', (_req, res) => {
  // REPLACE WITH: Azure IoT Hub / SCADA real-time energy feed in Phase 3
  // Issue fix: serve live simulation state (ticking kW + computed anomaly),
  // falling back to static CSV only if the sim is unavailable.
  try {
    const { getPlantState } = require('../simulation/engine');
    const simAssets = getPlantState().energyAssets;
    if (Array.isArray(simAssets) && simAssets.length) {
      return res.json({ assets: simAssets.map((a: any) => ({
        id: a.id, name: a.name, kw: a.kw, anomaly: !!a.anomaly,
      })) });
    }
  } catch { /* fall through to CSV */ }
  try {
    const { loadEnergyAssets } = require('../data/csv-loader');
    res.json({ assets: loadEnergyAssets() });
  } catch {
    res.json({ assets: [] });
  }
});

export default energyRouter;
