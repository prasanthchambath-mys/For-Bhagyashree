/**
 * ManuAI — Semantic Core API Routes
 *
 * Exposes the enterprise semantic data model via REST API.
 * These routes are the enterprise-grade layer between source systems
 * and agent dashboards.
 *
 * /api/semantic/dimensions/*  — Dimension tables (assets, lines, suppliers)
 * /api/semantic/kpis/*        — KPI engine values and trends
 * /api/semantic/events/*      — Persistent cross-agent event log
 * /api/semantic/scenarios/*   — Orchestration scenario status
 */

import { Router } from 'express';
import { getDb } from '../database/connection';
import { getLatestKPIs, getKPITrend } from '../kpi/engine';
import { getRecentEvents, getEventWithImpacts, getEventsByAsset } from '../database/event-store';
import { getActiveScenarios, getScenarioSteps } from '../orchestration/scenario-engine';
import { logger } from '../middleware/logger';

export const semanticCoreRouter = Router();

// ── Dimension tables ──────────────────────────────────────────────────────────
semanticCoreRouter.get('/dimensions/plants', (_req, res) => {
  try {
    res.json({ plants: getDb().prepare('SELECT * FROM dim_plant').all() });
  } catch { res.json({ plants: [] }); }
});

semanticCoreRouter.get('/dimensions/lines', (_req, res) => {
  try {
    res.json({ lines: getDb().prepare('SELECT l.*, p.plant_name FROM dim_line l JOIN dim_plant p ON p.plant_id=l.plant_id').all() });
  } catch { res.json({ lines: [] }); }
});

semanticCoreRouter.get('/dimensions/assets', (_req, res) => {
  try {
    res.json({ assets: getDb().prepare('SELECT * FROM dim_asset ORDER BY asset_type, asset_name').all() });
  } catch { res.json({ assets: [] }); }
});

semanticCoreRouter.get('/dimensions/assets/:assetId', (req, res) => {
  try {
    const asset = getDb().prepare('SELECT * FROM dim_asset WHERE asset_id=?').get(req.params.assetId);
    if (!asset) { res.status(404).json({ error: 'Asset not found' }); return; }
    res.json({ asset });
  } catch { res.status(500).json({ error: 'Query failed' }); }
});

semanticCoreRouter.get('/dimensions/suppliers', (_req, res) => {
  try {
    res.json({ suppliers: getDb().prepare('SELECT * FROM dim_supplier ORDER BY risk_category, supplier_name').all() });
  } catch { res.json({ suppliers: [] }); }
});

semanticCoreRouter.get('/dimensions/materials', (_req, res) => {
  try {
    res.json({ materials: getDb().prepare('SELECT * FROM dim_material').all() });
  } catch { res.json({ materials: [] }); }
});

// ── KPI Engine ────────────────────────────────────────────────────────────────
semanticCoreRouter.get('/kpis/latest', (req, res) => {
  const assetId = req.query.asset_id as string | undefined;
  const scope   = assetId ? 'asset' : 'plant';
  res.json({ kpis: getLatestKPIs(scope, assetId), scope, asset_id: assetId ?? null });
});

semanticCoreRouter.get('/kpis/trend/:kpiId', (req, res) => {
  const days    = Number(req.query.days ?? 30);
  const assetId = req.query.asset_id as string | undefined;
  res.json({ kpi_id: req.params.kpiId, days, data: getKPITrend(req.params.kpiId, days, assetId) });
});

semanticCoreRouter.get('/kpis/definitions', (_req, res) => {
  try {
    res.json({ definitions: getDb().prepare('SELECT * FROM semantic_kpi_definition').all() });
  } catch { res.json({ definitions: [] }); }
});

semanticCoreRouter.get('/kpis/summary', (_req, res) => {
  try {
    const db = getDb();
    // Latest value for each plant-level KPI
    const summary = db.prepare(`
      SELECT k.kpi_id, k.kpi_name, k.unit, v.value, v.target, v.status, v.ts
      FROM semantic_kpi_definition k
      LEFT JOIN semantic_kpi_value v ON v.kpi_id = k.kpi_id AND v.scope = 'plant'
        AND v.ts = (SELECT MAX(ts) FROM semantic_kpi_value WHERE kpi_id=k.kpi_id AND scope='plant')
      ORDER BY k.kpi_id
    `).all();
    res.json({ summary, computed_at: new Date().toISOString() });
  } catch { res.json({ summary: [] }); }
});

// ── Event Store ───────────────────────────────────────────────────────────────
semanticCoreRouter.get('/events', (req, res) => {
  const limit = Number(req.query.limit ?? 50);
  res.json({ events: getRecentEvents(limit) });
});

semanticCoreRouter.get('/events/:eventId', (req, res) => {
  const result = getEventWithImpacts(req.params.eventId);
  if (!result) { res.status(404).json({ error: 'Event not found' }); return; }
  res.json(result);
});

semanticCoreRouter.get('/events/asset/:assetId', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ asset_id: req.params.assetId, events: getEventsByAsset(req.params.assetId, days) });
});

semanticCoreRouter.get('/events/impacts', (_req, res) => {
  try {
    const impacts = getDb().prepare(`
      SELECT i.*, e.event_type, e.from_agent, e.asset_id, e.severity, e.ts as event_ts
      FROM semantic_event_impact i
      JOIN semantic_event e ON e.event_id = i.event_id
      ORDER BY i.ts DESC LIMIT 100
    `).all();
    res.json({ impacts });
  } catch { res.json({ impacts: [] }); }
});

// ── Orchestration Scenarios ───────────────────────────────────────────────────
semanticCoreRouter.get('/scenarios', (_req, res) => {
  res.json({ scenarios: getActiveScenarios() });
});

semanticCoreRouter.get('/scenarios/:scenarioId', (req, res) => {
  const steps = getScenarioSteps(req.params.scenarioId);
  if (!steps.length) { res.status(404).json({ error: 'Scenario not found' }); return; }
  res.json(steps[0]);
});

// ── Data model overview ───────────────────────────────────────────────────────
semanticCoreRouter.get('/model', (_req, res) => {
  try {
    const db = getDb();
    const counts = {
      dim_plant:    (db.prepare('SELECT COUNT(*) as n FROM dim_plant').get() as any).n,
      dim_line:     (db.prepare('SELECT COUNT(*) as n FROM dim_line').get() as any).n,
      dim_asset:    (db.prepare('SELECT COUNT(*) as n FROM dim_asset').get() as any).n,
      dim_supplier: (db.prepare('SELECT COUNT(*) as n FROM dim_supplier').get() as any).n,
      dim_material: (db.prepare('SELECT COUNT(*) as n FROM dim_material').get() as any).n,
      semantic_kpi_definition: (db.prepare('SELECT COUNT(*) as n FROM semantic_kpi_definition').get() as any).n,
      semantic_kpi_value:      (db.prepare('SELECT COUNT(*) as n FROM semantic_kpi_value').get() as any).n,
      semantic_event:          (db.prepare('SELECT COUNT(*) as n FROM semantic_event').get() as any).n,
      semantic_event_impact:   (db.prepare('SELECT COUNT(*) as n FROM semantic_event_impact').get() as any).n,
      orchestration_scenario:  (db.prepare('SELECT COUNT(*) as n FROM orchestration_scenario').get() as any).n,
    };
    res.json({
      model_version: 2,
      architecture: 'Semantic Core Data Model',
      tables: counts,
      description: 'Enterprise semantic data model with dimensions, facts, KPI engine and event orchestration.',
    });
  } catch(err) { res.status(500).json({ error: String(err) }); }
});
