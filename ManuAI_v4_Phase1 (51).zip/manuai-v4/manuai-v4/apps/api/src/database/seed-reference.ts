/**
 * Issue 8 fix: persist reference CSV data to SQLite on startup.
 * Provides audit trail + DB queryability. Routes still serve from CSV in Phase 1;
 * Phase 2 will flip routes to query these tables.
 */
import { getDb } from './connection';
import { loadCsvRaw } from '../data/csv-loader';
import { logger } from '../middleware/logger';

const REF_SOURCES: Array<{ csv: string; table: string; cols: string[] }> = [
  { csv: 'supply_risks.csv',    table: 'ref_supply_risks',
    cols: ['supplier_id','supplier_name','sku','description','current_stock_days','reorder_point_days','lead_time_contracted_days','lead_time_actual_days','monthly_consumption','unit_cost_inr','single_source','country_of_origin','financial_risk_score'] },
  { csv: 'quality_defects.csv', table: 'ref_quality_defects',
    cols: ['id','time','line','component','type','severity','action','confidence'] },
  { csv: 'twin_kpis.csv',       table: 'ref_twin_kpis',
    cols: ['kpi_id','kpi_name','unit','actual','twin_predicted','divergence_threshold_pct','asset_id'] },
  { csv: 'safety_permits.csv',  table: 'ref_safety_permits',
    cols: ['ptw_id','asset_id','work_type','technician','status','jha_complete','isolation_verified','competency_valid'] },
  { csv: 'yield_params.csv',    table: 'ref_yield_params',
    cols: ['id','name','unit','val','tgt','min','max','drift_rate'] },
];

export function seedReferenceData(): void {
  const db = getDb();
  const now = Date.now();
  let total = 0;
  for (const src of REF_SOURCES) {
    try {
      const rows = loadCsvRaw(src.csv);
      if (!rows.length) continue;
      db.prepare(`DELETE FROM ${src.table}`).run(); // refresh snapshot each boot
      const placeholders = src.cols.map(() => '?').join(',');
      const ins = db.prepare(`INSERT INTO ${src.table} (${src.cols.join(',')}, loaded_at) VALUES (${placeholders}, ?)`);
      const tx = db.transaction((rs: any[]) => {
        for (const r of rs) ins.run(...src.cols.map(c => r[c] ?? null), now);
      });
      tx(rows);
      total += rows.length;
    } catch (e) {
      logger.warn(`[RefSeed] ${src.csv} failed: ${e}`);
    }
  }
  logger.info(`[RefSeed] ${total} reference rows persisted to SQLite (Issue 8)`);
}
