/**
 * ManuAI — Semantic Event Store
 *
 * Persists every cross-agent event to SQLite.
 * Replaces the in-memory recentEvents[] array in semantic/service.ts.
 *
 * Every event now has:
 *   semantic_event          — the root event with full payload
 *   semantic_event_impact   — one row per impacted agent
 *
 * This gives a full audit trail: who fired it, what it impacted,
 * what actions were taken. Enterprise-grade traceability.
 */

import { getDb } from './connection';
import { logger } from '../middleware/logger';
import { CrossAgentEvent } from '../semantic/service';

export function persistSemanticEvent(event: CrossAgentEvent): void {
  try {
    const db = getDb();
    db.prepare(`
      INSERT OR IGNORE INTO semantic_event
        (event_id, event_type, from_agent, asset_id, severity, message, payload, ts)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      event.id,
      event.type,
      event.from,
      event.asset || null,
      event.sev,
      event.msg,
      JSON.stringify(event),
      Date.now()
    );
  } catch(err) {
    logger.warn('[EventStore] Event persist error', { error: String(err) });
  }
}

export function persistEventImpact(
  eventId: string,
  targetAgent: string,
  impactType: string,
  impactValue: number | null,
  impactUnit: string,
  description: string,
  actionTaken?: string,
  actionRef?: string
): void {
  try {
    getDb().prepare(`
      INSERT INTO semantic_event_impact
        (event_id, target_agent, impact_type, impact_value, impact_unit, description, action_taken, action_ref, ts)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(eventId, targetAgent, impactType, impactValue, impactUnit, description, actionTaken ?? null, actionRef ?? null, Date.now());
  } catch(err) {
    logger.warn('[EventStore] Impact persist error', { error: String(err) });
  }
}

export function getRecentEvents(limit = 50): any[] {
  try {
    return getDb().prepare(`
      SELECT e.*, COUNT(i.id) as impact_count
      FROM semantic_event e
      LEFT JOIN semantic_event_impact i ON i.event_id = e.event_id
      GROUP BY e.event_id
      ORDER BY e.ts DESC
      LIMIT ?
    `).all(limit);
  } catch { return []; }
}

export function getEventWithImpacts(eventId: string): any {
  try {
    const db = getDb();
    const event   = db.prepare('SELECT * FROM semantic_event WHERE event_id=?').get(eventId);
    const impacts = db.prepare('SELECT * FROM semantic_event_impact WHERE event_id=? ORDER BY ts ASC').all(eventId);
    return { event, impacts };
  } catch { return null; }
}

export function getEventsByAsset(assetId: string, days = 7): any[] {
  try {
    const since = Date.now() - days * 86400000;
    return getDb().prepare(`
      SELECT * FROM semantic_event
      WHERE asset_id=? AND ts>=?
      ORDER BY ts DESC
    `).all(assetId, since);
  } catch { return []; }
}

export function resolveEvent(eventId: string): void {
  try {
    getDb().prepare('UPDATE semantic_event SET resolved_at=? WHERE event_id=?').run(Date.now(), eventId);
  } catch { /* non-fatal */ }
}
