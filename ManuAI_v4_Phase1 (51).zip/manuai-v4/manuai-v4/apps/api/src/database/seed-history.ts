/**
 * ManuAI — Historical Data Generator
 *
 * Runs ONCE at startup when the database is empty.
 * Generates 30 days of realistic synthetic history backwards from now.
 * History is internally consistent with the live simulation state.
 *
 * Generates ~300,000 records in ~30 seconds.
 */

import { getDb } from './connection';
import { loadMachines, loadYieldParams, loadEnergyAssets, loadSafetyZones, loadTechnicians } from '../data/csv-loader';
import { logger } from '../middleware/logger';

const DAYS = 30;
const OEE_INTERVAL_MS    = 5  * 60 * 1000;  // every 5 min
const ENERGY_INTERVAL_MS = 30 * 60 * 1000;  // every 30 min
const YIELD_INTERVAL_MS  = 5  * 60 * 1000;  // every 5 min

function noise(scale = 1): number {
  return (Math.random() - 0.5) * 2 * scale;
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

// 24-hour demand curve for energy
const DEMAND_CURVE = [
  0.55,0.50,0.46,0.74,0.97,1.02,0.98,1.01,
  1.06,0.91,0.72,0.60,0.55,0.50,0.46,0.74,
  0.97,1.02,0.98,1.01,1.06,0.91,0.72,0.60,
];

export async function seedHistory(): Promise<void> {
  const db = getDb();
  const now = Date.now();
  const startMs = now - DAYS * 24 * 3600 * 1000;

  logger.info('[DB] Seeding 30 days of historical data — this takes ~30 seconds...');

  const machines = loadMachines();
  const techName = loadTechnicians()[0]?.name ?? 'Technician';
  const yieldParams = loadYieldParams();
  const energyAssets = loadEnergyAssets();

  // ── Insert helpers (prepared statements for speed) ──────────────────────────
  const insertOee = db.prepare(`
    INSERT INTO oee_readings (machine_id, machine_name, line, ts, oee, avail, perf, qual, loss_type, loss_min)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertHealth = db.prepare(`
    INSERT INTO machine_health (machine_id, ts, health, rul, vib, temp, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const insertBatch = db.prepare(`
    INSERT OR IGNORE INTO batches (id, product, qty_kg, plan_yield, actual_yield, status, started_at, completed_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertYield = db.prepare(`
    INSERT INTO yield_history (param_id, param_name, ts, value, target, warn)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const insertEnergy = db.prepare(`
    INSERT INTO energy_readings (asset_id, asset_name, ts, kw, anomaly)
    VALUES (?, ?, ?, ?, ?)
  `);
  const insertAlert = db.prepare(`
    INSERT OR IGNORE INTO alerts (id, machine_id, machine_name, line, type, severity, message, ts, acked, acked_by, acked_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertSafety = db.prepare(`
    INSERT OR IGNORE INTO safety_events (id, zone, event_type, severity, h2s, co, ch4, ts, resolved_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // ── Use a transaction for speed (100x faster than individual inserts) ────────
  const insertAll = db.transaction(() => {

    // ── 1. Machine OEE + Health ────────────────────────────────────────────────
    for (const m of machines) {
      // Each machine starts healthier 30 days ago, degrades to current state
      let health = clamp(m.health + 30 + Math.random() * 20, 40, 99);
      let rul    = clamp(m.rul    + 40 + Math.random() * 30, 10, 200);
      let vib    = clamp(m.vib * 0.5 + Math.random() * 0.5, 0.3, 5);
      let temp   = clamp(m.temp * 0.85 + Math.random() * 5, 35, 75);

      let ts = startMs;
      let alertCounter = 0;
      let maintenanceUntil = 0;

      while (ts < now) {
        const inMaint = ts < maintenanceUntil;

        if (!inMaint) {
          // Degrade gradually
          health = clamp(health - m._degradeRate * 0.15 + noise(0.08), 5, 99);
          rul    = clamp(rul    - m._degradeRate * 0.06, 1, 200);
          vib    = clamp(vib    + m._degradeRate * 0.004 + noise(0.06), 0.3, 15);
          temp   = clamp(temp   + m._degradeRate * 0.005 + noise(0.4), 35, 105);
        } else {
          // During maintenance — recovering
          health = clamp(health + 0.5, 5, 99);
        }

        // OEE components
        const hf   = health / 100;
        const avail = clamp(m.avail * (0.85 + hf * 0.15) + noise(0.4), 40, 99.9);
        const perf  = clamp(m.perf  * (0.88 + hf * 0.12) + noise(0.3), 40, 99.9);
        const qual  = clamp(m.qual  * 0.999 + noise(0.04), 85, 99.9);
        const oee   = +(avail * perf * qual / 10000).toFixed(1);
        const status = health >= 80 ? 'good' : health >= 65 ? 'caution' : health >= 40 ? 'warning' : 'critical';
        // Loss per reading = fraction of reading interval lost to downtime/inefficiency
        // Reading interval ~13 min (30 days of data / 3360 readings per machine)
        // This gives realistic monthly totals (not inflated by 60-min multiplier per tick)
        const readingIntervalMin = (30 * 24 * 60) / 3360; // ~12.9 min
        const lossMin = Math.floor(clamp((1 - hf) * readingIntervalMin + noise(0.5), 0, readingIntervalMin));

        insertOee.run(m.id, m.name, m.line, ts, oee, +avail.toFixed(1), +perf.toFixed(1), +qual.toFixed(1), m.loss, lossMin);
        insertHealth.run(m.id, ts, +health.toFixed(1), +rul.toFixed(1), +vib.toFixed(1), +temp.toFixed(0), status);

        // Auto-maintenance trigger at low health
        if (health < 20 && ts > maintenanceUntil + 48 * 3600000) {
          maintenanceUntil = ts + (2 + Math.random() * 3) * 3600000;
          health = clamp(health + 35 + noise(5), 55, 90);
          rul    = Math.floor(50 + Math.random() * 60);

          // Alert for maintenance trigger
          const alertId = `ALT-${m.id}-${alertCounter++}`;
          const acked = Math.random() > 0.2;
          const ackedAt = acked ? ts + Math.floor(Math.random() * 3600000) : null;
          insertAlert.run(
            alertId, m.id, m.name, m.line,
            'Unplanned Breakdown', 'critical',
            `${m.name}: Health ${health.toFixed(0)}%, RUL ${rul.toFixed(0)}d. Auto-maintenance triggered.`,
            ts, acked ? 1 : 0, acked ? techName : null, ackedAt
          );
        }

        // Occasional warning alerts
        if (status === 'warning' && Math.random() < 0.002) {
          const alertId = `ALT-${m.id}-W${alertCounter++}`;
          insertAlert.run(
            alertId, m.id, m.name, m.line,
            'Speed Loss', 'warning',
            `${m.name}: Speed loss detected. OEE ${oee}%.`,
            ts, 1, 'Supervisor', ts + 1800000
          );
        }

        ts += OEE_INTERVAL_MS;
      }
    }

    // ── 2. Production batches ─────────────────────────────────────────────────
    const products = ['Compound X-12 Grade A', 'Compound Y-07 Grade B', 'Compound Z-04 Grade S'];
    const durations = [6, 7, 8, 4]; // hours
    let batchTs = startMs;
    let batchCounter = 88300;

    while (batchTs < now) {
      const product = products[Math.floor(Math.random() * products.length)];
      const qty = [900, 1800, 2400][Math.floor(Math.random() * 3)];
      const plan = +(87 + Math.random() * 4).toFixed(1);
      const durationMs = durations[Math.floor(Math.random() * durations.length)] * 3600000;
      const completedAt = batchTs + durationMs;
      const isCompleted = completedAt < now;
      const actual = isCompleted ? +(plan * (0.94 + Math.random() * 0.08)).toFixed(1) : null;

      insertBatch.run(
        `PP-${batchCounter++}`, product, qty, plan, actual,
        isCompleted ? 'completed' : 'in_process',
        batchTs, isCompleted ? completedAt : null
      );

      // Gap between batches (30min to 2hr)
      batchTs += durationMs + (0.5 + Math.random() * 1.5) * 3600000;
    }

    // ── 3. Yield parameters ───────────────────────────────────────────────────
    for (const p of yieldParams) {
      let val = p.tgt + noise((p.max - p.min) * 0.05);
      let ts = startMs;

      while (ts < now) {
        const correction = (val - p.tgt) * -0.015;
        val = clamp(val + p._driftRate * p._driftDir * 0.08 + correction + noise(p._driftRate * 0.04), p.min, p.max);
        const warn = Math.abs(val - p.tgt) / (p.max - p.min) > 0.06;

        insertYield.run(p.id, p.name, ts, +val.toFixed(2), p.tgt, warn ? 1 : 0);
        ts += YIELD_INTERVAL_MS;
      }
    }

    // ── 4. Energy readings ────────────────────────────────────────────────────
    for (const a of energyAssets) {
      let ts = startMs;
      while (ts < now) {
        const hour = new Date(ts).getHours();
        const kw = +(a._baseKw * DEMAND_CURVE[hour] + noise(a._baseKw * 0.06)).toFixed(0);
        const anomaly = kw > a._baseKw * 1.12 ? 1 : 0;
        insertEnergy.run(a.id, a.name, ts, kw, anomaly);
        ts += ENERGY_INTERVAL_MS;
      }
    }

    // ── 5. Safety events ──────────────────────────────────────────────────────
    const zones = ['Zone A', 'Zone B', 'Zone C', 'Zone D'];
    let safetyCounter = 1;

    for (let day = 0; day < DAYS; day++) {
      // ~2 events per day randomly
      const numEvents = Math.random() < 0.3 ? 0 : Math.random() < 0.6 ? 1 : 2;
      for (let e = 0; e < numEvents; e++) {
        const zone = zones[Math.floor(Math.random() * zones.length)];
        const ts = startMs + day * 86400000 + Math.floor(Math.random() * 86400000);
        const sev = Math.random() < 0.2 ? 'critical' : Math.random() < 0.5 ? 'high' : 'medium';
        const resolvedAt = ts + Math.floor((0.5 + Math.random() * 2) * 3600000);
        const h2s  = sev === 'critical' ? 2 + Math.random() * 8 : Math.random() * 2;
        const co   = sev === 'critical' ? 30 + Math.random() * 50 : Math.random() * 20;
        const ch4  = sev === 'critical' ? 8 + Math.random() * 15 : Math.random() * 5;

        insertSafety.run(
          `SEV-${String(safetyCounter++).padStart(4,'0')}`,
          zone, 'Gas precursor', sev,
          +h2s.toFixed(2), +co.toFixed(2), +ch4.toFixed(2),
          ts, resolvedAt < now ? resolvedAt : null
        );
      }
    }
  });

  // Run everything in one transaction
  insertAll();

  const oeeCount = (db.prepare('SELECT COUNT(*) as c FROM oee_readings').get() as { c: number }).c;
  const batchCount = (db.prepare('SELECT COUNT(*) as c FROM batches').get() as { c: number }).c;
  const alertCount = (db.prepare('SELECT COUNT(*) as c FROM alerts').get() as { c: number }).c;

  logger.info(`[DB] History seeded — ${oeeCount} OEE readings, ${batchCount} batches, ${alertCount} alerts`);
}
