/**
 * ManuAI — Dimension Seeder
 *
 * Seeds the Semantic Core dimension tables from CSV files.
 * Runs once on startup if dimensions are empty.
 * This is what makes the platform look like a real enterprise data model.
 *
 * dim_plant     ← platform_config.csv
 * dim_line      ← machines.csv (distinct lines)
 * dim_asset     ← machines.csv + utilities.csv
 * dim_supplier  ← supply_risks.csv
 * dim_material  ← parts.csv
 * semantic_kpi_definition ← semantic_kpi_definitions.csv
 */

import { getDb } from './connection';
import { logger } from '../middleware/logger';
import {
  loadMachines, loadUtilities, loadSupplyRisks,
  loadParts, loadSemanticKpiDefs,
} from '../data/csv-loader';

export function seedDimensions(): void {
  const db = getDb();
  const now = Date.now();

  // Check if already seeded
  const existing = db.prepare('SELECT COUNT(*) as cnt FROM dim_asset').get() as { cnt: number };
  if (existing.cnt > 0) {
    logger.info('[DB] Dimensions already seeded — skipping');
    return;
  }

  logger.info('[DB] Seeding Semantic Core dimensions...');

  // ── dim_plant ──────────────────────────────────────────────────────────────
  db.prepare(`
    INSERT OR IGNORE INTO dim_plant (plant_id, plant_name, location, timezone, currency, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run('P1', 'ManuAI Pilot Plant', 'Mumbai, India', 'Asia/Kolkata', 'INR', now);
  // Issue fix: machines.csv tags MCH-05..08 as P2 — register the second plant
  getDb().prepare(`
    INSERT OR IGNORE INTO dim_plant (plant_id, plant_name, location, timezone, currency, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run('P2', 'ManuAI Plant 2', 'Pune, India', 'Asia/Kolkata', 'INR', now);

  // ── dim_line (from machines.csv distinct lines) ────────────────────────────
  const machines = loadMachines() as any[];
  const lines = [...new Set(machines.map((m: any) => m.line))];
  const lineStmt = db.prepare(`
    INSERT OR IGNORE INTO dim_line (line_id, line_name, plant_id, line_type, created_at)
    VALUES (?, ?, ?, ?, ?)
  `);
  for (const line of lines) {
    lineStmt.run(line, `Production ${line}`, ['Line A','Line B'].includes(line) ? 'P1' : 'P2', 'production', now);
  }

  // ── dim_asset (machines + utilities) ──────────────────────────────────────
  const utilities = loadUtilities() as any[];
  const assetStmt = db.prepare(`
    INSERT OR IGNORE INTO dim_asset
      (asset_id, asset_name, asset_type, line_id, plant_id, rated_kw, source_system, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const m of machines) {
    assetStmt.run(
      m.id, m.name, 'production_machine',
      m.line, m.plant ?? 'P1', m.rated_kw ?? null,
      'PI_HISTORIAN', now
    );
  }
  for (const u of utilities) {
    assetStmt.run(
      u.id, u.name, 'utility_asset',
      null, 'P1', u.rated_kw ?? null,
      'IOT_HUB', now
    );
  }

  // ── dim_supplier ───────────────────────────────────────────────────────────
  const risks = loadSupplyRisks() as any[];
  const supplierStmt = db.prepare(`
    INSERT OR IGNORE INTO dim_supplier
      (supplier_id, supplier_name, country, risk_category, single_source, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  for (const r of risks) {
    const riskCat = Number(r.financial_risk_score ?? 0) > 6 ? 'high' :
                    Number(r.current_stock_days ?? 30) < 30  ? 'high' : 'medium';
    supplierStmt.run(
      r.sku, r.supplier_name,
      r.country_of_origin ?? 'Unknown',
      riskCat,
      r.single_source === 'true' ? 1 : 0,
      now
    );
  }

  // ── dim_material (from parts.csv) ──────────────────────────────────────────
  const { orders } = loadParts();
  const matStmt = db.prepare(`
    INSERT OR IGNORE INTO dim_material
      (material_id, material_name, unit, category, lead_days, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  for (const p of orders as any[]) {
    matStmt.run(
      p.sku, p.part ?? p.sku,
      'EA', 'spare_part',
      p.lead ?? 14, now
    );
  }

  // ── semantic_kpi_definition ────────────────────────────────────────────────
  const kpiDefs = loadSemanticKpiDefs();
  const kpiStmt = db.prepare(`
    INSERT OR IGNORE INTO semantic_kpi_definition
      (kpi_id, kpi_name, formula, unit, agents, source_system, governance, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const k of kpiDefs as any[]) {
    kpiStmt.run(
      k.id, k.name, k.formula, k.unit,
      Array.isArray(k.agents) ? k.agents.join(',') : k.agents,
      k.src, k.governance ?? 'Semantic Layer', now
    );
  }

  const assetCount = (db.prepare('SELECT COUNT(*) as cnt FROM dim_asset').get() as any).cnt;
  const kpiCount   = (db.prepare('SELECT COUNT(*) as cnt FROM semantic_kpi_definition').get() as any).cnt;
  logger.info(`[DB] Dimensions seeded — ${assetCount} assets, ${lines.length} lines, ${kpiCount} KPI definitions`);
}
