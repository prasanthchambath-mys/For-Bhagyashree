import { EventHubConsumerClient } from '@azure/event-hubs';
import { broadcast } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { loadMachines } from '../data/csv-loader';

export interface SensorReading {
  deviceId: string; plantId: string;
  sensorType: 'vibration' | 'temperature' | 'pressure' | 'gas_ppm' | 'current';
  value: number; unit: string; timestamp: string;
  anomaly?: boolean; anomalyScore?: number;
}

// Ring buffer: last 1440 readings per device+sensor combo
const buffers = new Map<string, SensorReading[]>();
const MAX_BUF = 1440;

const key = (deviceId: string, sensorType: string) => `${deviceId}::${sensorType}`;

export function getLatest(deviceId: string, sensorType: string): SensorReading | null {
  const buf = buffers.get(key(deviceId, sensorType));
  return buf?.[buf.length - 1] ?? null;
}

export function getHistory(deviceId: string, sensorType: string, count = 24): SensorReading[] {
  return (buffers.get(key(deviceId, sensorType)) ?? []).slice(-count);
}

let consumer: EventHubConsumerClient | null = null;

export async function startIngestion(): Promise<void> {
  if (!process.env.IOT_HUB_CONNECTION_STRING) {
    logger.warn('IOT_HUB_CONNECTION_STRING not set — IoT Hub disabled, using simulated data');
    startSimulation();
    return;
  }
  try {
    consumer = new EventHubConsumerClient(
      process.env.IOT_HUB_CONSUMER_GROUP ?? '$Default',
      process.env.IOT_HUB_CONNECTION_STRING,
    );
    await consumer.subscribe({
      processEvents: async (events) => {
        for (const ev of events) {
          const msg = ev.body as SensorReading;
          if (!msg?.deviceId) continue;
          const k = key(msg.deviceId, msg.sensorType);
          const buf = buffers.get(k) ?? [];
          buf.push(msg);
          if (buf.length > MAX_BUF) buf.shift();
          buffers.set(k, buf);
          broadcast('pdm', { type: 'sensor', data: msg });
          if (msg.sensorType === 'gas_ppm' && msg.anomaly) broadcast('safety', { type: 'precursor', data: msg });
        }
      },
      processError: async (err) => { logger.error('IoT Hub error', { error: err.message }); },
    });
    logger.info('IoT Hub ingestion started');
  } catch (err) {
    logger.error('IoT Hub connect failed', { error: String(err) });
    startSimulation();
  }
}

// Simulate sensor data when IoT Hub is not connected (dev mode)
function startSimulation(): void {
  // Load critical machines from CSV — REPLACE WITH IoT Hub subscription in Phase 3
  const allMachines = loadMachines();
  const assets = allMachines
    .filter((m: any) => m.health < 50 || m.status === 'critical')
    .map((m: any) => m.id)
    .slice(0, 5);  // simulate top 5 critical
  setInterval(() => {
    for (const id of assets) {
      const machine = allMachines.find((m: any) => m.id === id);
      const baseVib = machine ? Number(machine.vib ?? 5.0) : 5.0;
      const reading: SensorReading = {
        deviceId: id, plantId: 'P1', sensorType: 'vibration',
        value: +(baseVib + (Math.random() - 0.5) * 0.4).toFixed(2),
        unit: 'mm/s', timestamp: new Date().toISOString(),
        anomaly: baseVib > 8,
      };
      const k = key(id, 'vibration');
      const buf = buffers.get(k) ?? [];
      buf.push(reading);
      if (buf.length > MAX_BUF) buf.shift();
      buffers.set(k, buf);
    }
  }, 3500);
  logger.info('IoT Hub simulation mode active');
}

export async function stopIngestion(): Promise<void> {
  await consumer?.close();
}
