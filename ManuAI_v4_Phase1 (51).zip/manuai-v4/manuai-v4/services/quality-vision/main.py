"""
ManuAI — Quality Vision Service  v2.0
Manages ONNX/TensorRT vision model lifecycle for inline defect detection.
In mock mode returns synthetic defect detection results with realistic
confidence scores and defect classifications.
"""

import os, random, logging, uuid
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Quality Vision", version="2.0.0")

MOCK = not bool(os.getenv("VISION_MODEL_PATH"))
if MOCK:
    logger.warning("VISION_MODEL_PATH not set — quality vision running in mock mode")


# ── Models ────────────────────────────────────────────────────────────────────

class InspectionRequest(BaseModel):
    image_id: str
    line_id: str
    component_type: str    # "housing" | "bracket" | "weld_joint" | "shaft" | "bearing_race"
    batch_id: str
    image_base64: Optional[str] = None   # omit in mock mode

class BoundingBox(BaseModel):
    x: float; y: float; w: float; h: float  # normalised 0–1

class DefectDetection(BaseModel):
    defect_id: str
    defect_type: str
    severity: str          # "major" | "minor" | "cosmetic"
    confidence: float
    bbox: Optional[BoundingBox]
    action: str            # "reject" | "re-inspect" | "accept" | "scrap"
    ncr_required: bool

class InspectionResult(BaseModel):
    image_id: str
    line_id: str
    component_type: str
    batch_id: str
    pass_fail: str          # "pass" | "fail"
    defects: List[DefectDetection]
    inspection_time_ms: int
    model_version: str
    model_source: str

class ModelStatus(BaseModel):
    line_id: str
    model_version: str
    status: str             # "running" | "degraded" | "offline"
    fps: float
    accuracy_pct: float
    defects_today: int
    false_positive_rate: float

# ── Defect taxonomy ───────────────────────────────────────────────────────────

DEFECT_TYPES: Dict[str, dict] = {
    "surface_crack":          {"severity": "major",    "action": "reject",     "ncr": True,  "base_prob": 0.04},
    "dimensional_tolerance":  {"severity": "minor",    "action": "re-inspect", "ncr": False, "base_prob": 0.06},
    "assembly_misalignment":  {"severity": "major",    "action": "reject",     "ncr": True,  "base_prob": 0.03},
    "porosity":               {"severity": "major",    "action": "scrap",      "ncr": True,  "base_prob": 0.02},
    "surface_scratch":        {"severity": "cosmetic", "action": "accept",     "ncr": False, "base_prob": 0.08},
    "burr":                   {"severity": "minor",    "action": "re-inspect", "ncr": False, "base_prob": 0.05},
    "incomplete_weld":        {"severity": "major",    "action": "reject",     "ncr": True,  "base_prob": 0.03},
    "contamination":          {"severity": "minor",    "action": "re-inspect", "ncr": False, "base_prob": 0.04},
}

LINE_MODELS = {
    "Line A": {"version": "v3.1", "accuracy": 99.2, "fps": 28.4, "defects_today": 4,  "fpr": 0.008},
    "Line B": {"version": "v3.1", "accuracy": 97.8, "fps": 26.1, "defects_today": 18, "fpr": 0.021},
    "Line C": {"version": "v3.0", "accuracy": 98.9, "fps": 27.8, "defects_today": 9,  "fpr": 0.012},
    "Line D": {"version": "v3.1", "accuracy": 99.6, "fps": 29.2, "defects_today": 2,  "fpr": 0.005},
}

COMPONENT_DEFECT_BIAS = {
    "housing":       ["surface_crack", "dimensional_tolerance"],
    "bracket":       ["dimensional_tolerance", "burr"],
    "weld_joint":    ["incomplete_weld", "assembly_misalignment", "porosity"],
    "shaft":         ["dimensional_tolerance", "surface_scratch", "burr"],
    "bearing_race":  ["surface_crack", "surface_scratch", "dimensional_tolerance"],
}


def _mock_inspect(req: InspectionRequest) -> InspectionResult:
    biased = COMPONENT_DEFECT_BIAS.get(req.component_type, list(DEFECT_TYPES.keys()))
    line_info = LINE_MODELS.get(req.line_id, LINE_MODELS["Line A"])

    # Overall pass rate derived from line accuracy
    defect_roll = random.random()
    pass_threshold = line_info["accuracy"] / 100.0

    defects: List[DefectDetection] = []
    if defect_roll > pass_threshold:
        # Select 1–2 defect types, weighted toward biased types
        n_defects = 1 if defect_roll < (1 - (1 - pass_threshold) / 2) else 2
        chosen_types = random.sample(biased, min(n_defects, len(biased)))
        for dt in chosen_types:
            meta = DEFECT_TYPES[dt]
            confidence = round(random.uniform(0.88, 0.98), 2)
            defects.append(DefectDetection(
                defect_id=f"DEF-{random.randint(100,999)}",
                defect_type=dt.replace("_", " ").title(),
                severity=meta["severity"],
                confidence=confidence,
                bbox=BoundingBox(
                    x=round(random.uniform(0.1, 0.7), 3),
                    y=round(random.uniform(0.1, 0.7), 3),
                    w=round(random.uniform(0.05, 0.2), 3),
                    h=round(random.uniform(0.05, 0.2), 3),
                ),
                action=meta["action"],
                ncr_required=meta["ncr"],
            ))

    pass_fail = "fail" if defects else "pass"

    return InspectionResult(
        image_id=req.image_id,
        line_id=req.line_id,
        component_type=req.component_type,
        batch_id=req.batch_id,
        pass_fail=pass_fail,
        defects=defects,
        inspection_time_ms=random.randint(28, 55),
        model_version=line_info["version"],
        model_source="mock_rule_engine",
    )


@app.post("/inspect", response_model=InspectionResult)
def inspect(req: InspectionRequest):
    if MOCK:
        return _mock_inspect(req)
    # LIVE: load ONNX model and run inference
    # model = ort.InferenceSession(os.getenv("VISION_MODEL_PATH"))
    # ...
    raise HTTPException(503, "Vision model path not configured — set VISION_MODEL_PATH")


@app.get("/models/status", response_model=List[ModelStatus])
def model_status():
    return [
        ModelStatus(
            line_id=line,
            model_version=info["version"],
            status="running",
            fps=info["fps"] + random.uniform(-0.5, 0.5),
            accuracy_pct=info["accuracy"],
            defects_today=info["defects_today"],
            false_positive_rate=info["fpr"],
        )
        for line, info in LINE_MODELS.items()
    ]


@app.get("/health")
def health():
    return {"status": "ok", "service": "quality-vision", "mode": "mock" if MOCK else "live"}
