"""
ManuAI — PdM Inference Service  v2.0
FastAPI microservice for failure prediction and Remaining Useful Life estimation.
Runs as an AKS pod in production. Rule-based fallback works without Azure ML.
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import numpy as np
import logging

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI PdM Inference", version="2.0.0")


class SensorFeatures(BaseModel):
    asset_id: str
    vibration_rms: float        # mm/s — ISO 10816
    vibration_peak: float       # mm/s
    temperature_delta: float    # °C above ambient
    pressure_variance: float    # bar standard deviation
    run_hours_total: float      # cumulative
    run_hours_since_service: float
    load_factor: float          # 0–1
    ambient_temp: float         # °C


class PdMResult(BaseModel):
    asset_id: str
    failure_probability: float  # 0–1 within 30 days
    rul_days: float
    rul_low: float              # 90% CI lower
    rul_high: float             # 90% CI upper
    health_score: float         # 0–100
    anomaly_score: float        # 0–1
    failure_mode: str
    action: str


def predict(s: SensorFeatures) -> PdMResult:
    """
    ISO 10816-3 Class III limits:
      - Good:    vib < 2.3 mm/s
      - Satisfactory: < 4.5 mm/s
      - Unsatisfactory: < 7.1 mm/s (alarm)
      - Unacceptable: >= 7.1 mm/s (trip)
    """
    # Vibration health score
    vib_pct = min(100.0, max(0.0, 100.0 - (s.vibration_rms / 0.071) * 100.0))
    # Thermal health score (alarm at +30°C above ambient, trip at +50°C)
    temp_pct = min(100.0, max(0.0, 100.0 - max(0.0, s.temperature_delta - 10.0) * 2.0))
    # Service age score
    age_norm = min(1.0, s.run_hours_since_service / 8760.0)
    age_pct  = 100.0 * (1.0 - age_norm ** 1.5)

    health = 0.50 * vib_pct + 0.30 * temp_pct + 0.20 * age_pct

    # RUL: linear to failure threshold (health = 30)
    if health <= 30.0:
        rul = 0.0
    else:
        rate = max(0.001, (100.0 - health) / max(1.0, s.run_hours_since_service))
        rul = max(0.0, (health - 30.0) / rate / 24.0)

    # Failure mode
    if s.vibration_rms > 5.0:
        mode = "bearing_wear" if s.temperature_delta > 25 else "imbalance"
    elif s.temperature_delta > 35:
        mode = "overtemperature"
    elif s.pressure_variance > 0.5:
        mode = "seal_leak"
    else:
        mode = "normal_wear"

    if rul < 7:
        action = f"CRITICAL: Replace immediately. RUL {rul:.1f}d — schedule emergency maintenance."
    elif rul < 14:
        action = f"URGENT: Schedule within 7 days. RUL {rul:.1f}d — auto-WO recommended."
    elif rul < 30:
        action = f"PLAN: Next maintenance window. RUL {rul:.1f}d."
    else:
        action = "MONITOR: Continue standard monitoring."

    return PdMResult(
        asset_id=s.asset_id,
        failure_probability=round(max(0.0, 1.0 - health / 100.0), 3),
        rul_days=round(rul, 1),
        rul_low=round(rul * 0.75, 1),
        rul_high=round(rul * 1.25, 1),
        health_score=round(health, 1),
        anomaly_score=round(max(0.0, 1.0 - health / 100.0), 3),
        failure_mode=mode,
        action=action,
    )


@app.get("/health")
def health():
    return {"status": "ok", "service": "pdm-inference", "version": "2.0.0"}


@app.post("/predict", response_model=PdMResult)
def predict_single(req: SensorFeatures):
    try:
        return predict(req)
    except Exception as e:
        logger.error(f"Predict error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/predict/batch", response_model=List[PdMResult])
def predict_batch(assets: List[SensorFeatures]):
    return [predict(a) for a in assets]


@app.get("/thresholds")
def thresholds():
    return {
        "iso_10816_class_iii": {
            "good": "< 2.3 mm/s", "satisfactory": "< 4.5 mm/s",
            "unsatisfactory": "< 7.1 mm/s", "unacceptable": ">= 7.1 mm/s",
        },
        "temperature_delta": {
            "normal": "< 20°C", "caution": "20–30°C", "alarm": "30–50°C", "trip": "> 50°C",
        },
        "rul_thresholds": {
            "critical_days": 7, "urgent_days": 14, "plan_days": 30,
        },
    }
