/**
 * ManuAI — Synthetic Data Engine
 *
 * Simulates a live manufacturing plant. Runs inside the API process —
 * no extra service needed. Auto-starts when MOCK_DATA_ENGINE=true (default).
 *
 * Every 4 seconds it:
 *   • Degrades machine health, vibration, temperature
 *   • Triggers maintenance when health is critical, restores after
 *   • Cycles batches: planned → in_process → completed → new batch
 *   • Drifts yield parameters away from target, slowly self-corrects
 *   • Follows a real 24-hour energy demand curve
 *   • Fires occasional safety gas spikes and resolves them
 *   • Emits cross-agent events via WebSocket in real time
 *
 * Routes call getPlantState() instead of hardcoded constants.
 * When real connectors are wired, the engine is disabled — no code changes.
 */

import { broadcast, broadcastEvent } from '../websocket/broadcaster';
import { computeKPIs, persistKPIs } from '../kpi/engine';
import { triggerDegradationScenario } from '../orchestration/scenario-engine';
import { semanticLayer } from '../semantic/service';
import { logger } from '../middleware/logger';
import { writeStateToDB, writeAlertToDB, writeSafetyEventToDB } from '../database/writer';
import { loadMachines, loadUtilities, loadYieldParams, loadEnergyAssets, loadEnergyHourly, loadSafetyZones } from '../data/csv-loader';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MachineSim {
  id: string; name: string; line: string; plant: string;
  oee: number; avail: number; perf: number; qual: number;
  health: number; rul: number;
  status: 'good' | 'caution' | 'warning' | 'critical';
  loss: string; lossMin: number;
  vib: number; temp: number;
  _degradeRate: number;
  _inMaintenance: boolean;
  _maintenanceTicksLeft: number;
}

export interface UtilitySim {
  id: string; name: string;
  health: number; rul: number; status: string;
  vib: number; temp: number; press: number;
  oeeLink: string | null;
  _degradeRate: number;
}

export interface BatchSim {
  id: string; product: string; qty: number;
  plan: number; actual: number | null;
  status: 'planned' | 'in_process' | 'completed';
  startedAt: number; durationMs: number;
}

export interface YieldParamSim {
  id: string; name: string; unit: string;
  val: number; tgt: number; min: number; max: number;
  warn: boolean; blocked: boolean;
  _driftRate: number; _driftDir: 1 | -1;
}

export interface EnergyAssetSim {
  id: string; name: string; kw: number; anomaly: boolean; _baseKw: number;
}

export interface SafetyZoneSim {
  zone: string; h2s: number; co: number; ch4: number;
  _spiking: boolean; _spikeTicks: number;
}

export interface PlantState {
  machines: MachineSim[];
  utilities: UtilitySim[];
  plantOEE: number;
  batch: BatchSim;
  yieldParams: YieldParamSim[];
  energyKw: number;
  energyTrend: Array<{ h: string; kw: number }>;
  energyAssets: EnergyAssetSim[];
  safetyZones: SafetyZoneSim[];
  tickCount: number;
  lastTick: string;
}

// ─── Initial state ────────────────────────────────────────────────────────────

function initMachines(): MachineSim[] { return loadMachines() as MachineSim[]; }

function initUtilities(): UtilitySim[] { return loadUtilities() as UtilitySim[]; }

function initYieldParams(): YieldParamSim[] { return loadYieldParams() as YieldParamSim[]; }

function initEnergyAssets(): EnergyAssetSim[] { return loadEnergyAssets() as EnergyAssetSim[]; }

function initSafetyZones(): SafetyZoneSim[] { return loadSafetyZones() as SafetyZoneSim[]; }

import { loadDemandCurve } from '../data/csv-loader';
const DEMAND_CURVE = loadDemandCurve(); // 24-hour energy demand profile from demand_curve.csv

function buildEnergyTrend(): Array<{ h: string; kw: number }> { return loadEnergyHourly(); }

// ─── Engine ───────────────────────────────────────────────────────────────────

class SimulationEngine {
  private state: PlantState;
  private timer: ReturnType<typeof setInterval> | null = null;
  private evtCounter = 100;

  constructor() {
    this.state = {
      machines: initMachines(), utilities: initUtilities(),
      plantOEE: 76.8,
      batch: { id:'PP-88414',product:'Compound X-12 Grade A',qty:2400,plan:91.0,actual:null,
               status:'in_process',startedAt:Date.now()-3*3600000,durationMs:8*3600000 },
      yieldParams: initYieldParams(),
      energyKw: 1547, energyTrend: buildEnergyTrend(),
      energyAssets: initEnergyAssets(), safetyZones: initSafetyZones(),
      tickCount: 0, lastTick: new Date().toISOString(),
    };
  }

  getState(): PlantState { return this.state; }

  start(ms = 4000): void {
    if (this.timer) return;
    // Register faults for machines already in critical state from CSV data
    // Ensures Semantic Layer shows blocked recs from first page load
    for (const m of this.state.machines) {
      if ((m as any).health < 40 && (m as any).status === 'critical') {
        semanticLayer.registerFault('CR-001', (m as any).id);
        logger.info(`[SIM] Initial fault registered for ${(m as any).id} (health ${(m as any).health})`);
      }
    }
    this.timer = setInterval(() => this.tick(), ms);
    logger.info(`[SIM] Simulation engine started — tick every ${ms}ms`);
  }

  stop(): void { if (this.timer) { clearInterval(this.timer); this.timer = null; } }

  private n(s = 1): number { return (Math.random() - 0.5) * 2 * s; }
  private cl(v: number, a: number, b: number): number { return Math.max(a, Math.min(b, v)); }

  private tick(): void {
    const st = this.state;
    st.tickCount++;
    st.lastTick = new Date().toISOString();
    this.tickMachines();
    this.tickUtilities();
    this.tickBatch();
    this.tickYieldParams();
    this.tickEnergy();
    this.tickSafety();
    st.plantOEE = +(st.machines.reduce((a,m)=>a+m.oee,0)/st.machines.length).toFixed(1);
    // KPI engine: compute + persist every 75 ticks (~5 min). Was imported but never
    // invoked — found during Issue 2/4 regression (entire pipeline was dead).
    if (st.tickCount % 75 === 1) {
      try { persistKPIs(computeKPIs()); } catch { /* KPI persistence must never break the sim */ }
    }
    // Round machine values before broadcast to avoid excessive decimals in UI
    const roundedMachines = st.machines.map(m => ({
      ...m,
      oee:   +Number(m.oee).toFixed(1),
      avail: +Number(m.avail).toFixed(1),
      perf:  +Number(m.perf).toFixed(1),
      qual:  +Number(m.qual).toFixed(1),
      health: +Number(m.health).toFixed(1),
      rul:    Math.round(Number(m.rul)),
      lossMin: Math.round(Number(m.lossMin ?? 0)),
      temp:   Math.round(Number(m.temp ?? 0)),
    }));
    broadcast('oee', {
      type:'live', machines:roundedMachines, plantOEE:+st.plantOEE.toFixed(1),
      plant_id:'P1', source_mode:'Synthetic', ts:st.lastTick,
    });
    // Broadcast all agent channels so every dashboard receives live updates
    broadcast('quality', {
      type:'live', zones:st.safetyZones, defectRate:+(100 - (st.machines.reduce((s,m)=>s+m.qual,0)/st.machines.length)).toFixed(2),
      plant_id:'P1', source_mode:'Synthetic', ts:st.lastTick,
    });
    broadcast('supply', {
      type:'live', energyKw:st.energyKw, batch:st.batch,
      plant_id:'P1', source_mode:'Synthetic', ts:st.lastTick,
    });
    broadcast('twin', {
      type:'live', machines:st.machines, plantOEE:st.plantOEE,
      plant_id:'P1', source_mode:'Synthetic', ts:st.lastTick,
    });
    broadcast('safety', {
      type:'live', zones:st.safetyZones,
      plant_id:'P1', source_mode:'Synthetic', ts:st.lastTick,
    });
    writeStateToDB(st);
  }

  // ── Machines ─────────────────────────────────────────────────────────────────

  private tickMachines(): void {
    for (const m of this.state.machines) {
      if (m._inMaintenance) {
        m._maintenanceTicksLeft--;
        if (m._maintenanceTicksLeft <= 0) {
          m._inMaintenance = false;
          m.health = this.cl(m.health + 35 + this.n(5), 60, 95);
          m.rul    = Math.floor(60 + Math.random() * 80);
          m.vib    = +(1.0 + Math.random() * 1.5).toFixed(1);
          m.temp   = Math.floor(45 + Math.random() * 15);
          m.qual   = this.cl(95 + this.n(2), 94, 99.5);
          m.avail  = this.cl(85 + this.n(3), 80, 98);
          m.perf   = this.cl(85 + this.n(3), 80, 96);
          m.lossMin= Math.floor(10 + Math.random() * 30);
          this.updateStatus(m);
          this.fireEv('pdm','oee','MAINTENANCE_COMPLETE',
            `${m.name} maintenance complete. Health restored to ${m.health.toFixed(0)}%.`,
            `OEE recovery +${(5+Math.random()*4).toFixed(1)}%`,m.id,'info');
          semanticLayer.resolveFault('CR-001', m.id);
        }
        continue;
      }
      m.health = this.cl(m.health - m._degradeRate + this.n(0.05), 5, 99);
      m.rul    = this.cl(m.rul    - m._degradeRate * 0.4, 1, 200);
      m.vib    = this.cl(m.vib    + m._degradeRate * 0.03 + this.n(0.08), 0.3, 15);
      m.temp   = this.cl(m.temp   + m._degradeRate * 0.05 + this.n(0.5), 35, 105);
      const hf = m.health / 100;
      m.avail  = this.cl(m.avail * (0.9998 + hf * 0.0002) + this.n(0.1), 40, 99.9);
      m.perf   = this.cl(m.perf  * (0.9998 + hf * 0.0002) + this.n(0.1), 40, 99.9);
      m.qual   = this.cl(m.qual  * 0.9999 + this.n(0.08), 94, 99.9);
      m.oee    = +(m.avail * m.perf * m.qual / 10000).toFixed(1);
      m.lossMin = Math.floor(this.cl(m.lossMin + (1-hf)*0.5 + this.n(0.3), 0, 300));
      this.updateStatus(m);

      if (m.health < 20 && !m._inMaintenance) {
        m._inMaintenance = true;
        m._maintenanceTicksLeft = Math.floor(30 + Math.random() * 20);
        this.fireEv('pdm','oee','MAINTENANCE_STARTED',
          `Auto-maintenance triggered: ${m.name}. Health ${m.health.toFixed(0)}%. WO auto-raised.`,
          'Production halted for maintenance window', m.id, 'warning');
        semanticLayer.registerFault('CR-001', m.id);
        logger.info(`[SIM] ${m.id} maintenance triggered`);
      }
    }
  }

  private updateStatus(m: MachineSim): void {
    m.status = m.health >= 80 ? 'good' : m.health >= 65 ? 'caution' : m.health >= 40 ? 'warning' : 'critical';
    m.loss = m.avail < 80 ? 'Unplanned Breakdown' : m.perf < 85 ? 'Speed Loss' : m.qual < 96 ? 'In-process Defects' : 'Minor Stops';
          m.lossMin= Math.max(0, Math.floor((1 - m.oee/100) * 30 + this.n(2)));
  }

  // ── Utilities ─────────────────────────────────────────────────────────────────

  private tickUtilities(): void {
    for (const u of this.state.utilities) {
      u.health = this.cl(u.health - u._degradeRate + this.n(0.05), 5, 99);
      u.rul    = this.cl(u.rul    - u._degradeRate * 0.4, 1, 200);
      u.vib    = this.cl(u.vib    + u._degradeRate * 0.02 + this.n(0.06), 0.3, 12);
      u.temp   = this.cl(u.temp   + u._degradeRate * 0.04 + this.n(0.4), 10, 110);
      u.status = u.health >= 75 ? 'good' : u.health >= 55 ? 'caution' : u.health >= 35 ? 'warning' : 'critical';
      if (u.health < 15) { u.health = this.cl(u.health + 30, 15, 70); u.rul = Math.floor(20 + Math.random()*30); }
    }
  }

  // ── Batch ─────────────────────────────────────────────────────────────────────

  private tickBatch(): void {
    const b = this.state.batch;
    if (b.status !== 'in_process') return;
    const progress = this.cl((Date.now() - b.startedAt) / b.durationMs, 0, 1);
    b.actual = +(b.plan * (0.96 + progress * 0.06) + this.n(0.3)).toFixed(1);
    if (progress >= 1) {
      b.status = 'completed';
      this.fireEv('yield','oee','BATCH_COMPLETED',
        `Batch ${b.id} complete. Yield ${b.actual}% vs plan ${b.plan}%.`,
        `${(b.actual??0) >= b.plan ? '+' : ''}${((b.actual??0) - b.plan).toFixed(1)}% vs plan`, b.id,'info');
      setTimeout(() => {
        const products = ['Compound X-12 Grade A','Compound Y-07 Grade B','Compound Z-04 Grade S'];
        this.state.batch = {
          id:`PP-${88414+this.state.tickCount}`,
          product:products[Math.floor(Math.random()*3)],
          qty:[900,1800,2400][Math.floor(Math.random()*3)],
          plan:+(87+Math.random()*4).toFixed(1), actual:null, status:'in_process',
          startedAt:Date.now(), durationMs:(6+Math.floor(Math.random()*4))*3600000,
        };
        logger.info(`[SIM] New batch: ${this.state.batch.id}`);
      }, 4500);
    }
  }

  // ── Yield params ──────────────────────────────────────────────────────────────

  private tickYieldParams(): void {
    for (const p of this.state.yieldParams) {
      const correction = (p.val - p.tgt) * -0.02;
      p.val = +this.cl(p.val + p._driftRate * p._driftDir * 0.5 + correction + this.n(p._driftRate * 0.3), p.min, p.max).toFixed(1);
      p.warn = Math.abs(p.val - p.tgt) / (p.max - p.min) > 0.06;
      if (Math.random() < 0.005) p._driftDir = p._driftDir === 1 ? -1 : 1;
    }
    broadcast('yield', { type:'params', params:this.state.yieldParams });
  }

  // ── Energy ────────────────────────────────────────────────────────────────────

  private tickEnergy(): void {
    const h = new Date().getHours();
    this.state.energyKw = +(1520 * DEMAND_CURVE[h] + this.n(30)).toFixed(0);
    for (const a of this.state.energyAssets) {
      a.kw = +(a._baseKw * DEMAND_CURVE[h] + this.n(a._baseKw * 0.05)).toFixed(0);
      a.anomaly = a.kw > a._baseKw * 1.12;
    }
    // Update the rolling trend for current hour slot
    const slot = Math.floor(h / 2);
    this.state.energyTrend[slot].kw = this.state.energyKw;
    broadcast('energy', { type:'load', kw:this.state.energyKw, assets:this.state.energyAssets });
  }

  // ── Safety ────────────────────────────────────────────────────────────────────

  private tickSafety(): void {
    for (const z of this.state.safetyZones) {
      if (z._spiking) {
        z.h2s = this.cl(z.h2s + this.n(0.15) - 0.05, 0, 15);
        z.co  = this.cl(z.co  + this.n(1.0)  - 0.3,  0, 150);
        z.ch4 = this.cl(z.ch4 + this.n(0.5)  - 0.2,  0, 30);
        z._spikeTicks--;
        if (z._spikeTicks <= 0) {
          z._spiking = false;
          z.h2s = this.cl(z.h2s * 0.4, 0, 3);
          z.co  = this.cl(z.co  * 0.4, 0, 20);
          z.ch4 = this.cl(z.ch4 * 0.4, 0, 8);
          this.fireEv('safety','oee','GAS_PRECURSOR_CLEARING',
            `${z.zone} gas readings normalising. Evacuation alert can be lifted.`,
            'Resume work after zone certification', z.zone, 'warning');
        }
      } else {
        z.h2s = this.cl(z.h2s + this.n(0.05), 0, 3);
        z.co  = this.cl(z.co  + this.n(0.8),  0, 30);
        z.ch4 = this.cl(z.ch4 + this.n(0.3),  0, 10);
        if (Math.random() < 0.008) {
          z._spiking = true;
          z._spikeTicks = Math.floor(8 + Math.random() * 10);
          z.h2s += 1.5 + Math.random() * 2;
          z.co  += 15  + Math.random() * 20;
          z.ch4 += 5   + Math.random() * 8;
          this.fireEv('safety','oee','GAS_PRECURSOR_DETECTED',
            `Gas precursor in ${z.zone}. H₂S: ${z.h2s.toFixed(1)} ppm. Investigate immediately.`,
            'Hot-work permits auto-blocked', z.zone, 'critical');
          logger.warn(`[SIM] Gas spike in ${z.zone}`);
        }
      }
    }
  }

  // ── Event helper ──────────────────────────────────────────────────────────────

  private fireEv(from:string,to:string,type:string,msg:string,impact:string,asset:string,sev:'critical'|'warning'|'info'): void {
    // Resolve line_id for asset from machine state
    const m = this.state.machines.find(m => m.id === asset)
           || this.state.utilities.find(u => u.id === asset);
    const ev = {
      id:          `XEV-${this.evtCounter++}`,
      from, to, type, sev, msg, impact,
      asset,
      asset_id:    asset,
      plant_id:    'P1',
      line_id:     (m as any)?.line ?? null,
      scenario_id: null,
      source_mode: 'Synthetic' as const,
      ts:          new Date().toISOString(),
    };
    void semanticLayer.publishEvent(ev as any);
    // publishEvent handles persistence + WebSocket — no duplicate broadcastEvent
  }
}

export const simulationEngine = new SimulationEngine();
export function getPlantState(): PlantState { return simulationEngine.getState(); }
