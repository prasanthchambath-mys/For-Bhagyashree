import { Router } from 'express';
import { loadYieldParams } from '../data/csv-loader';
import { getTagsBatch } from '../connectors/pi-historian';
import { getTodayResults } from '../connectors/lims';
import { getProductionOrders } from '../connectors/sap-odata';
import { writeSetPoint } from '../connectors/opc-ua';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { broadcast } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { getPlantState } from '../simulation/engine';
import { z } from 'zod';

const router = Router();

// DCS parameter metadata loaded from yield_params.csv — no hardcoded tags
// REPLACE WITH: OPC-UA tag registry or real PI tag config in Phase 3
function getParamsMeta() {
  return (loadYieldParams() as any[]).map(p => ({
    id:     p.id,
    name:   p.name,
    piTag:  `Plant.Reactor.${p.id.replace('-','')}.PV`,
    nodeId: `ns=2;s=${p.id.replace('-','')}_SP`,
    unit:   p.unit,
    min:    Number(p.min ?? 0),
    max:    Number(p.max ?? 100),
    target: Number(p.tgt ?? 0),
  }));
}

router.get('/params', async (_req, res) => {
  const piValues = await getTagsBatch(getParamsMeta().map(p => p.piTag)).catch(() => ({}));
  const simParams = getPlantState().yieldParams;

  const params = getParamsMeta().map(p => {
    const simVal = simParams.find(sp => sp.id === p.id);
    const val = piValues[p.piTag] ?? simVal?.val ?? p.target;
    const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId: p.id });
    return {
      ...p, val: +val.toFixed(1),
      warn: Math.abs(val - p.target) / p.target > 0.05,
      blocked: conflict.blocked, blockedReason: conflict.reason,
    };
  });
  res.json({ params, timestamp: new Date().toISOString() });
});

const WriteSchema = z.object({ tagId: z.string(), value: z.number(), reason: z.string().min(5) });

router.post('/dcs-write', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const parsed = WriteSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  const { tagId, value, reason } = parsed.data;

  const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId });
  if (conflict.blocked) { res.status(409).json({ error: 'Semantic Layer block', reason: conflict.reason }); return; }

  const param = getParamsMeta().find(p => p.id === tagId);
  if (!param) { res.status(404).json({ error: `Unknown tag: ${tagId}` }); return; }
  if (value < param.min || value > param.max) { res.status(400).json({ error: `${value} out of safe range [${param.min}, ${param.max}]` }); return; }

  const ok = await writeSetPoint(param.nodeId, value);
  if (!ok) { res.status(502).json({ error: 'OPC-UA write failed' }); return; }

  logger.info('DCS write', { tagId, value, user: req.user?.name, reason });
  await semanticLayer.publishEvent({ id:`DCS-${Date.now()}`, from:'yield', to:'oee', type:'dcs_write', sev:'info',
    msg:`${param.name} → ${value} ${param.unit}: ${reason}`, impact:'Yield impact expected within 15 min', asset:tagId, ts:new Date().toISOString() });
  broadcast('yield', { type:'dcs_confirmed', tagId, value });
  res.json({ success: true, tagId, value, unit: param.unit });
});

router.get('/lims', async (_req, res) => {
  const results = await getTodayResults();
  res.json({ results });
});

router.get('/orders', async (_req, res) => {
  const state = getPlantState();
  const orders = (await getProductionOrders().catch(() => [])) as any[];
  const liveOrder = {
    id: state.batch.id, product: state.batch.product,
    qty: `${state.batch.qty} kg`, plan: state.batch.plan,
    actual: state.batch.actual, status: state.batch.status,
    start: new Date(state.batch.startedAt).toLocaleString('en-IN'),
    end: new Date(state.batch.startedAt + state.batch.durationMs).toLocaleString('en-IN'),
  };
  res.json({ orders: orders.length ? orders : [liveOrder] });
});

export default router;
