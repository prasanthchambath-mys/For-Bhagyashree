import { Router } from 'express';
import { getPlantState } from '../simulation/engine';
import {
  loadWorkOrders, loadQualityDefects, loadQualityLines, loadSupplyRisks,
  loadTwinKPIs, loadTwinScenarios, loadTwinComponents, loadSafetyPermits,
  loadProductionOrders, loadSafetyZones, loadTechnicians, loadMachines,
  loadUtilities, loadEnergyAssets, loadEnergyWaste, loadEnergyDispatch,
  loadDemandForecast, loadCarbonTrend, loadParts, loadPdmRules,
} from '../data/csv-loader';
import { createMaintenanceNotification, createPurchaseRequisition } from '../connectors/sap-odata';
import { getHistory, getLatest } from '../connectors/iot-hub';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { unifiedChat, agentRecommendation, semanticQuery } from '../ai/llm-client';
import { logger } from '../middleware/logger';
import { z } from 'zod';

// ══════════════════════════════════════════════════════════════
// PdM Agent
// ══════════════════════════════════════════════════════════════
export const pdmRouter = Router();

pdmRouter.get('/assets', (_req, res) => {
  const state = getPlantState();
  const assets = state.machines.map(m => ({
    id: m.id, name: m.name, line: m.line, plant: m.plant,
    oee: +Number(m.oee).toFixed(1), avail: +Number(m.avail).toFixed(1),
    perf: +Number(m.perf).toFixed(1), qual: +Number(m.qual).toFixed(1),
    health: +Number(m.health).toFixed(1), rul: Math.round(Number(m.rul)),
    status: m.status, loss: m.loss, lossMin: m.lossMin,
    vib: m.vib, temp: m.temp,
  }));
  const utilityAssets = state.utilities.map(u => ({
    id: u.id, name: u.name, health: Math.round(u.health), rul: Math.round(u.rul),
    status: u.status, oeeLink: u.oeeLink,
  }));
  res.json({
    assets, utilityAssets,
    plant_id:    'P1',
    source_mode: 'Synthetic',
    source_system: 'PI_HISTORIAN',
    ts: new Date().toISOString(),
  });
});

pdmRouter.get('/sensors/:assetId', (req, res) => {
  const { assetId } = req.params;
  res.json({
    assetId,
    vibration: { latest: getLatest(assetId, 'vibration'), history: getHistory(assetId, 'vibration', 24) },
    temperature: { latest: getLatest(assetId, 'temperature'), history: getHistory(assetId, 'temperature', 24) },
  });
});

pdmRouter.get('/workorders', async (_req, res) => res.json({ orders: loadWorkOrders() }));

pdmRouter.post('/workorders', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { equipment, description, priority } = req.body as { equipment: string; description: string; priority?: string };
  // Issue 12: semantic governance — maintenance WO affects OEE
  const conflict = semanticLayer.checkConflict({ agent: 'pdm', type: 'work_order', assetId: equipment });
  if (conflict.blocked) return res.status(409).json({ blocked: true, reason: conflict.reason, ruleId: conflict.ruleId });
  try {
    const wo = await createMaintenanceNotification({ equipment, text: description, priority });
    await semanticLayer.publishEvent({ id: `WO-${Date.now()}`, from: 'pdm', to: 'oee', type: 'work_order_created', sev: 'info', msg: `WO ${wo.MaintenanceNotification}: ${description}`, impact: 'Maintenance scheduled', asset: equipment, ts: new Date().toISOString() });
    res.json({ success: true, workOrderId: wo.MaintenanceNotification });
  } catch { res.status(502).json({ error: 'SAP PM unavailable' }); }
});

pdmRouter.post('/parts-order', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity, assetId, reason } = req.body as { material: string; quantity: number; assetId: string; reason: string };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: `[ManuAI PdM] ${assetId}: ${reason}`, deliveryDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0] });
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

// PDM assets, utilities and work orders — all from CSV files
// REPLACE WITH: IoT Hub + SAP PM in Phase 3
const getPdmAssets = () => loadMachines();
const getUtilAssets = () => loadUtilities();
const getPdmWorkorders = () => loadWorkOrders();

// ══════════════════════════════════════════════════════════════
// Quality Vision Agent
// ══════════════════════════════════════════════════════════════
export const qualityRouter = Router();

qualityRouter.get('/defects', (_req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const defects = loadQualityDefects();
  const major = defects.filter((d:any) => d.severity === 'major').length;
  const minor = defects.filter((d:any) => d.severity === 'minor').length;
  // Build hourly trend for chart
  const hourly: Record<string, number> = {};
  for (let h = 6; h <= 18; h++) hourly[`${String(h).padStart(2,'0')}:00`] = 0;
  for (const d of defects as any[]) {
    const bucket = ((d.time as string)?.slice(0, 2) ?? '06') + ':00';
    if (hourly[bucket] !== undefined) hourly[bucket]++;
  }
  const trend = Object.entries(hourly).map(([h, count]) => ({ h, defects: count }));
  res.json({
    log: defects, trend,          // what frontend expects
    defects,                       // legacy field
    summary: { total: defects.length, major, minor },
    source_mode: 'CSV', source_system: 'VISION_AI_SAP_QM', plant_id: 'P1',
  });
});
qualityRouter.get('/lines', (_req, res) => res.json({ lines: loadQualityLines() }));

// Quality defects and lines — from CSV files (REPLACE WITH Vision AI + MES in Phase 3)
const getQualityDefects = () => loadQualityDefects();
const getQualityLines   = () => loadQualityLines();

// ══════════════════════════════════════════════════════════════
// Energy Optimisation Agent
// ══════════════════════════════════════════════════════════════
export const energyRouter = Router();

energyRouter.get('/load', (_req, res) => {
  const state = getPlantState();
  res.json({ trend: state.energyTrend, assets: state.energyAssets, waste: getEnergyWasteList(), totalKw: state.energyKw });
});

energyRouter.post('/dispatch', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { assetId, action } = req.body as { assetId: string; action: string };
  // Issue 12: semantic governance — energy dispatch can affect yield-critical assets
  const conflict = semanticLayer.checkConflict({ agent: 'energy', type: 'dispatch', assetId });
  if (conflict.blocked) return res.status(409).json({ blocked: true, reason: conflict.reason, ruleId: conflict.ruleId });
  logger.info('Energy dispatch', { assetId, action, user: req.user?.name });
  await semanticLayer.publishEvent({ id: `ED-${Date.now()}`, from: 'energy', to: 'yield', type: 'energy_dispatch', sev: 'info', msg: `Dispatch ${action} on ${assetId}`, impact: 'Load profile change', asset: assetId, ts: new Date().toISOString() });
  res.json({ success: true, assetId, action, dispatchedAt: new Date().toISOString() });
});

// Energy assets and waste — from CSV files (REPLACE WITH smart meters + IoT Hub in Phase 3)
const getEnergyAssetsList = () => loadEnergyAssets();
const getEnergyWasteList  = () => loadEnergyWaste();

// ══════════════════════════════════════════════════════════════
// Supply Chain Resilience Agent
// ══════════════════════════════════════════════════════════════
export const supplyRouter = Router();

// Issue 10 fix: risk scoring server-side; raw rows preserved for compatibility
supplyRouter.get('/risks', async (_req, res) => {
  const raw = loadSupplyRisks() as any[];
  const scored = raw.map((s: any) => {
    const leadDrift = Number(s.lead_time_actual_days ?? 0) - Number(s.lead_time_contracted_days ?? 0);
    const stockDays = Number(s.current_stock_days ?? 0);
    const risk = stockDays < 14 ? 'critical' : stockDays < 30 ? 'high' : 'medium';
    return {
      supplier:  s.supplier_name,
      sku:       s.sku,
      desc:      s.description,
      risk, stockDays, leadDrift,
      exposure:  s.monthly_consumption ? `\u20b9${(Number(s.monthly_consumption) * Number(s.unit_cost_inr ?? 0) / 100000).toFixed(1)}L/mo` : '\u2014',
      reason:    Number(s.financial_risk_score ?? 0) > 6 ? 'Financial distress' : s.country_of_origin !== 'Germany' && s.single_source === 'true' ? 'Geopolitical risk' : 'Lead time drift',
      action:    stockDays < 14 ? 'Emergency PO required' : 'Expedite delivery',
    };
  });
  // Issue 5: enrich with supply-intelligence multi-factor assessment when available
  let assessed: any = null;
  const SUPPLY_SERVICE_URL = process.env.SUPPLY_SERVICE_URL;
  if (SUPPLY_SERVICE_URL) {
    try {
      const r = await fetch(`${SUPPLY_SERVICE_URL}/assess`, { signal: AbortSignal.timeout(2000) });
      if (r.ok) assessed = await r.json();
    } catch { /* CSV-only response */ }
  }
  res.json({
    risks: loadSupplyRisks(),  // raw rows — legacy consumers
    scored,                     // pre-scored — new consumers
    assessed,                   // service multi-factor assessment (null if unavailable)
    source_mode: assessed ? 'SERVICE+CSV' : 'CSV',
    source_system: 'ERP_SUPPLIER_RISK', plant_id: 'P1',
  });
});
supplyRouter.get('/forecast', (_req, res) => res.json({ forecast: loadDemandForecast() }));

supplyRouter.post('/reorder', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity } = req.body as { material: string; quantity: number };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: '[ManuAI Supply] Risk-triggered reorder', deliveryDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0] });
    await semanticLayer.publishEvent({ id: `SR-${Date.now()}`, from: 'supply', to: 'pdm', type: 'reorder_created', sev: 'info', msg: `PR ${pr.PurchaseRequisition}: ${quantity}x ${material}`, impact: 'Parts inbound', asset: material, ts: new Date().toISOString() });
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

// ══════════════════════════════════════════════════════════════
// Digital Twin Operations Agent
// ══════════════════════════════════════════════════════════════
export const twinRouter = Router();

// Issue 5+11 fix: twin-sync service is authoritative; CSV computation is fallback
const TWIN_SERVICE_URL = process.env.TWIN_SERVICE_URL;
twinRouter.get('/status', async (_req, res) => {
  if (TWIN_SERVICE_URL) {
    try {
      const r = await fetch(`${TWIN_SERVICE_URL}/status`, { signal: AbortSignal.timeout(2000) });
      if (r.ok) {
        const svc: any = await r.json();
        return res.json({
          syncedAt: svc.synced_at ?? new Date().toISOString(),
          accuracy: svc.accuracy_pct ?? 0,
          diverging: svc.diverging_count ?? 0,
          scenarios: Array.isArray(svc.scenarios) ? svc.scenarios.length : loadTwinScenarios().length,
          source_mode: 'SERVICE', source_system: 'twin-sync', plant_id: 'P1',
        });
      }
    } catch { /* fall through to CSV */ }
  }
  // CSV fallback (pre-Issue-5 behaviour)
  const kpis = loadTwinKPIs() as any[];
  const divergingCount = kpis.filter(k => {
    const delta = Math.abs(k.actual - k.twin_predicted);
    const pct = k.twin_predicted !== 0 ? delta / Math.abs(k.twin_predicted) * 100 : 0;
    return pct > k.threshold_pct;
  }).length;
  res.json({
    syncedAt: new Date().toISOString(),
    accuracy: +(100 - divergingCount * 1.2).toFixed(1),
    diverging: divergingCount,
    scenarios: loadTwinScenarios().length,
    source_mode:   'CSV',
    source_system: 'Azure_Digital_Twins',
    plant_id:      'P1',
  });
});
twinRouter.get('/divergence', (_req, res) => {
  const kpis = loadTwinKPIs();
  const divergence = kpis.map(k => {
    const delta = k.actual - k.twin_predicted;
    const pct = k.twin_predicted !== 0 ? Math.abs(delta / k.twin_predicted * 100) : 0;
    const status = pct > k.threshold_pct * 2 ? 'critical' : pct > k.threshold_pct ? 'diverging' : 'aligned';
    const sign = delta >= 0 ? '+' : '';
    return { kpi: k.kpi_name, actual: k.actual, twin: k.twin_predicted,
             delta: `${sign}${delta.toFixed(1)}${k.unit === '%' ? '%' : ''}`,
             status, time: 'live' };
  });
  res.json({ divergence });
});
twinRouter.get('/scenarios',  (_req, res) => res.json({ scenarios: loadTwinScenarios() }));

twinRouter.post('/scenarios/:id/run', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  logger.info('Twin scenario run', { id: req.params.id, user: req.user?.name });
  // Issue 12: scenario runs are cross-agent events (twin → yield/oee consumers)
  await semanticLayer.publishEvent({ id: `TS-${Date.now()}`, from: 'twin', to: 'yield', type: 'scenario_run', sev: 'info', msg: `Scenario ${req.params.id} started`, impact: 'Simulation in progress', asset: req.params.id, ts: new Date().toISOString() });
  res.json({ success: true, scenarioId: req.params.id, status: 'running', estimatedMinutes: 8 });
});

// TWIN_DIVERGENCE removed — served from twin_kpis.csv via /api/twin/divergence
// TWIN_SCENARIOS removed — served from twin_scenarios.csv via /api/twin/scenarios

// ══════════════════════════════════════════════════════════════
// Safety & Compliance Agent
// ══════════════════════════════════════════════════════════════
export const safetyRouter = Router();

safetyRouter.get('/events', (_req, res) => {
  try {
    const db = require('../database/connection').getDb();
    const events = db.prepare('SELECT * FROM safety_events WHERE resolved_at IS NULL ORDER BY ts DESC LIMIT 20').all();
    const openCritical = events.filter((e:any) => e.severity === 'critical').length;
    res.json({
      events, openCritical,
      source_mode:   'Synthetic',
      source_system: 'EHS_SENSOR_NETWORK',
      plant_id:      'P1',
    });
  } catch { res.json({ events: [], openCritical: 0 }); }
});
safetyRouter.get('/ptw', (_req, res) => res.json({ permits: loadSafetyPermits() }));

safetyRouter.post('/ptw/:id/approve', requireRole(ROLES.ENGINEER, ROLES.SUPERVISOR, ROLES.ADMIN), (req, res) => {
  logger.info('PTW approval', { id: req.params.id, user: req.user?.name });
  res.json({ success: true, ptwId: req.params.id, approvedBy: req.user?.name, at: new Date().toISOString() });
});

// SAFETY_EVENTS now served from SQLite via /api/history/safety/events
// PTW_LIST now served from safety_permits.csv via /api/safety/permits

// ══════════════════════════════════════════════════════════════
// Semantic Layer Routes
// ══════════════════════════════════════════════════════════════
export const semanticRouter = Router();

semanticRouter.get('/kpis',   (_req, res) => res.json({ kpis: semanticLayer.getKPIDefinitions() }));
semanticRouter.get('/events', async (_req, res) => res.json({ events: await semanticLayer.getRecentEvents(50) }));

// ══════════════════════════════════════════════════════════════
// Unified AI Routes
// ══════════════════════════════════════════════════════════════
export const aiRouter = Router();

const ChatSchema = z.object({
  messages: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string() })),
  liveContext: z.string().optional(),
});

aiRouter.post('/chat', async (req, res) => {
  const parsed = ChatSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  try {
    const reply = await unifiedChat(parsed.data.messages as any, parsed.data.liveContext);
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

aiRouter.post('/recommend/:agent', async (req, res) => {
  const { context, question } = req.body as { context: string; question: string };
  try {
    const reply = await agentRecommendation(req.params.agent, context, question);
    res.json({ reply, agent: req.params.agent });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

aiRouter.post('/semantic-query', async (req, res) => {
  const { question, kpiContext } = req.body as { question: string; kpiContext: string };
  try {
    const reply = await semanticQuery(question, kpiContext);
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});
