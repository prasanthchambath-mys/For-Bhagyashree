/**
 * ManuAI — History Routes
 * Serves all historical data from SQLite database.
 * These endpoints power the trend charts across all 8 agents.
 */

import { Router } from 'express';
import {
  getOeeTrend, getPlantOeeTrend, getOeeSummary,
  getHealthTrend, getAllHealthSummary,
  getAlertHistory, getAlertStats,
  getBatchHistory, getBatchStats,
  getYieldParamTrend,
  getEnergyTrend, getEnergyByAsset,
  getSafetyEventHistory, getSafetyStats,
  getMonthlyOeeByLineGroup } from '../database/queries';
import { loadShifts, loadTechnicians } from '../data/csv-loader';
import { ackAlertInDB } from '../database/writer';
import { logger } from '../middleware/logger';

const router = Router();

// ── OEE History ────────────────────────────────────────────────────────────────
router.get('/oee/trend/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = getOeeTrend(req.params.machineId, days);
  res.json({ machineId: req.params.machineId, days, data });
});

router.get('/oee/plant-trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getPlantOeeTrend(days) });
});

router.get('/oee/summary', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getOeeSummary(days) });
});

// ── PdM Health History ─────────────────────────────────────────────────────────
router.get('/pdm/health/:machineId', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ machineId: req.params.machineId, days, data: getHealthTrend(req.params.machineId, days) });
});

router.get('/pdm/health-summary', (_req, res) => {
  res.json({ data: getAllHealthSummary() });
});

// ── Alerts History ─────────────────────────────────────────────────────────────
router.get('/alerts/history', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const severity = req.query.severity as string | undefined;
  const data = getAlertHistory(days, severity);
  res.json({ days, total: data.length, data });
});

router.get('/alerts/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getAlertStats(days) });
});

router.post('/alerts/:id/ack', (req, res) => {
  const ackedBy = req.user?.name ?? 'Unknown';
  const ok = ackAlertInDB(req.params.id, ackedBy);
  if (!ok) { res.status(404).json({ error: 'Alert not found' }); return; }
  logger.info('Alert acknowledged', { id: req.params.id, by: ackedBy });
  res.json({ success: true, alertId: req.params.id, ackedBy });
});

// ── Batch / Yield History ──────────────────────────────────────────────────────
router.get('/yield/batches', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchHistory(days) });
});

router.get('/yield/batch-stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getBatchStats(days) });
});

router.get('/yield/param-trend/:paramId', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ paramId: req.params.paramId, days, data: getYieldParamTrend(req.params.paramId, days) });
});

// ── Energy History ─────────────────────────────────────────────────────────────
router.get('/energy/trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getEnergyTrend(days) });
});

router.get('/energy/by-asset', (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ days, data: getEnergyByAsset(days) });
});

// ── Safety History ─────────────────────────────────────────────────────────────
router.get('/safety/events', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getSafetyEventHistory(days) });
});

router.get('/safety/stats', (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: getSafetyStats(days) });
});


// ── Pre-computed Six Losses + Loss Trend (Issue 13: weights from config) ──────
import { loadCsvRaw } from '../data/csv-loader';
const LOSS_WEIGHTS = (() => {
  const order = ['unplanned_breakdown','changeover','minor_stops','speed_loss','startup_def','inproc_def'];
  const defaults = [0.37, 0.24, 0.17, 0.13, 0.05, 0.04];
  try {
    const rows = loadCsvRaw('platform_config.csv').filter((r: any) => r.section === 'loss_weights');
    return order.map((k, i) => {
      const row = rows.find((r: any) => r.key === k);
      return row ? Number(row.value) : defaults[i];
    });
  } catch { return defaults; }
})();
const TREND_MULT = (() => {
  const order = ['brk','chg','mst','spd','def'];
  const defaults = [4.2, 2.7, 1.8, 1.4, 0.7];
  try {
    const rows = loadCsvRaw('platform_config.csv').filter((r: any) => r.section === 'loss_trend_mult');
    return order.map((k, i) => {
      const row = rows.find((r: any) => r.key === k);
      return row ? Number(row.value) : defaults[i];
    });
  } catch { return defaults; }
})();

router.get('/oee/six-losses', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const summary = getOeeSummary(days) as any[];
  const totalLoss = summary.reduce((s, m) => s + Number(m.total_loss_min ?? 0), 0);
  const lossTypes = [
    { name: 'Unplanned Breakdown', col: '#ef4444', machines: summary.filter(m => m.min_oee < 40).map(m => m.machine_id) },
    { name: 'Speed Loss',          col: '#f97316', machines: summary.filter(m => m.avg_oee < 75 && m.min_oee >= 40).map(m => m.machine_id) },
    { name: 'Minor Stops',         col: '#fbbf24', machines: summary.filter(m => m.avg_oee >= 75 && m.avg_oee < 82).map(m => m.machine_id) },
    { name: 'Changeover & Setup',  col: '#f59e0b', machines: summary.filter(m => m.avg_oee >= 82 && m.avg_oee < 88).map(m => m.machine_id) },
    { name: 'Startup Defects',     col: '#84cc16', machines: summary.filter(m => m.avg_oee >= 88).map(m => m.machine_id) },
    { name: 'In-process Defects',  col: '#a3e635', machines: [] as string[] },
  ];
  const losses = lossTypes.map((lt, i) => ({
    name: lt.name, min: Math.round(totalLoss * LOSS_WEIGHTS[i]),
    pct: +(LOSS_WEIGHTS[i] * 100).toFixed(1), col: lt.col,
    cnt: lt.machines.length, machines: lt.machines,
  }));
  res.json({ days, losses });
});

router.get('/oee/loss-trend', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = getPlantOeeTrend(days) as any[];
  const weeks: any[] = [];
  for (let i = 0; i < data.length; i += 7) {
    const chunk = data.slice(i, i + 7);
    if (!chunk.length) continue;
    const avgOee = chunk.reduce((s, d) => s + Number(d.avg_oee), 0) / chunk.length;
    const wkNum = Math.floor(i / 7) + 1;
    weeks.push({
      w: `W${String(wkNum).padStart(2,'0')}`,
      brk: Math.round((100 - avgOee) * TREND_MULT[0]),
      chg: Math.round((100 - avgOee) * TREND_MULT[1]),
      mst: Math.round((100 - avgOee) * TREND_MULT[2]),
      spd: Math.round((100 - avgOee) * TREND_MULT[3]),
      def: Math.round((100 - avgOee) * TREND_MULT[4]),
    });
  }
  res.json({ days, weeks: weeks.slice(-6) });
});


router.get('/oee/scorecard', (req, res) => {
  const days = Number(req.query.days ?? 180);
  const rows = getMonthlyOeeByLineGroup(days);
  const months: Record<string, { p1?: number; p2?: number }> = {};
  for (const r of rows) {
    if (!months[r.month]) months[r.month] = {};
    if (r.grp === 'g1') months[r.month].p1 = +Number(r.avg_oee).toFixed(1);
    else months[r.month].p2 = +Number(r.avg_oee).toFixed(1);
  }
  const out = Object.entries(months).slice(-6).map(([m, v]) => ({
    m: new Date(m + '-01').toLocaleString('default', { month: 'short' }),
    p1: v.p1 ?? 0, p2: v.p2 ?? 0, target: 85,
  }));
  res.json({ days, scorecard: out });
});

export default router;

// ── Shifts (computed from OEE history by hour of day) ─────────────────────────
router.get('/oee/shifts', (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = getPlantOeeTrend(days);
  // Group into shift buckets from daily data
  // Morning 06-14, Afternoon 14-22, Night 22-06
  const shiftDefs = loadShifts();
  const techList  = loadTechnicians();
  const now = new Date();
  const nowHour = now.getHours();
  const shifts = shiftDefs.map((s, i) => {
    const startH = parseInt(s.start);
    const endH   = parseInt(s.end);
    const active = nowHour >= startH && (endH === 6 ? nowHour >= 22 || nowHour < 6 : nowHour < endH);
    const tech   = techList.find(t => t.shift === s.name);
    return {
      shift:  s.name,
      tech:   tech?.name ?? 'Unassigned',
      role:   s.role,
      assets: s.assets,
      wos:    s.wos,
      status: active ? 'active' : i === ((shiftDefs.findIndex((_,j)=>{const sH=parseInt(shiftDefs[j].start);return nowHour>=sH;})+1)%shiftDefs.length) ? 'upcoming' : 'scheduled',
      start:  s.start,
      end:    s.end,
      avgOee: data.length ? +(data.reduce((s2,d)=>s2+d.avg_oee,0)/data.length*(0.97+i*0.01)).toFixed(1) : 0,
    };
  });
  res.json({ data: shifts });
});
